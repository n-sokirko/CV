import React, {useEffect, useState} from 'react';
import './IngredientsManagement.scss';
import SearchBar from "../../components/meals/SearchBar.jsx";
import SortingItem from "../../components/meals/SortingItem.jsx";
import {getIngredients} from "../../service/api/restaurantApi.js";
import IngredientItem from "../../components/ingredients/IngredientItem.jsx";
import {useNavigate} from "react-router-dom";

const IngredientsManagement = () => {

    const navigate = useNavigate();

    const sortingOptions = [
        {label: "Name A-Z ", value: "name asc"},
        {label: "Name Z-A", value: "name desc"}
    ];

    const [ingredients, setIngredients] = useState([]);

    const [loading, setLoading] = useState(true);

    const [searchExpression, setSearchExpression] = useState("");
    const [searchQuery, setSearchQuery] = useState("");

    const [numberOfPages, setNumberOfPages] = useState(1);
    const [currentPage, setCurrentPage] = useState(0);
    const ingredientsPerPage = 12;
    const [sortingOption, setSortingOption] = useState("");


    useEffect(() => {
        const checkIfLoggedIn = () => {
            const sessionStorageToken = sessionStorage.getItem('jwt_restaurant');
            if (!sessionStorageToken){
                navigate('/restaurant/login');
            }
        };
        checkIfLoggedIn();
    }, []);

    const updateSearchInputChange = (event) => {
        setSearchExpression(event.target.value);
    };

    const updateSearchInput = (event) => {
        if (event.key === 'Enter') {
            setSearchQuery(searchExpression);
            setCurrentPage(0);
        }
    };

    const updateSortingOption = (option) => {
        setSortingOption(option);
    };

    const updateNumberOfPage = (pageNumber) => {
        setCurrentPage(pageNumber - 1);
    };


    useEffect(() => {
        const fetchIngredients = async () => {
            setLoading(true);
            try {
                const response = await getIngredients(
                    searchQuery, currentPage, ingredientsPerPage, sortingOption);
                const result = await response.json();
                const ingredients = result.content;
                setIngredients(ingredients);

                setNumberOfPages(result.totalPages);

            } catch (error) {
                console.error("Error during fetching ingredients", error);
            } finally {
                setLoading(false);
            }
        };
        fetchIngredients();
    }, [searchQuery, currentPage, sortingOption]);


    const renderPagination = () => {
        const pages = [];
        for (let i = 1; i <= numberOfPages; i++) {
            pages.push(
                <button
                    key={i}
                    className={`pagination-button ${i === currentPage + 1 ? 'active' : ''}`}
                    onClick={() => updateNumberOfPage(i)}
                >
                    {i}
                </button>
            );
        }
        return <div className="pagination-container">{pages}</div>;
    };

    return (
        <div className="restaurant__ingredients-management--wrapper">
            <div className="restaurant__ingredients-management--title">Manage ingredients availability</div>

            <div className="restaurant__ingredients-management--search-sort-container">
                <SearchBar
                    placeholder="Search ingredients..."
                    onChange={updateSearchInputChange}
                    onKeyDown={updateSearchInput}
                />
                <SortingItem
                    options={sortingOptions}
                    onSortChange={updateSortingOption}
                />
            </div>

            {loading ? (
                <div className="restaurant__ingredients-management--loading-ingredients-message">Loading ingredients...</div>
            ) : (
                <>
                    <div className="restaurant__ingredients-management--list-container">
                        {ingredients.length === 0 ? (
                            <div className="restaurant__ingredients-management--no-ingredients-message">No ingredients found</div>
                        ) : (
                            ingredients.map((ingredient) => (
                                <IngredientItem
                                    key={ingredient.id}
                                    id={ingredient.id}
                                    name={ingredient.name}
                                    isAvailable={ingredient.isAvailable}
                                />
                            ))
                        )}
                    </div>
                    {renderPagination()}
                </>
            )}
        </div>
    );
};

export default IngredientsManagement;