import React, {useState, useEffect} from 'react';
import './ContactForm.scss';
import {getOpeningHours} from "../../service/api/customerApi.js";

const ContactForm = () => {

    const [openingHours, setOpeningHours] = useState([]);

    useEffect(() => {
        const getOpeningHoursFunction = async () => {
            try {
                const response = await getOpeningHours();
                const data = await response.json();

                const weekdaysMap = {
                    1: 'Mon',
                    2: 'Tue',
                    3: 'Wed',
                    4: 'Thu',
                    5: 'Fri',
                    6: 'Sat',
                    7: 'Sun'
                };

                const hours = data.map(item => ({
                    day: weekdaysMap[item.weekday],
                    openingTime: item.openingTime.slice(0, 5),
                    closingTime: item.closingTime.slice(0, 5)
                }));

                setOpeningHours(hours);
            } catch (error) {
                console.error('Error fetching opening hours:', error);
            }
        };

        getOpeningHoursFunction();
    }, []);

    return (
        <>
            <div className="common__contact-form--container-wrapper">
                <h1 style={{fontSize: '48px', color: 'white'}}>Contact us</h1>
                <div className="common__contact-form--container">
                    <div className="common__contact-form--info-and-hours-section">
                        <p className="common__contact-form--text">If you have any questions about our services, or if
                            you
                            need assistance
                            with reservations or other inquiries, please don't hesitate to reach out to us. We're here
                            to
                            help!</p>
                        <div className="common__contact-form--contact-details">
                            <div className="common__contact-form--info-item">
                                <i className="fa-solid fa-location-dot common__contact-form--info-icon"></i>
                                <h4>Location</h4>
                                <p className="common__contact-form--info-detail">High Street 13b</p>
                            </div>
                            <div className="common__contact-form--info-item">
                                <i className="fa-solid fa-envelope common__contact-form--info-icon"></i>
                                <h4>Email</h4>
                                <p className="common__contact-form--info-detail">restaurant-zpi@gmail.com</p>
                            </div>
                            <div className="common__contact-form--info-item">
                                <i className="fa-solid fa-phone common__contact-form--info-icon"></i>
                                <h4>Phone</h4>
                                <p className="common__contact-form--info-detail">123-456-789</p>
                            </div>
                        </div>
                        <div className="common__contact-form--opening-hours">
                            <strong>Opening Hours:</strong><br/>
                            {openingHours.length > 0 ? (
                                openingHours.map((hour, index) => (
                                    <div key={index}>
                                        {hour.day}: {hour.openingTime} - {hour.closingTime}
                                    </div>
                                ))
                            ) : (
                                <p>Loading opening hours...</p>
                            )}
                        </div>
                    </div>
                    <div className="common__contact-form--map-section">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10000.1!2d17.1!3d51.1!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7f!2zTcWCb3N0ZSB3IEtyYWtvd2ll!5e0!3m2!1spl!2spl!4v1600000000000"
                            allowFullScreen
                        ></iframe>
                    </div>
                </div>
            </div>
        </>
    );
};

export default ContactForm;