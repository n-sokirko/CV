import React, { useEffect, useState, useCallback } from 'react';
import './ReservationsHistory.scss';
import ReservationItem from "./../../../components/personalData/history/ReservationItem.jsx";
import { getClientById } from "../../../service/api/waiterApi.js";
import { getPersonalData, getReservationsByClientId } from "../../../service/api/customerApi.js";
import FilterBar from "./FilterBar.jsx";
import { useNavigate } from "react-router-dom";

const ReservationsHistory = () => {
    const navigate = useNavigate();

    const [numberOfPages, setNumberOfPages] = useState(1);
    const [currentPage, setCurrentPage] = useState(0);
    const reservationsPerPage = 12;
    const [reservations, setReservations] = useState([]);
    const [dateFilter, setDateFilter] = useState({ start: '', end: '' });

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, [navigate]);

    const updateNumberOfPage = (pageNumber) => {
        setCurrentPage(pageNumber - 1);
    };

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };

    const updateDateFilter = (dates) => {
        setDateFilter(dates);
    };

    const getReservationsFunction = useCallback(async () => {
        const token = getToken();
        const clientResponse = await getPersonalData(token);
        const userData = await clientResponse.json();

        const formattedStart = dateFilter.start ? dateFilter.start.replace(/-/g, '/') : '';
        const formattedEnd = dateFilter.end ? dateFilter.end.replace(/-/g, '/') : '';

        const reservationResponse = await getReservationsByClientId(currentPage, reservationsPerPage, userData.id, formattedStart, formattedEnd);
        const reservationResult = await reservationResponse.json();
        setNumberOfPages(reservationResult.totalPages);

        const updatedReservations = await Promise.all(reservationResult.content.map(async (reservation) => {
            const clientResponse = await getClientById(reservation.clientId);
            const clientResult = await clientResponse.json();
            reservation.clientName = clientResult.name;
            return reservation;
        }));

        setReservations(updatedReservations);
    }, [currentPage, reservationsPerPage, dateFilter]);

    useEffect(() => {
        getReservationsFunction();
    }, [getReservationsFunction]);

    const renderPagination = () => {
        const pages = [];
        for (let i = 1; i <= numberOfPages; i++) {
            pages.push(
                <button
                    key={i}
                    className={`pagination-button ${i === currentPage + 1 ? 'active' : ''}`}
                    onClick={() => updateNumberOfPage(i)}
                >
                    {i}
                </button>
            );
        }
        return <div className="pagination-container">{pages}</div>;
    };

    return (
        <div className="client-reservations-wrapper">
            <div className="client-reservations-title">Your Reservation History</div>
            <FilterBar onDateFilterChange={updateDateFilter} />
            {reservations.length === 0 ? (
                <div className="no-reservations-message">No reservations found</div>
            ) : (
                <div className="client-reservations-list-container">
                    {reservations.map((reservation) => (
                        <ReservationItem
                            key={reservation.id}
                            id={reservation.id}
                            date={reservation.reservationDate}
                            startTime={reservation.startTime}
                            endTime={reservation.endTime}
                            diningDeskIds={reservation.diningDeskIds}
                            status={reservation.state}
                            notes={reservation.additionalComments}
                            numberOfGuests={reservation.numberOfPeople}
                            refreshReservations={getReservationsFunction}
                        />
                    ))}
                </div>
            )}
            {renderPagination()}
        </div>
    );
};

export default ReservationsHistory;