import React, {useEffect, useState} from 'react';
import './OrdersHistory.scss';
import OrderItem from "./../../../components/personalData/history/OrderItem.jsx";
import {
    getOrdersByClientId,
    getPersonalData,
} from "../../../service/api/customerApi.js";
import FilterBar from "./FilterBar.jsx";
import {useNavigate} from "react-router-dom";

const OrdersHistory = () => {
    const navigate = useNavigate();
    const [ordersData, setOrdersData] = useState([]);
    const [numberOfPages, setNumberOfPages] = useState(1);
    const [currentPage, setCurrentPage] = useState(0);
    const [dateFilter, setDateFilter] = useState({start: '', end: ''});
    const [loading, setLoading] = useState(true);
    const ordersPerPage = 12;

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, [navigate]);

    const updateNumberOfPage = (pageNumber) => {
        setCurrentPage(pageNumber - 1);
    };

    const updateDateFilter = (dates) => {
        setDateFilter(dates);
        setCurrentPage(0);
    };

    useEffect(() => {
        const fetchOrders = async () => {
            setLoading(true);
            try {
                const token = localStorage.getItem('jwt_client') || sessionStorage.getItem('jwt_client');
                const clientResponse = await getPersonalData(token);
                const userData = await clientResponse.json();
                const formattedStart = dateFilter.start ? dateFilter.start.replace(/-/g, '/') : '';
                const formattedEnd = dateFilter.end ? dateFilter.end.replace(/-/g, '/') : '';
                const response = await getOrdersByClientId(currentPage, ordersPerPage, userData.id, formattedStart, formattedEnd);
                const result = await response.json();
                setNumberOfPages(result.totalPages);
                setOrdersData(result.content.map(order => ({
                    ...order,
                    items: [],
                    table: null,
                    room: null,
                    totalPrice: null
                })));
            } catch (error) {
                console.error("Error fetching orders", error);
            } finally {
                setLoading(false);
            }
        };
        fetchOrders();
    }, [currentPage, dateFilter]);

    const renderPagination = () => {
        const pages = [];
        for (let i = 1; i <= numberOfPages; i++) {
            pages.push(
                <button
                    key={i}
                    className={`pagination-button ${i === currentPage + 1 ? 'active' : ''}`}
                    onClick={() => updateNumberOfPage(i)}
                >
                    {i}
                </button>
            );
        }
        return <div className="pagination-container">{pages}</div>;
    };

    return (
        <div className="client-orders-wrapper">
            <div className="client-orders-title">Your Order History</div>
            <FilterBar onDateFilterChange={updateDateFilter}/>
            {loading ? (
                <div className="loading-message">Loading orders...</div>
            ) : ordersData.length === 0 ? (
                <div className="no-orders-message">No orders found</div>
            ) : (
                <>
                    <div className="client-orders-list-container">
                        {ordersData.map((order) => (
                            <OrderItem
                                key={order.id}
                                order={order}
                                fetchDetails={true}
                            />
                        ))}
                    </div>
                    {renderPagination()}
                </>
            )}
        </div>
    );
};

export default OrdersHistory;