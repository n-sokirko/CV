import EditPersonalData from "../../components/personalData/EditPersonalData.jsx";
import React, {useEffect} from 'react';
import './AccountPage.scss';
import EditDietPreferences from "../../components/personalData/EditDietPreferences.jsx";
import {useNavigate} from "react-router-dom";

const AccountPage = () => {
    const navigate = useNavigate();

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, []);

    return (
        <div className="client__account--container-wrapper">
            <div className="client__account--container">
                <EditPersonalData/>
                <EditDietPreferences/>
            </div>
        </div>
    );
};


export default AccountPage;