import React from 'react'
import {RegisterForm} from '../../components/authentication/RegisterForm'

const Register = () => {
    return (
        <RegisterForm/>
    )
}

export default Register