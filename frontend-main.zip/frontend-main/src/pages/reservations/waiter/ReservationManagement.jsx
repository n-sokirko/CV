import React, {useEffect, useState} from 'react';
import './ReservationManagement.scss';
import ReservationItem from "./../../../components/reservations/waiter/ReservationItem.jsx";
import FilterBar from "../../../components/reservations/waiter/FilterBar.jsx";
import {getClientById, getReservations} from "../../../service/api/waiterApi.js";
import {useNavigate} from "react-router-dom";

const ReservationManagement = () => {
    const navigate = useNavigate();

    const [dateFilter, setDateFilter] = useState({start: '', end: ''});
    const [numberOfPages, setNumberOfPages] = useState(1);
    const [currentPage, setCurrentPage] = useState(0);
    const reservationsPerPage = 12;
    const [reservations, setReservations] = useState([]);
    const [loading, setLoading] = useState(true);

    const updateDateFilter = (dates) => {
        setDateFilter(dates);
        setCurrentPage(0);
    };

    const updateNumberOfPage = (pageNumber) => {
        setCurrentPage(pageNumber - 1);
    };

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const sessionStorageToken = sessionStorage.getItem('jwt_waiter');
            if (!sessionStorageToken) {
                navigate('/waiter/login');
            }
        };
        checkIfLoggedIn();
    }, [navigate]);

    const formatDate = (date) => {
        return `${date.getFullYear()}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')}`;
    };

    useEffect(() => {
        const getReservationsFunction = async () => {
            setLoading(true);
            const today = new Date();
            const todayDate = formatDate(today);
            const formattedStart = dateFilter.start ? dateFilter.start.replace(/-/g, '/') : '';
            const formattedEnd = dateFilter.end ? dateFilter.end.replace(/-/g, '/') : '';
            let reservationResponse
            if (formattedStart !== '' || formattedEnd !== '') {
                reservationResponse = await getReservations(currentPage, reservationsPerPage, "", formattedStart, formattedEnd);
            } else {
                reservationResponse = await getReservations(currentPage, reservationsPerPage, todayDate, "", "");
            }
            const reservationResult = await reservationResponse.json();
            setNumberOfPages(reservationResult.totalPages);

            const updatedReservations = await Promise.all(reservationResult.content.map(async (reservation) => {
                const clientResponse = await getClientById(reservation.clientId);
                const clientResult = await clientResponse.json();
                reservation.clientName = clientResult.name;
                return reservation;
            }));

            setReservations(updatedReservations);
            setLoading(false);
        };

        getReservationsFunction();
    }, [currentPage, dateFilter]);

    const renderPagination = () => {
        const pages = [];
        for (let i = 1; i <= numberOfPages; i++) {
            pages.push(
                <button
                    key={i}
                    className={`pagination-button ${i === currentPage + 1 ? 'active' : ''}`}
                    onClick={() => updateNumberOfPage(i)}
                >
                    {i}
                </button>
            );
        }
        return <div className="pagination-container">{pages}</div>;
    };

    return (
        <div className="waiter__reservations--wrapper">
            {loading ? (
                <div className="common__menu-page--loading-meals-message">Loading reservations...</div>
            ) : (
                <>
                    <div className="waiter__reservations--title">Reservations Management</div>
                    <FilterBar onDateFilterChange={updateDateFilter}/>
                    {reservations.length === 0 ? (
                        <div className="waiter__reservations--no-reservations-message">No reservations found</div>
                    ) : (
                        <div className="waiter__reservations--list-container">
                            {reservations.map((reservation) => (
                                <ReservationItem
                                    key={reservation.id}
                                    id={reservation.id}
                                    clientName={reservation.clientName}
                                    date={reservation.reservationDate}
                                    startTime={reservation.startTime}
                                    endTime={reservation.endTime}
                                    diningDeskIds={reservation.diningDeskIds}
                                    status={reservation.state}
                                    notes={reservation.additionalComments}
                                    numberOfGuests={reservation.numberOfPeople}
                                />
                            ))}
                        </div>
                    )}
                    {renderPagination()}
                </>
            )}
        </div>
    );
};

export default ReservationManagement;