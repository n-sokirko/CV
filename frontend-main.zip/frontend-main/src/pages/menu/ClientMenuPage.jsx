
import React, {useEffect, useState} from "react";
import MealItem from "./../../components/meals/MealItem";
import MealDetails from "./../../components/meals/MealDetails";
import "./ItemsPage.scss";
import SearchBar from "../../components/meals/SearchBar.jsx";
import SortingItem from "../../components/meals/SortingItem.jsx";
import DietsBar from "../../components/meals/DietsBar.jsx";
import {
    getCategoryById,
    getIngredientById,
    getAllergenById,
    getClientMenu,
    getPersonalData,
    getDietsByClientId,
    getDietById
} from "../../service/api/customerApi.js";
import {DEFAULT_IMAGE_LINK} from "../../service/api/commonApi.js";
import {useNavigate} from "react-router-dom";

const ClientMenuPage = () => {
    const navigate = useNavigate();

    const sortingOptions = [
        {label: "Price Ascending", value: "price asc"},
        {label: "Price Descending", value: "price desc"},
    ];

    const [meals, setMeals] = useState([]);
    const [mealCategories, setMealCategories] = useState({});
    const [mealIngredients, setMealIngredients] = useState({});
    const [mealAllergens, setMealAllergens] = useState({});
    const [loading, setLoading] = useState(true);
    const [diets, setDiets] = useState([]);

    const [searchExpression, setSearchExpression] = useState("");
    const [searchQuery, setSearchQuery] = useState("");

    const [numberOfPages, setNumberOfPages] = useState(1);
    const [currentPage, setCurrentPage] = useState(0);
    const mealsPerPage = 10;
    const [sortingOption, setSortingOption] = useState("");

    const [mealIdDetails, setMealIdDetails] = useState(null);

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, []);

    const updateSearchInputChange = (event) => {
        setSearchExpression(event.target.value);
    };

    const updateSearchInput = (event) => {
        if (event.key === "Enter") {
            setSearchQuery(searchExpression);
            setCurrentPage(0);
        }
    };

    const updateSortingOption = (option) => {
        setSortingOption(option);
    };

    const updateNumberOfPage = (pageNumber) => {
        setCurrentPage(pageNumber - 1);
    };

    const fetchMealCategories = async (meals) => {
        const categories = {};
        for (const meal of meals) {
            if (meal.subcategory?.categoryId) {
                const categoryId = meal.subcategory.categoryId;
                const categoryResponse = await getCategoryById(categoryId);
                const category = await categoryResponse.json();
                categories[meal.id] = category.name;
            }
        }
        return categories;
    };

    const fetchMealIngredients = async (meals) => {
        const ingredients = {};
        for (const meal of meals) {
            const mealIngredients = [];
            for (const ingredientId of meal.ingredients) {
                const ingredientResponse = await getIngredientById(ingredientId);
                const ingredient = await ingredientResponse.json();
                mealIngredients.push(ingredient);
            }
            ingredients[meal.id] = mealIngredients;
        }
        return ingredients;
    };

    const fetchMealAllergens = async (ingredients) => {
        const allergens = {};
        for (const [mealId, mealIngredients] of Object.entries(ingredients)) {
            const allergenSet = new Set();
            for (const ingredient of mealIngredients) {
                for (const allergenId of ingredient.allergens) {
                    const allergenResponse = await getAllergenById(allergenId);
                    const allergen = await allergenResponse.json();
                    allergenSet.add(allergen.code);
                }
            }
            allergens[mealId] = Array.from(allergenSet);
        }
        return allergens;
    };

    const getToken = () => {
        const localStorageToken = localStorage.getItem("jwt_client");
        const sessionStorageToken = sessionStorage.getItem("jwt_client");
        return sessionStorageToken || localStorageToken;
    };

    useEffect(() => {
        const fetchMeals = async () => {
            setLoading(true);
            try {
                const token = getToken();
                const personalDataResponse = await getPersonalData(token);
                const personalData = await personalDataResponse.json();
                const clientId = personalData.id;

                const dietsResponse = await getDietsByClientId(clientId);
                const dietsResult = await dietsResponse.json();
                const dietsIds = dietsResult.dietsIds;

                const mealResponse = await getClientMenu(
                    dietsIds
                );
                const mealResult = await mealResponse.json();

                setMeals(mealResult);
                setNumberOfPages(mealResult.totalPages);

                const categories = await fetchMealCategories(mealResult);
                const ingredients = await fetchMealIngredients(mealResult);
                const allergens = await fetchMealAllergens(ingredients);

                setMealCategories(categories);
                setMealIngredients(
                    Object.fromEntries(
                        Object.entries(ingredients).map(([id, ings]) => [
                            id,
                            ings.map((ing) => ing.name),
                        ])
                    )
                );
                setMealAllergens(allergens);
            } catch (error) {
                console.error("Error during fetching meals", error);
            } finally {
                setLoading(false);
            }
        };

        fetchMeals();
    }, [searchQuery, currentPage, sortingOption]);

    useEffect(() => {
        const fetchClientDiets = async () => {
            try {
                const token = getToken();
                const personalDataResponse = await getPersonalData(token);
                const personalData = await personalDataResponse.json();
                const clientId = personalData.id;

                const dietsResponse = await getDietsByClientId(clientId);
                const dietsResult = await dietsResponse.json();

                const dietNames = [];
                for (const dietId of dietsResult.dietsIds) {
                    const dietResponse = await getDietById(dietId);
                    const dietData = await dietResponse.json();
                    dietNames.push(dietData.name);
                }

                setDiets(dietNames);
            } catch (error) {
                console.error("Error fetching client diets", error);
            }
        };

        fetchClientDiets();
    }, []);

    const renderPagination = () => {
        const pages = [];
        for (let i = 1; i <= numberOfPages; i++) {
            pages.push(
                <button
                    key={i}
                    className={`pagination-button ${
                        i === currentPage + 1 ? "active" : ""
                    }`}
                    onClick={() => updateNumberOfPage(i)}
                >
                    {i}
                </button>
            );
        }
        return <div className="pagination-container">{pages}</div>;
    };

    const closeMealDetails = () => setMealIdDetails(null);

    return (
        <div className="common__menu-page--wrapper">
            <div className="common__menu-page--menu-title">Explore Your Personalized Menu Based on Your Diet Preferences</div>
            <DietsBar diets={diets}/>

            {loading ? (
                <div className="common__menu-page--loading-meals-message">Loading meals...</div>
            ) : (
                <>
                    <div className="common__menu-page--items-list-container">
                        {meals.length === 0 ? (
                            <div className="common__menu-page--no-meals-message">No meals available</div>
                        ) : (
                            meals.map((meal, index) => (
                                <MealItem
                                    key={index}
                                    name={meal.name}
                                    category={mealCategories[meal.id]}
                                    subcategory={meal.subcategory?.name}
                                    ingredients={mealIngredients[meal.id]}
                                    price={meal.price}
                                    calories={meal.calories || "Unknown"}
                                    imageUrl={meal.imageLink || DEFAULT_IMAGE_LINK}
                                    // diets={meal.diets || ["Not implemented"]}
                                    allergens={mealAllergens[meal.id]}
                                    isAvailable={meal.isAvailable}
                                    onCartClick={() => setMealIdDetails(meal.id)}
                                />
                            ))
                        )}
                    </div>
                    {renderPagination()}
                </>
            )}

            {mealIdDetails && (
                <div className="common__menu-page--meal-item-overlay">
                    <div className="common__menu-page--meal-item-modal">
                        <MealDetails
                            mealId={mealIdDetails}
                            onClose={() => setMealIdDetails(null)}
                        />
                    </div>
                    <div className="common__menu-page--meal-item-backdrop" onClick={closeMealDetails}></div>
                </div>
            )}
        </div>
    );
};

export default ClientMenuPage;