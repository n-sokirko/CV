import React, {useState, useEffect} from 'react';
import {useNavigate} from 'react-router-dom';
import './OrderSummary.scss';
import {getTableById} from './../../../service/api/commonApi.js';
import {placeOrder} from "../../../service/api/customerApi.js";

const OrderSummary = () => {
    const [meals, setMeals] = useState([]);
    const [total, setTotal] = useState(0);
    const [diningOption, setDiningOption] = useState(null);
    const [paymentMethod, setPaymentMethod] = useState(null);
    const [orderPlaced, setOrderPlaced] = useState(false);
    const [paymentUrl, setPaymentUrl] = useState(null);
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, []);

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };

    useEffect(() => {
        const token = getToken();
        const cartData = localStorage.getItem(`${token}_cart`);
        console.log("CART", cartData);
        if (cartData) {
            const parsedMeals = JSON.parse(cartData);
            setMeals(parsedMeals);
            const calculatedTotal = parsedMeals.reduce((totalPrice, meal) => totalPrice + meal.unitPrice * meal.mealQuantity, 0);
            setTotal(calculatedTotal.toFixed(2));
        }

        const diningDeskId = parseInt(localStorage.getItem(`${token}_dinning_desk`), 10);
        if (diningDeskId === 0) {
            setDiningOption({type: 'Take Away'});
        } else {
            getDiningTable(diningDeskId);
        }

        const payment = localStorage.getItem(`${token}_payment`);
        if (payment) {
            setPaymentMethod(payment === "ONLINE" ? "Online" : "On Site");
        }
    }, []);

    const getDiningTable = async (id) => {
        try {
            const response = await getTableById(id);
            const data = await response.json();
            setDiningOption({
                type: 'Dine In',
                tableNumber: data.tableNumber,
                roomId: data.roomId,
            });
        } catch (error) {
            console.error("Error fetching table:", error);
        }
    };

    const placeOrderFunction = async () => {
        const token = getToken()
        const diningDeskId = parseInt(localStorage.getItem(`${token}_dinning_desk`), 10);
        const orderData = {
            dinningDeskId: diningOption.type === "Take Away" ? null : diningDeskId,
            orderedMeals: meals.map((meal) => ({
                count: meal.mealQuantity,
                mealId: meal.mealId,
                modifications: meal.modifiers.map((modifier) => ({
                    modifiableIngredientId: modifier.id,
                    count: modifier.count,
                })),
            })),
            paymentType: paymentMethod === "Online" ? "ONLINE" : "ON_SITE"
        };

        setLoading(true);

        try {
            const response = await placeOrder(orderData, token);
            const data = await response.json();
            const details = data.paymentDetails || '';
            const paymentUrl = details.paymentUrl || '';

            setPaymentUrl(paymentUrl);

            localStorage.removeItem(`${token}_cart`);
            localStorage.removeItem(`${token}_dinning_desk`);
            localStorage.removeItem(`${token}_payment`);
            setMeals([]);
            setTotal(0);
            setOrderPlaced(true);
        } catch (error) {
            console.error('Error placing order:', error);
        } finally {
            setLoading(false);
        }
    };

    const goHome = () => {
        setOrderPlaced(false);
        navigate('/');
    };

    const goToPaymentPage = () => {
        if (paymentUrl) {
            window.location.href = paymentUrl;
        }
    };

    const goToMenu = () => {
        navigate('/menu');
    };

    return (
        <div className="client__order-summary--wrapper-final">
            <div className="client__order-summary--wrapper">
                <h2>Order Summary</h2>
                <div className="dining-info">
                    {diningOption ? (
                        diningOption.type === 'Take Away' ? (
                            <p>Dining Option: Take Away</p>
                        ) : (
                            <p>Dining Option: Dine In - Table {diningOption.tableNumber}, Room {diningOption.roomId}</p>
                        )
                    ) : (
                        <p>Loading dining information...</p>
                    )}
                    <p>Payment Method: {paymentMethod}</p>
                </div>
                <div className="client__order-summary--order-items-list">
                    {meals.map((meal, index) => (
                        <div key={index} className="client__order-summary--order-summary-item">
                        <span>
                            {meal.mealName} x {meal.mealQuantity} - ${(meal.unitPrice * meal.mealQuantity).toFixed(2)}
                        </span>
                        </div>
                    ))}
                </div>
                <div className="client__order-summary--order-total">
                    <strong>Total: ${total}</strong>
                </div>
                <div className="client__order-summary--order-action-buttons">
                    <button className="client__order-summary--go-to-menu-button" onClick={goToMenu}>
                        Go Back to Menu
                    </button>
                    <button
                        className="client__order-summary--place-order-button"
                        onClick={placeOrderFunction}
                        disabled={meals.length === 0 || loading}
                    >
                        {loading ? 'Placing Order...' : 'Place Order'}
                    </button>
                </div>

                {orderPlaced && (
                    paymentMethod === "Online" ? (
                        <div className="client__order-summary--order-success-modal">
                            <div className="client__order-summary--order-success-content">
                                <h3>Order successfully placed!</h3>
                                <p>To complete your order, you will be redirected to the payment page.</p>
                                <button
                                    className="client__order-summary--go-home-button"
                                    onClick={goToPaymentPage}
                                >
                                    Proceed to Payment
                                </button>
                            </div>
                            <div className="client__order-summary--order-success-backdrop"></div>
                        </div>
                    ) : (
                        <div className="client__order-summary--order-success-modal">
                            <div className="client__order-summary--order-success-content">
                                <h3>Order successfully placed!</h3>
                                <p>Thank you for your order.</p>
                                <button className="client__order-summary--go-home-button" onClick={goHome}>
                                    Go to Home Page
                                </button>
                            </div>
                            <div className="client__order-summary--order-success-backdrop"></div>
                        </div>
                    )
                )}
            </div>
        </div>
    );
};

export default OrderSummary;