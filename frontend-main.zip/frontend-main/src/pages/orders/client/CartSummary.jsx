import React, {useEffect, useState} from 'react';
import {useNavigate} from 'react-router-dom';
import CartItem from './../../../components/orders/client/CartItem.jsx';
import './CartSummary.scss';
import {getMealById, getMealsRecommendations} from "../../../service/api/customerApi.js";

const CartSummary = () => {
    const [meals, setMeals] = useState([]);
    const [loading, setLoading] = useState(false);
    const [recommendations, setRecommendations] = useState([]);
    const navigate = useNavigate();

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, [navigate]);

    useEffect(() => {
        fetchCartItems();
    }, []);

    const fetchCartItems = async () => {
        setLoading(true);
        const token = getToken();
        const cartData = localStorage.getItem(`${token}_cart`);
        if (cartData) {
            try {
                const parsedMeals = JSON.parse(cartData);
                setMeals(parsedMeals);
                const mealIds = parsedMeals.map(meal => meal.mealId);
                fetchRecommendations(mealIds);
            } catch (error) {
                console.error(`Error parsing cart data: ${error}`);
            } finally {
                setLoading(false);
            }
        } else {
            setMeals([]);
            setLoading(false);
        }
    };

    const fetchRecommendations = async (mealIds) => {
        if (mealIds && mealIds.length > 0) {
            try {
                const response = await getMealsRecommendations({cardIds: mealIds});
                const data = await response.json();
                setRecommendations(data);
            } catch (error) {
                console.error(`Error fetching recommendations: ${error}`);
            }
        } else {
            setRecommendations([]);
        }
    };

    const updateCart = (updatedMeals) => {
        const token = getToken();
        const formattedCart = updatedMeals.map((meal) => ({
            mealId: meal.mealId,
            mealName: meal.mealName,
            mealQuantity: meal.mealQuantity,
            modifiers: meal.modifiers || [],
            unitPrice: meal.unitPrice,
            totalPrice: (meal.unitPrice * meal.mealQuantity).toFixed(2),
        }));
        localStorage.setItem(`${token}_cart`, JSON.stringify(formattedCart));
        setMeals([...formattedCart]);
        const mealIds = formattedCart.map(meal => meal.mealId);
        fetchRecommendations(mealIds);
    };

    const addRecommendationToCart = (item) => {
        const existingIndex = meals.findIndex(m => m.mealId === item.id);
        if (existingIndex >= 0) {
            meals[existingIndex].mealQuantity += 1;
        } else {
            meals.push({
                mealId: item.id,
                mealName: item.name,
                mealQuantity: 1,
                unitPrice: item.price,
                modifiers: [],
            });
        }
        updateCart(meals);
    };

    const incrementMealQuantity = (index) => {
        const newMeals = [...meals];
        newMeals[index].mealQuantity += 1;
        updateCart(newMeals);
    };

    const decrementMealQuantity = (index) => {
        const newMeals = [...meals];
        if (newMeals[index].mealQuantity > 1) {
            newMeals[index].mealQuantity -= 1;
            updateCart(newMeals);
        } else {
            newMeals.splice(index, 1);
            updateCart(newMeals);
        }
    };

    const removeMeal = (index) => {
        const newMeals = meals.filter((_, i) => i !== index);
        updateCart(newMeals);
    };

    const totalPrice = meals.reduce((total, meal) => total + parseFloat(meal.totalPrice), 0).toFixed(2);

    return (
        <>
            <div className="client__cart-summary--wrapper-container">
                <h1 style={{fontSize: '46px', color: 'white'}}>Cart Summary</h1>
                <div className="client__cart-summary--wrapper">
                    <div className="client__cart-summary--cart-items-list">
                        <div className="client__cart-summary--title">Your Cart</div>
                        <div className="client__cart-summary--cart-items-scrollable">
                            {loading ? (
                                <div className="client__cart-summary--loading-meals-message">Loading meals...</div>
                            ) : meals.length > 0 ? (
                                meals.map((meal, index) => (
                                    <CartItem
                                        key={index}
                                        mealId={meal.mealId}
                                        mealName={meal.mealName}
                                        mealQuantity={meal.mealQuantity}
                                        modifiers={meal.modifiers}
                                        unitPrice={meal.unitPrice}
                                        onIncrement={() => incrementMealQuantity(index)}
                                        onDecrement={() => decrementMealQuantity(index)}
                                        onRemove={() => removeMeal(index)}
                                    />
                                ))
                            ) : (
                                <div className="client__cart-summary--empty-cart-message">Your cart is empty.</div>
                            )}
                        </div>
                    </div>
                    <div className="client__cart-summary--price-summary">
                        <h2>Total price</h2>
                        {meals.length > 0 && meals.map((meal, index) => (
                            <div key={index} className="client__cart-summary--order-item">
                            <span>
                                {meal.mealName} x {meal.mealQuantity}, Total: ${(meal.unitPrice * meal.mealQuantity).toFixed(2)}
                            </span>
                            </div>
                        ))}
                        <div className="client__cart-summary--total">
                            <strong>Total: ${totalPrice}</strong>
                        </div>
                        <div className="client__cart-summary--button-container">
                            <button className="client__cart-summary--back-to-menu-button"
                                    onClick={() => navigate('/menu')}>Back to Menu
                            </button>
                            <button className="client__cart-summary--cart-next-button"
                                    onClick={() => navigate('/order/table')} disabled={meals.length === 0}>Next
                            </button>
                        </div>
                    </div>
                    <div className="client__cart-summary--recommendations">
                        <h2>Recommended for You</h2>
                        {recommendations.map((item, index) => (
                            <div key={index} className="client__cart-summary--recommendation-item">
                                <div className="client__cart-summary--recommendation-detail">
                                    <strong>{item.name}</strong>
                                    <div>Price: ${item.price.toFixed(2)}</div>
                                </div>
                                <button className="client__cart-summary--add-to-cart-button"
                                        onClick={() => addRecommendationToCart(item)}>Add to Cart
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </>
    );
};

export default CartSummary;