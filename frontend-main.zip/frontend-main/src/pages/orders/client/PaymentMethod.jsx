import React, {useEffect, useState} from 'react';
import {useNavigate} from 'react-router-dom';
import './PaymentMethod.scss';

const PaymentMethod = () => {
    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };

    const navigate = useNavigate();
    const token = getToken();
    const [selectedPayment, setSelectedPayment] = useState(
        localStorage.getItem(`${token}_payment`) || null
    );

    const updatePaymentType = (payment) => {
        if (selectedPayment === payment) {
            setSelectedPayment(null);
            localStorage.removeItem(`${token}_payment`);
        } else {
            setSelectedPayment(payment);
            localStorage.setItem(`${token}_payment`, payment);
        }
    };

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, []);

    return (
        <div className="client__payment-method--wrapper">
            <div className="client__payment-method">
                <div className="client__payment-method--card">
                    <h2>Choose Payment Method</h2>
                    <div className="client__payment-method--buttons">
                        <button
                            className={`button large ${
                                selectedPayment === 'ON_SITE' ? 'selected' : ''
                            }`}
                            onClick={() => updatePaymentType('ON_SITE')}
                        >
                            On site
                        </button>
                        <button
                            className={`button large ${
                                selectedPayment === 'ONLINE' ? 'selected' : ''
                            }`}
                            onClick={() => updatePaymentType('ONLINE')}
                        >
                            Online
                        </button>
                    </div>
                    <div className="client__payment-method--payment-action-buttons"
                         style={{marginRight: '80px'}}>
                        <button
                            className="client__payment-method--payment-action-button wide"
                            onClick={() => navigate('/order/table')}
                        >
                            Go back
                        </button>
                        <button
                            className="client__payment-method--payment-action-button wide"
                            onClick={() => navigate('/order/summary')}
                            disabled={!selectedPayment}
                        >
                            Go to order summary
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PaymentMethod;
