import {Html5QrcodeScanner} from "html5-qrcode";
import {useEffect} from "react";
import "./QrCodeScanner.scss";

const QrCodeScanner = ({onScanSuccess, onClose}) => {
    useEffect(() => {
        const html5QrcodeScanner = new Html5QrcodeScanner("reader", {
            qrbox: {
                width: 500,
                height: 500,
            },
            fps: 5,
        });

        html5QrcodeScanner.render(
            (result) => {
                onScanSuccess(result);
                html5QrcodeScanner.clear();
            },
            (error) => console.warn("Scanning error:", error)
        );

        return () => {
            html5QrcodeScanner.clear().catch((err) =>
                console.error("Clear failed on unmount:", err)
            );
        };
    }, [onScanSuccess]);

    return (
        <div className="qr-code-scanner-container">
            <button onClick={onClose} className="close-scanner-button">Close Scanner</button>
            <div id="reader" className="qr-code-reader"></div>
        </div>
    );
};

export default QrCodeScanner;