import React, {useEffect} from 'react';
import {Link, useNavigate, useSearchParams} from 'react-router-dom';
import './OrderPaid.scss';

const OrderPaid = () => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const error = searchParams.get('error');

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, []);

    return (
        <div className="client__order-paid--wrapper">
            <div className={`client__order-paid--success`}>
                <div className={`client__order-paid--success-container`}>
                    {error ? (
                        <>
                            <h1>Order Payment Unsuccessful</h1>
                            <p>We encountered an error during your payment process.</p>
                        </>
                    ) : (
                        <>
                            <h1>Order Payment Successful</h1>
                            <p>Your order has been successfully paid. Thank you for your purchase!</p>
                        </>
                    )}
                    <Link to="/" className={`client__order-paid--success-link`}>Go to Home</Link>
                </div>
            </div>
        </div>
    );
};

export default OrderPaid;