import React, {useState, useEffect} from "react";
import {useNavigate} from "react-router-dom";
import "./TableChoice.scss";
import {getTables} from "../../../service/api/commonApi.js";
import QrCodeScanner from "./QrCodeScanner";
import {getTableById} from "../../../service/api/customerApi.js";

const TableChoice = () => {
    const [choice, setChoice] = useState(null);
    const [tables, setTables] = useState([]);
    const [selectedTable, setSelectedTable] = useState(null);
    const [loading, setLoading] = useState(false);
    const [showScanner, setShowScanner] = useState(false);
    const [scanResult, setScanResult] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, []);


    const handleScannerClose = () => {
        setShowScanner(false);  // Assuming this is the state controlling the scanner visibility
    };
    const getTablesFunction = async () => {
        setLoading(true);
        try {
            const response = await getTables();
            const data = await response.json();
            setTables(data.content);
        } catch (error) {
            console.error("Error fetching tables: ", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (choice === "onSite") {
            getTablesFunction();
        }
    }, [choice]);

    const updateSelectedTable = (id) => {
        setSelectedTable((prevSelectedTable) =>
            prevSelectedTable === id ? null : id
        );
    };

    const handleQrScan = async (result) => {
        const parsedResult = parseQrResult(result);
        if (parsedResult) {
            const tableResult = await getTableById(parsedResult);
            const tableResponse = await tableResult.json();
            const result = "Table: " + tableResponse.tableNumber + " Room: " + tableResponse.roomId;
            setScanResult(result);
            setSelectedTable(parsedResult);
        } else {
            console.error("Invalid QR Code format.");
        }
        setShowScanner(false);
    };

    const parseQrResult = (qrText) => {
        const match = qrText.match(/dinning_desk=(\d+)/);
        return match ? parseInt(match[1], 10) : null;
    };

    const closeModal = () => {
        setScanResult(null);
    };

    const goToPayment = () => {
        navigate("/payment");
    };

    const goToNextPage = () => {
        const token = getToken();
        const diningDesk = choice === "takeAway" ? 0 : selectedTable;
        localStorage.setItem(`${token}_dinning_desk`, diningDesk);

        const option = localStorage.getItem(`${token}_dinning_desk`);
        if (option === "0") {
            localStorage.setItem(`${token}_payment`, "ONLINE");
            navigate("/order/summary");
        } else {
            navigate("/payment");
        }
    };

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };

    const backToCart = () => {
        navigate("/cart/summary");
    };

    return (
        <div className={`client__place-choice--wrapper ${showScanner ? "scanner-active" : ""}`}>
            <div className="client__place-choice--card">
                <h2>Choose your dining preference</h2>
                <div className="client__place-choice--buttons">
                    <button
                        className={`client__place-choice--button large ${
                            choice === "onSite" ? "selected" : ""
                        }`}
                        onClick={() => setChoice("onSite")}
                    >
                        Dine In
                    </button>
                    <button
                        className={`client__place-choice--button large ${
                            choice === "takeAway" ? "selected" : ""
                        }`}
                        onClick={() => {
                            setChoice("takeAway");
                            setSelectedTable(null);
                        }}
                    >
                        Take Away
                    </button>
                </div>
            </div>

            {choice === "onSite" && (
                <>
                    {showScanner ? (
                        <QrCodeScanner onScanSuccess={handleQrScan} onClose={handleScannerClose}/>
                    ) : (
                        <div className="client__place-choice--tables-container">
                            <h3>Choose Your Table</h3>
                            <button
                                className="client__place-choice--scan-button"
                                onClick={() => setShowScanner(true)}
                            >
                                Scan QR Code
                            </button>
                            {loading ? (
                                <p>Loading tables...</p>
                            ) : tables.length > 0 ? (
                                <div className="client__place-choice--tables-grid">
                                    {tables.map((table) => (
                                        <div
                                            key={table.id}
                                            className={`client__place-choice--table-card ${
                                                selectedTable === table.id ? "selected" : ""
                                            }`}
                                            onClick={() => updateSelectedTable(table.id)}
                                        >
                                            <p className="client__place-choice--table-room">
                                                Table {table.tableNumber}
                                            </p>
                                            <p className="client__place-choice--table-room">
                                                Room {table.roomId}
                                            </p>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <p>No tables available.</p>
                            )}
                        </div>
                    )}
                </>
            )}

            <div className="client__place-choice--navigation-buttons">
                <button
                    className="client__place-choice--back-button"
                    onClick={backToCart}
                >
                    Back to Cart
                </button>
                <button
                    className="client__place-choice--next-button"
                    onClick={goToNextPage}
                    disabled={!choice || (choice === "onSite" && !selectedTable)}
                >
                    Next
                </button>
            </div>

            {scanResult && (
                <div className="client__place-choice--scan-result-window">
                    <div className="client__place-choice--scan-result-content">
                        <h2>Scan Successful!</h2>
                        <p>Scanned Table: {scanResult}</p>
                        <div className="client__place-choice--scan-result-buttons">
                            <button onClick={closeModal} className="client__place-choice--scan-back-button">
                                Back
                            </button>
                            <button onClick={goToPayment} className="client__place-choice--scan-next-button">
                                Go Next
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default TableChoice;