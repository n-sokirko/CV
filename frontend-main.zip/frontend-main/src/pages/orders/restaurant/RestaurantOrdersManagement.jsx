import React, {useEffect, useState} from 'react';
import './OrdersManagement.scss';
import OrderItem from "./../../../components/orders/restaurant/OrderItem.jsx";
import {getOrders, getMealById, getModifiableIngredientById} from "../../../service/api/restaurantApi.js";
import {useNavigate} from "react-router-dom";

const RestaurantOrdersManagement = () => {
    const [ordersData, setOrdersData] = useState([]);
    const [numberOfPages, setNumberOfPages] = useState(1);
    const [currentPage, setCurrentPage] = useState(0);
    const [loading, setLoading] = useState(true);
    const ordersPerPage = 12;

    const navigate = useNavigate();

    const renderPagination = () => {
        const pages = [];
        for (let i = 1; i <= numberOfPages; i++) {
            pages.push(
                <button
                    key={i}
                    className={`pagination-button ${i === currentPage + 1 ? 'active' : ''}`}
                    onClick={() => updateNumberOfPage(i)}
                >
                    {i}
                </button>
            );
        }
        return <div className="pagination-container">{pages}</div>;
    };

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const sessionStorageToken = sessionStorage.getItem('jwt_restaurant');
            if (!sessionStorageToken) {
                navigate('/restaurant/login');
            }
        };
        checkIfLoggedIn();
    }, [navigate]);

    const updateNumberOfPage = (pageNumber) => {
        setCurrentPage(pageNumber - 1);
    };

    const formatDate = (date, time) => {
        return `${date.getFullYear()}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')} ${time}`;
    };

    const fetchOrders = async () => {
        setLoading(true);
        try {
            const today = new Date();
            const startDate = formatDate(today, "00:00:01");
            const endDate = formatDate(today, "23:59:59");
            const response = await getOrders(currentPage, ordersPerPage, startDate, endDate);
            const result = await response.json();
            setNumberOfPages(result.totalPages);
            const orders = result.content;

            const ordersResult = [];

            for (const order of orders) {
                const tableNumber = order.dinningDeskId;

                const mealsResult = [];

                for (const orderedMeal of order.orderedMeals) {
                    const mealResponse = await getMealById(orderedMeal.mealId);
                    const mealResult = await mealResponse.json();
                    const mealName = mealResult.name;
                    const mealQuantity = orderedMeal.count;

                    const modificationsResult = [];

                    for (const modification of orderedMeal.modifications) {
                        const ingredientResponse = await getModifiableIngredientById(modification.modifiableIngredientId);
                        const ingredientResult = await ingredientResponse.json();
                        const ingredientName = ingredientResult.ingredient.name;
                        const baseCount = ingredientResult.baseCount;

                        const modificationCount = modification.count;

                        if (modificationCount > baseCount) {
                            const extraCount = modificationCount - baseCount;

                            modificationsResult.push({
                                name: ingredientName,
                                type: "extra",
                                count: extraCount
                            });
                        } else if (modificationCount < baseCount) {
                            const missingCount = baseCount - modificationCount;
                            modificationsResult.push({
                                name: ingredientName,
                                type: "missing",
                                count: missingCount
                            });
                        }
                    }

                    mealsResult.push({
                        name: `${mealQuantity} x ${mealName}`,
                        modifications: modificationsResult
                    });
                }

                ordersResult.push({
                    id: order.id,
                    table: tableNumber,
                    status: order.state,
                    items: mealsResult,
                    paymentType: order.paymentType
                });
            }

            setOrdersData(ordersResult);
        } catch (error) {
            console.error("Error fetching orders", error);
        }
        setLoading(false);
    };

    useEffect(() => {
        fetchOrders();
    }, [currentPage]);

    useEffect(() => {
        const intervalId = setInterval(() => {
            fetchOrders();
        }, 15000);

        return () => clearInterval(intervalId);
    }, [currentPage]);

    return (
        <div className="restaurant__orders--wrapper">
            {loading ? (
                <div className="common__menu-page--loading-meals-message">Loading orders...</div>
            ) : (
                <>
                    <div className="restaurant__orders--title">Orders Management</div>
                    {ordersData.length === 0 ? (
                        <div className="restaurant__orders--no-orders-message">No orders in progress</div>
                    ) : (
                        <div className="restaurant__orders--list-container">
                            {ordersData.map((order) => (
                                <OrderItem
                                    key={order.id}
                                    id={order.id}
                                    table={order.table}
                                    status={order.status}
                                    items={order.items}
                                    paymentType={order.paymentType}
                                    refreshOrders={fetchOrders}
                                />
                            ))}
                        </div>
                    )}
                    {renderPagination()}
                </>
            )}
        </div>
    );
};

export default RestaurantOrdersManagement;