import React, {useEffect, useState} from 'react';
import './OrdersManagement.scss';
import OrderItem from "./../../../components/orders/waiter/OrderItem.jsx";
import {useNavigate} from "react-router-dom";
import {getOrdersByWaiterId, getWaiterPersonalData} from "../../../service/api/waiterApi.js";

const WaiterAssignedOrdersManagement = () => {
    const navigate = useNavigate();
    const [ordersData, setOrdersData] = useState([]);
    const [numberOfPages, setNumberOfPages] = useState(1);
    const [currentPage, setCurrentPage] = useState(0);
    const [loading, setLoading] = useState(true);
    const ordersPerPage = 12;
    const [waiterId, setWaiterId] = useState(0);

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_waiter');
        const sessionStorageToken = sessionStorage.getItem('jwt_waiter');
        return sessionStorageToken || localStorageToken;
    };

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const sessionStorageToken = sessionStorage.getItem('jwt_waiter');
            if (!sessionStorageToken) {
                navigate('/waiter/login');
            }
        };
        checkIfLoggedIn();
    }, [navigate]);

    const updateNumberOfPage = (pageNumber) => {
        setCurrentPage(pageNumber - 1);
    };

    const formatDate = (date, time) => {
        return `${date.getFullYear()}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')} ${time}`;
    };

    const fetchOrders = async () => {
        setLoading(true);
        try {
            if (!waiterId) {
                const token = getToken();
                const waiterResponse = await getWaiterPersonalData(token);
                const waiterData = await waiterResponse.json();
                setWaiterId(waiterData.id);
            }

            const today = new Date();
            const startDate = formatDate(today, "00:00:01");
            const endDate = formatDate(today, "23:59:59");
            const response = await getOrdersByWaiterId(currentPage, ordersPerPage, waiterId, startDate, endDate);
            const result = await response.json();
            setNumberOfPages(result.totalPages);
            setOrdersData(result.content.map(order => ({
                ...order,
                items: [],
                table: null,
                room: null,
                totalPrice: null
            })));
        } catch (error) {
            console.error("Error fetching orders", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchOrders();
    }, [currentPage, waiterId]);

    useEffect(() => {
        const intervalId = setInterval(() => {
            if (waiterId) {
                fetchOrders();
            }
        }, 15000);
        return () => clearInterval(intervalId);
    }, [waiterId]);

    const renderPagination = () => {
        const pages = [];
        for (let i = 1; i <= numberOfPages; i++) {
            pages.push(
                <button
                    key={i}
                    className={`pagination-button ${i === currentPage + 1 ? 'active' : ''}`}
                    onClick={() => updateNumberOfPage(i)}
                >
                    {i}
                </button>
            );
        }
        return <div className="pagination-container">{pages}</div>;
    };

    return (
        <div className="client-orders-wrapper">
            <div className="waiter__orders--title">Unassigned Orders Management</div>
            <div className="waiter__orders--filter-buttons">
                <button
                    className="waiter__orders--filter-button"
                    onClick={() => navigate('/waiter/orders/unassigned')}
                >
                    Show Unassigned Orders
                </button>
                <button
                    className="waiter__orders--filter-button"
                    onClick={() => navigate('/waiter/orders/assigned')}
                >
                    Show My Orders
                </button>
            </div>
            {loading ? (
                <div className="loading-message">Loading orders...</div>
            ) : ordersData.length === 0 ? (
                <div className="no-orders-message">No orders found</div>
            ) : (
                <>
                    <div className="client-orders-list-container">
                        {ordersData.map((order) => (
                            <OrderItem
                                key={order.id}
                                order={order}
                                fetchDetails={true}
                                refreshOrders={fetchOrders}
                            />
                        ))}
                    </div>
                    {renderPagination()}
                </>
            )}
        </div>
    );
};

export default WaiterAssignedOrdersManagement;