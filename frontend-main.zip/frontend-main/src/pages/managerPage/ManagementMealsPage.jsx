import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ManagerNavbar from '../../components/navbar/ManagerNavbar'; 
import AddMeal from '../../components/manager/meal/AddMeal';
import AddAllergen from '../../components/manager/allergen/AddAllergen';
import ViewAllergen from '../../components/manager/allergen/ViewAllergen';  
import ViewMeal from '../../components/manager/meal/ViewMeal';
import AddDiet from '../../components/manager/diet/AddDiet';
import DietList from '../../components/manager/diet/DietList';
import AddIngredient from '../../components/manager/ingredient/AddIngredient';
import ViewIngredient from '../../components/manager/ingredient/ViewIngredient';
import AddCategory from '../../components/manager/category/AddCategory';
import ViewCategory from '../../components/manager/category/ViewCategory';
import AddSubcategory from '../../components/manager/subcategory/AddSubcategory';
import ViewSubcategory from '../../components/manager/subcategory/ViewSubcategory';
import EditMeal from '../../components/manager/meal/EditMeal';
import './ManagementMealsPage.scss';

const ManagementMealsPage = () => {
    const navigate = useNavigate();
    const [activeComponent, setActiveComponent] = useState(null); 
    const [selectedMealId, setSelectedMealId] = useState(null);

    useEffect(() => {
        const token = sessionStorage.getItem('jwt_manager');
        if (!token) {
            navigate('/manager/login'); 
        }
    }, [navigate]);

    const handleComponentClick = (component) => {
        setActiveComponent(component);
    };

    const handleMealSelect = (mealId) => {
        setSelectedMealId(mealId);
        setActiveComponent('editMeal');
    };

    return (
        <div className="management-page">
            <ManagerNavbar />
            <h1 className="manager-home-title">Manager Dashboard</h1>

            <div className="management-sections">
                <div className="card">
                    <h2>Dishes</h2>
                    <button onClick={() => handleComponentClick('addMeal')} className="card-button">
                        Add Meal
                    </button>
                    <button onClick={() => handleComponentClick('viewMeals')} className="card-button">
                        View Meals
                    </button>
                    <button onClick={() => handleComponentClick('addCategory')} className="card-button">
                        Add Category
                    </button>
                    <button onClick={() => handleComponentClick('viewCategories')} className="card-button">
                        View Categories
                    </button>
                    <button onClick={() => handleComponentClick('addSubcategory')} className="card-button">
                        Add Subcategory
                    </button>
                    <button onClick={() => handleComponentClick('viewSubcategories')} className="card-button">
                        View Subcategories
                    </button>  
                </div>

                <div className="card">
                    <h2>Ingredients & Allergens</h2>
                    <button onClick={() => handleComponentClick('addIngredient')} className="card-button">
                        Add Ingredient
                    </button>
                    <button onClick={() => handleComponentClick('viewIngredients')} className="card-button">
                        View Ingredients
                    </button>
                    <button onClick={() => handleComponentClick('addAllergen')} className="card-button">
                        Add Allergen
                    </button>
                    <button onClick={() => handleComponentClick('viewAllergens')} className="card-button">
                        View Allergens
                    </button> 
                </div>

                <div className="card">
                    <h2>Diets</h2>
                    <button onClick={() => handleComponentClick('addDiet')} className="card-button">
                        Add Diet
                    </button>
                    <button onClick={() => handleComponentClick('viewDiets')} className="card-button">
                        View Diets
                    </button>
                </div>
            </div>

            <div className="component-display">
                {activeComponent === 'addMeal' && <AddMeal />}
                {activeComponent === 'addAllergen' && <AddAllergen />}
                {activeComponent === 'viewAllergens' && <ViewAllergen />}
                {activeComponent === 'viewMeals' && <ViewMeal onMealSelect={handleMealSelect} />}
                {activeComponent === 'addDiet' && <AddDiet />}
                {activeComponent === 'viewDiets' && <DietList />}
                {activeComponent === 'addIngredient' && <AddIngredient />}
                {activeComponent === 'viewIngredients' && <ViewIngredient />}
                {activeComponent === 'addCategory' && <AddCategory />}
                {activeComponent === 'viewCategories' && <ViewCategory />}
                {activeComponent === 'addSubcategory' && <AddSubcategory />}
                {activeComponent === 'viewSubcategories' && <ViewSubcategory />}
                {activeComponent === 'editMeal' && selectedMealId && (
                    <EditMeal mealId={selectedMealId} onClose={() => setActiveComponent('viewMeals')} />
                )}
            </div>
        </div>
    );
};

export default ManagementMealsPage;
