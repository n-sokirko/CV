import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import RestaurantScheduleForm from '../../components/manager/restaurant-configuration/RestaurantScheduleForm';
import ManagerNavbar from '../../components/navbar/ManagerNavbar'; 
const RestaurantConfigurationPage = () => {
    const navigate = useNavigate();

    useEffect(() => {
        const token = sessionStorage.getItem('jwt_manager');
        if (!token) {
            navigate('/manager/login');
        }
    }, [navigate]);

    return   (
        <div>
            <ManagerNavbar />
            <h1>Restaurant Configuration</h1>
            <RestaurantScheduleForm/>
        </div>  
    );
}

export default RestaurantConfigurationPage;