import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ReservationReportGenerator from '../../components/manager/reportGeneration/ReservationReportGenerator';
import OrderReportGenerator from '../../components/manager/reportGeneration/OrderReportGenerator';
import './ReportGenerationPage.scss';
import ManagerNavbar from '../../components/navbar/ManagerNavbar';

const ReportGenerationPage = () => {
  const [activeReport, setActiveReport] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const token = sessionStorage.getItem('jwt_manager');
    if (!token) {
      navigate('/manager/login');
    }
  }, [navigate]);

  return (
    <div className="manager__report-generation-page">
      <ManagerNavbar />
      <h1 className="manager__report-generation-page--title">Report Generation Page</h1>

      <div className="manager__report-generation-page--tabs">
        <button
          className={`manager__report-generation-page--tab-button ${
            activeReport === 'reservations' ? 'manager__report-generation-page--tab-button-active' : ''
          }`}
          onClick={() => setActiveReport('reservations')}
        >
          Reservations Reports
        </button>
        <button
          className={`manager__report-generation-page--tab-button ${
            activeReport === 'orders' ? 'manager__report-generation-page--tab-button-active' : ''
          }`}
          onClick={() => setActiveReport('orders')}
        >
          Orders Reports
        </button>
      </div>

      <div className="manager__report-generation-page--container">
        {activeReport === null && (
          <div className="manager__report-generation-page--no-report">
            <h2>Select a report to view</h2>
          </div>
        )}
        {activeReport === 'reservations' && (
          <div className="manager__report-generation-page--report-content">
            <h2>Reservations Reports</h2>
            <ReservationReportGenerator goBack={() => setActiveReport(null)} />
          </div>
        )}
        {activeReport === 'orders' && (
          <div className="manager__report-generation-page--report-content">
            <h2>Orders Reports</h2>
            <OrderReportGenerator goBack={() => setActiveReport(null)} />
          </div>
        )}
      </div>
    </div>
  );
};

export default ReportGenerationPage;
