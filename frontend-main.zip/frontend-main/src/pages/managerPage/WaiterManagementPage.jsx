import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

import ManagerNavbar from '../../components/navbar/ManagerNavbar';
import WaiterManagement from '../../components/manager/waiterManagement/WaiterManagement';

const WaiterManagementPage = () => {
 
  const navigate = useNavigate();

  useEffect(() => {
    const token = sessionStorage.getItem('jwt_manager');
    if (!token) {
      navigate('/manager/login');
    }
  }, [navigate]);
  return (
   <div className="">
    <ManagerNavbar/>
    <WaiterManagement />
    </div>
  );
};

export default WaiterManagementPage;
