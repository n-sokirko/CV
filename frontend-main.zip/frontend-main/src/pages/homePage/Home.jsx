import React, { useEffect, useState } from 'react';
import CompletePersonalData from "../../components/authentication/verification/CompletePersonalData.jsx";
import { getPersonalData } from "../../service/api/customerApi.js";
import { useLocation, useNavigate } from "react-router-dom";
import './Home.scss';

const Home = () => {
    const [userData, setUserData] = useState({});
    const [isPersonalDataCompleted, setPersonalDataCompleted] = useState(false);
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [currentCardIndex, setCurrentCardIndex] = useState(0);

    const location = useLocation();
    const navigate = useNavigate();

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (sessionStorageToken || localStorageToken) {
                setIsLoggedIn(true);
            }
        };
        checkIfLoggedIn();
    }, []);

    useEffect(() => {
        const checkIfPersonalDataIsCompleted = async () => {
            const token = sessionStorage.getItem("jwt_client");
            if (!token) return;

            try {
                const response = await getPersonalData(token);
                const data = await response.json();
                setUserData(data);
                setPersonalDataCompleted(data.email !== "" && data.name !== "" && data.phone !== "");
            } catch (error) {
                console.error("Error fetching personal data:", error);
                setPersonalDataCompleted(false);
            }
        };

        if (isLoggedIn && (location.state?.refreshData || !userData.name)) {
            checkIfPersonalDataIsCompleted();
        }
    }, [isLoggedIn, location.state, userData.name]);

    const cards = [
        {
            title: "Create Your Perfect Meal Today!",
            description: "Place your order now and customize your meal just the way you like it! Modify ingredients, explore our recommendations, and create the perfect dish for your taste.",
            path: "/cart/summary",
            buttonText: "Place order"
        },
        {
            title: "Book a table now!",
            description: "Book your table now! Choose the perfect spot using our virtual seating panel, accurately reflecting the real layout. Not sure which table to pick? Let our recommendations guide you to the best choice!",
            path: "/reservation",
            buttonText: "Book a table"
        },
        {
            title: "Discover Your Perfect Meal!",
            description: "Explore our menu with ease! View detailed ingredient lists, allergen information, and calorie counts for each dish. Use our filtering options to quickly find exactly what you're looking for and enjoy a seamless dining experience.",
            path: "/menu",
            buttonText: "Explore menu"
        },
        {
            title: "Your Diet, Your Menu!",
            description: "Enjoy a personalized menu experience! Whether you're vegetarian, keto, or follow another dietary lifestyle, we've got you covered. Simply update your profile with your dietary preferences, and explore meals tailored to your needs in your personalized menu. Finding the perfect dish has never been easier!",
            path: "/account",
            buttonText: "View my account"
        }
    ];

    const navigateCards = (direction) => {
        setCurrentCardIndex(previous => {
            let newIndex = previous + direction;
            if (newIndex < 0) {
                newIndex = cards.length - 2;
            } else if (newIndex > cards.length - 2) {
                newIndex = 0;
            }
            return newIndex;
        });
    };

    const renderCards = () => {
        if (window.innerWidth <= 768) {
            const card = cards[currentCardIndex];
            return (
                <div className="common__home--card-content">
                    <h1>{card.title}</h1>
                    <p>{card.description}</p>
                    <button onClick={() => navigate(card.path)}>{card.buttonText}</button>
                </div>
            );
        } else {
            return Array.from({ length: 2 }).map((_, index) => {
                const card = cards[(currentCardIndex + index) % cards.length];
                return (
                    <div key={index} className="common__home--card-content">
                        <h1>{card.title}</h1>
                        <p>{card.description}</p>
                        <button onClick={() => navigate(card.path)}>{card.buttonText}</button>
                    </div>
                );
            });
        }
    };

    if (!isLoggedIn) {
        return (
            <div className="common__home--wrapper">
                <div className="common__home--welcome-message">
                    <p>Start Your Culinary Adventure With Us!</p>
                </div>
                <div className="common__home--cards-section">
                    <button onClick={() => navigateCards(-1)} className="common__home--arrow left">{"<"}</button>
                    <div className="common__home--card-item">
                        {renderCards()}
                    </div>
                    <button onClick={() => navigateCards(1)} className="common__home--arrow right">{">"}</button>
                </div>
            </div>
        );
    }

    if (!isPersonalDataCompleted) {
        return(
        <div className="common__home--wrapper">
        <CompletePersonalData userData={userData} />
        </div>
        );
    }

    return (
        <div className="common__home--wrapper">
            <div className="common__home--welcome-message">
                <p>Start Your Culinary Adventure With Us!</p>
            </div>
            <div className="common__home--cards-section">
                <button onClick={() => navigateCards(-1)} className="common__home--arrow left">{"<"}</button>
                <div className="common__home--card-item">
                    {renderCards()}
                </div>
                <button onClick={() => navigateCards(1)} className="common__home--arrow right">{">"}</button>
            </div>
        </div>
    );
};

export default Home;