import React, { useEffect } from 'react';
import RoomLayoutManager from '../../components/table-arrangement/RoomLayoutManager.jsx';
import { useNavigate } from 'react-router-dom';

const ManagerHome = () => {
    const navigate = useNavigate();

    useEffect(() => {
        const token = sessionStorage.getItem('jwt_manager');
        if (!token) {
            navigate('/manager/login');
        }
    }, [navigate]);

    return (
        <div>
            <h1 style={{ marginTop: '100px' }}>Manager Home</h1>
        
        </div>
    );
}

export default ManagerHome;