import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const RestaurantHome = () => {
    const navigate = useNavigate();

    useEffect(() => {
        const token = sessionStorage.getItem('jwt_restaurant');
        if (!token) {
            navigate('/restaurant/login');
        }
    }, [navigate]);

    return <h1 style={{ marginTop: '100px' }}>Restaurant Home</h1>;
}

export default RestaurantHome;