import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const WaiterHome = () => {
    const navigate = useNavigate();

    useEffect(() => {
        const token = sessionStorage.getItem('jwt_waiter');
        if (!token) {
            navigate('/waiter/login');
        }
    }, [navigate]);

    return <h1 style={{ marginTop: '100px' }}>Waiter Home</h1>;
}

export default WaiterHome;