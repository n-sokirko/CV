import React from 'react'
import ReactDOM from 'react-dom/client'

import {
    RouterProvider,
    createBrowserRouter
} from 'react-router-dom'

import App from './App'
import Home from './pages/homePage/Home'
import Register from './pages/authentication/Register'
import {RestaurantLoginForm} from './components/authentication/login/RestaurantLoginForm.jsx'
import ManagerHome from "./pages/homePage/ManagerHome.jsx";
import ConfirmUserViaGoogle from "./components/authentication/verification/ConfirmUserViaGoogle.jsx";
import ConfirmUserViaFacebook from "./components/authentication/verification/ConfirmUserViaFacebook.jsx";
import ActivateAccountInfo from "./components/authentication/verification/ActivateAccountInfo.jsx";
import {ManagerLoginForm} from "./components/authentication/login/ManagerLoginForm.jsx";
import {WaiterLoginForm} from "./components/authentication/login/WaiterLoginForm.jsx";
import {CustomerLoginForm} from "./components/authentication/login/CustomerLoginForm.jsx";
import ItemsPage from "./pages/menu/ItemsPage.jsx";
import IngredientsManagement from "./pages/restaurant/IngredientsManagement.jsx";
import {EnterEmail} from "./components/authentication/passwordReset/EnterEmail.jsx";
import {PasswordReset} from "./components/authentication/passwordReset/PasswordReset.jsx";
import ResetSuccess from "./components/authentication/passwordReset/ResetSuccess.jsx";
import SentEmail from "./components/authentication/passwordReset/SentEmail.jsx";
import AccountPage from "./pages/personalData/AccountPage.jsx";
import CartSummary from "./pages/orders/client/CartSummary.jsx";
import TableChoice from "./pages/orders/client/TableChoice.jsx";
import PaymentMethod from "./pages/orders/client/PaymentMethod.jsx";
import OrderPaid from "./pages/orders/client/OrderPaid.jsx";
import OrderSummary from "./pages/orders/client/OrderSummary.jsx";
import ReservationManagement from "./pages/reservations/waiter/ReservationManagement.jsx";
import RestaurantOrdersManagement from "./pages/orders/restaurant/RestaurantOrdersManagement.jsx";
import WaiterOrdersManagement from "./pages/orders/waiter/WaiterOrdersManagement.jsx";
import {PasswordChange} from "./components/authentication/passwordChange/PasswordChange.jsx";
import ChangeSuccess from "./components/authentication/passwordChange/ChangeSuccess.jsx";
import ContactForm from "./pages/contact/ContactForm.jsx";
import ReservationRoomChoice from "./components/reservations/client/ReservationRoomChoice.jsx";
import ReservationForm from "./components/reservations/client/ReservationForm.jsx";
import ReservationSummary from "./components/reservations/client/ReservationSummary.jsx";
import OrdersHistory from "./pages/personalData/history/OrdersHistory.jsx";
import ReservationsHistory from "./pages/personalData/history/ReservationsHistory.jsx";
import WaiterManagementPage from "./pages/managerPage/WaiterManagementPage.jsx";
import ClientMenuPage from "./pages/menu/ClientMenuPage.jsx";
import QrCodeScanner from "./pages/orders/client/QrCodeScanner.jsx";
import ManagementMealsPage from './pages/managerPage/ManagementMealsPage.jsx'
import WaiterAssignedOrdersManagements from "./pages/orders/waiter/WaiterAssignedOrdersManagement.jsx";
import TableArrangementPage from "./pages/managerPage/TableArrangementPage.jsx";
import ReportGenerationPage from './pages/managerPage/ReportGenerationPage.jsx'
import RestaurantConfigurationPage from './pages/managerPage/RestaurantConfigurationPage.jsx';
import WaiterHome from "./pages/homePage/WaiterHome.jsx";
import RestaurantHome from "./pages/homePage/RestaurantHome.jsx";


const router = createBrowserRouter([
    {
        path: '/',
        element: <App/>,
        children: [
            {
                path: '/',
                element: <Home/>,
            },
            {
                path: '/manager',
                element: <ManagerHome/>
            },
            {
                path: '/restaurant',
                element: <RestaurantHome/>
            },
            {
                path: '/waiter',
                element: <WaiterHome/>
            },
            {
                path: '/register',
                element: <Register/>,
            },
            {
                path: '/login',
                element: <CustomerLoginForm/>,
            },
            {
                path: '/manager/login',
                element: <ManagerLoginForm/>,
            }, {
                path: '/waiter/login',
                element: <WaiterLoginForm/>,
            },
            {
                path: '/restaurant/login',
                element: <RestaurantLoginForm/>
            },
            {
                path: '/authenticate/google',
                element: <ConfirmUserViaGoogle/>
            },
            {
                path: '/authenticate/facebook',

                element: <ConfirmUserViaFacebook/>
            },
            {
                path: '/activateAccount',
                element: <ActivateAccountInfo/>
            },
            {
                path: '/menu',
                element: <ItemsPage/>
            },
            {
                path: '/contact',
                element: <ContactForm/>
            },
            {
                path: '/restaurant/orders',
                element: <RestaurantOrdersManagement/>
            },
            {
                path: '/waiter/reservations',
                element: <ReservationManagement/>
            },
            {
                path: '/restaurant/ingredients',
                element: <IngredientsManagement/>
            },
            {
                path: '/tables',
                element: <ReservationRoomChoice/>
            },
            {
                path: '/reservation',
                element: <ReservationForm/>
            },
            {
                path: '/reservation/summary',
                element: <ReservationSummary/>
            },
            {
                path: '/password/reset',
                element: <EnterEmail/>
            },
            {
                path: '/password/reset/confirm',
                element: <SentEmail/>
            },
            {
                path: '/password-setup',
                element: <PasswordReset/>
            },
            {
                path: '/password/reset/success',
                element: <ResetSuccess/>
            },
            {
                path: '/account',
                element: <AccountPage/>
            },
            {
                path: '/password/change',
                element: <PasswordChange/>
            },
            {
                path: '/password/change/success',
                element: <ChangeSuccess/>
            },
            {
                path: '/cart/summary',
                element: <CartSummary/>
            },
            {
                path: '/order/table',
                element: <TableChoice/>
            },
            {
                path: '/order/summary',
                element: <OrderSummary/>
            },
            {
                path: '/payment',
                element: <PaymentMethod/>
            },
            {
                path: '/order/success',
                element: <OrderPaid/>
            },
            {
                path: '/reportgeneration',
                element: <ReportGenerationPage/>
            },
            {
                path: '/waiter/orders/assigned',
                element: <WaiterAssignedOrdersManagements/>
            },
            {
                path: '/waiter/orders/unassigned',
                element: <WaiterOrdersManagement/>
            },
            {
                path: '/menu/client',
                element: <ClientMenuPage/>
            },

            {
                path: '/account/orders',
                element: <OrdersHistory/>
            },
            {
                path: '/account/reservations',
                element: <ReservationsHistory/>
            },
            {
                path: '/code',
                element: <QrCodeScanner/>
            },
            {
                path: '/management-meals',
                element: <ManagementMealsPage/>
            },
            {
                path: 'restaurant-configuration',
                element: <RestaurantConfigurationPage/>
            },
            {
                path: '/table-arrangement',
                element: <TableArrangementPage/>
            },
            {   path: '/waiter-management',
                element: <WaiterManagementPage/>
            }
        ]
    }]
);

ReactDOM.createRoot(document.getElementById('root')).render(
    <RouterProvider router={router}>
        <App/>
    </RouterProvider>
)