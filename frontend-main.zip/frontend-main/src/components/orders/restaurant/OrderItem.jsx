import React from "react";
import './OrderItem.scss';
import { updateOrderState } from "../../../service/api/restaurantApi.js";

const OrderItem = ({ id, table, status, items, paymentType, refreshOrders }) => {
    const completeOrder = async () => {
        try {
            const newState = table == null ? "preparation_takeaway" : "preparation_on_site";
            await updateOrderState(id, newState);
            refreshOrders();
        } catch (error) {
            console.error(`Error completing order ${id}:`, error);
        }
    };

    const cancelOrder = async () => {
        try {
            const event = paymentType === "ONLINE" ? "cancel" : "abort";
            await updateOrderState(id, event);
            refreshOrders();
        } catch (error) {
            console.error(`Error cancelling order ${id}:`, error);
        }
    };

    return (
        <div className="restaurant__order-item">
            <span className={`restaurant__order-item--order-status-label
            ${status.toLowerCase().replace("_", "-")}`}>
                {status.replace("_", " ")}
            </span>
            <div className="restaurant__order-item--order-details">
                <h5 className="restaurant__order-item--order-id">Order ID: {id}</h5>
                <div className="restaurant__order-item--ordered-items-section">
                    <div className="restaurant__order-item--ordered-items-list">
                        <ul>
                            {items.map((item, index) => (
                                <li key={index} className="restaurant__order-item--ordered-item">
                                    <div className="restaurant__order-item--info">
                                        <span>{item.name}</span>
                                    </div>
                                    {item.modifications.length > 0 && (
                                        <div className="restaurant__order-item--order-modifications">
                                            {item.modifications.map((modification, index) => (
                                                <span key={index}>
                                                    {modification.type === "extra" ? (
                                                        `+${modification.count} extra ${modification.name}`
                                                    ) : (
                                                        `-${modification.count} less ${modification.name}`
                                                    )}
                                                </span>
                                            ))}
                                        </div>
                                    )}
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
                <div className="restaurant__order-item--order-buttons">
                    {status === "IN_PROGRESS" && (
                        <button
                            className="restaurant__order-item--cancel-button"
                            onClick={cancelOrder}
                        >
                            {paymentType === "ONLINE" ? "Cancel" : "Abort"}
                        </button>
                    )}
                    <button className="restaurant__order-item--order-more-button" onClick={completeOrder}>Complete</button>
                </div>
            </div>
        </div>
    );
};

export default OrderItem;