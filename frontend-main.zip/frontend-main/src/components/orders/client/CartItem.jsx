import React, {useState} from 'react';
import {FaPlus, FaMinus} from 'react-icons/fa';
import './CartItem.scss';

const CartItem = ({mealId, mealName, mealQuantity, modifiers, unitPrice, onIncrement, onDecrement, onRemove}) => {
    const [showConfirmation, setShowConfirmation] = useState(false);

    const decrementMealQuantity = () => {
        if (mealQuantity === 1) {
            setShowConfirmation(true);
        } else {
            onDecrement();
        }
    };

    const confirmRemove = () => {
        onRemove();
        setShowConfirmation(false);
    };

    const cancelRemove = () => {
        setShowConfirmation(false);
    };

    return (
        <div className="client__cart-item">
            <div className="client__cart-item--cart-item-details">
                <div className="client__cart-item--cart-item-header">
                    <div className="client__cart-item--cart-item-info">
                        <h5 className="client__cart-item--cart-item-name">{mealName}</h5>
                        {modifiers && modifiers.length > 0 && (
                            <div className="client__cart-item--cart-item-modifications">
                                {modifiers.map((modifier, index) => (
                                    <div key={index} className="client__cart-item--cart-item-modification">
                                        {modifier.count}x {modifier.name}
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                    <span className="client__cart-item--cart-item-price">${(unitPrice * mealQuantity).toFixed(2)}</span>
                </div>
                <div className="client__cart-item--cart-item-actions">
                    <div className="client__cart-item--cart-item-controls">
                        <FaMinus className="client__cart-item--control-icon" onClick={decrementMealQuantity}/>
                        <span className="client__cart-item--cart-item-quantity">{mealQuantity}</span>
                        <FaPlus className="client__cart-item--control-icon" onClick={onIncrement}/>
                    </div>
                </div>
            </div>
            {showConfirmation && (
                <div className="client__cart-item--cart-confirmation-overlay">
                    <div className="client__cart-item--cart-confirmation-dialog">
                        <p>Are you sure you want to remove this item from the cart?</p>
                        <button className="client__cart-item--cart-confirm-button" onClick={confirmRemove}>
                            Yes
                        </button>
                        <button className="client__cart-item--cart-cancel-button" onClick={cancelRemove}>
                            No
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default CartItem;
