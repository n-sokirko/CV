import React, {useState, useEffect} from "react";
import './ReservationItem.scss';
import {getTableById} from "../../../service/api/waiterApi.js";
import {updateReservationState} from "../../../service/api/customerApi.js";

const ReservationItem = ({
                             id,
                             date,
                             startTime,
                             endTime,
                             diningDeskIds,
                             notes,
                             status,
                             numberOfGuests,
                             refreshReservations
                         }) => {
    const [isMoreDisplayed, setMoreVisible] = useState(false);
    const [tablesDetails, setTablesDetails] = useState([]);
    const [isCancellationAllowed, setIsCancellationAllowed] = useState(true);
    const [showConfirmation, setShowConfirmation] = useState(false);

    const displayDetails = () => {
        if (showConfirmation) {
            setShowConfirmation(false);
        }
        setMoreVisible(!isMoreDisplayed);
    };

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };

    const updateReservationStateToCancelled = async () => {
        const token = getToken();
        await updateReservationState(id, token);
        refreshReservations();
        setShowConfirmation(true);
    };

    const checkCancellationAllowed = () => {
        const now = new Date();
        const reservationDate = new Date(date);

        reservationDate.setDate(reservationDate.getDate() - 1);
        reservationDate.setHours(23, 59, 59, 999);

        setIsCancellationAllowed(now <= reservationDate);
    };

    useEffect(() => {
        const getTablesDetails = async () => {
            const details = await Promise.all(diningDeskIds.map(async (tableId) => {
                try {
                    const response = await getTableById(tableId);
                    const data = await response.json();
                    return `Room Number: ${data.roomId}, Table Number: ${data.tableNumber}`;
                } catch (error) {
                    console.error('Failed to get table details:', error);
                    return 'Fetching failed';
                }
            }));
            setTablesDetails(details);
        };

        getTablesDetails();
        checkCancellationAllowed();
    }, [diningDeskIds, date]);

    return (
        <div className="client-reservation-item">
            <span className={`client-reservation-status-label ${status.toLowerCase()}`}>{status}</span>
            <div className="client-reservation-details">
                <div className="client-reservation-client-name">Reservation ID: {id}</div>
                <div>Date: {date}</div>
                <div>Time: {startTime} - {endTime}</div>
                <div className="client-reservation-buttons">
                    <button className="client-reservation-more-button" onClick={displayDetails}>More</button>
                </div>
            </div>
            {isMoreDisplayed && (
                <div className="client-reservation-more-info-window">
                    <div className="client-reservation-window-content">
                        <div className="client-reservation-details-section">
                            <h4>Reservation Details</h4>
                            <div>Reservation ID: {id}</div>
                            <div>Tables: <div
                                className="client-reservation-tables-list">{tablesDetails.map((table, index) => <div
                                key={index}>{table}</div>)}</div></div>
                            <div>Number of Guests: {numberOfGuests}</div>
                            <div>Additional info: {notes || "None"}</div>
                        </div>
                    </div>
                    <div className="client-reservation-buttons-section">
                        <button className="client-reservation-window-button" onClick={displayDetails}>Close</button>
                        {status === "CONFIRMED" && (
                            <button
                                className="client-reservation-window-button mark-cancelled"
                                onClick={updateReservationStateToCancelled}
                                disabled={!isCancellationAllowed}
                            >
                                Cancel reservation
                            </button>
                        )}
                    </div>
                    {showConfirmation && (
                        <div className="client-reservation-confirmation-message">
                            <p>Confirmation email has been sent.</p>
                            <button className="client-reservation-window-button" onClick={() => {
                                setShowConfirmation(false);
                                setMoreVisible(false);
                            }}>Go Back to Reservations
                            </button>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default ReservationItem;