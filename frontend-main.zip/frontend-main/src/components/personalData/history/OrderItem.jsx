import React, {useState} from "react";
import './OrderItem.scss';
import {
    getMealById,
    getModifiableIngredientById,
    getTableById,
    getRoomById,
} from "../../../service/api/customerApi.js";

const OrderItem = ({order, fetchDetails}) => {
    const [isMoreDisplayed, setMoreVisible] = useState(false);
    const [detailsLoaded, setDetailsLoaded] = useState(false);
    const [details, setDetails] = useState({
        items: [],
        totalPrice: 0,
        table: null,
        room: null
    });

    const displayDetails = async () => {
        if (!detailsLoaded && fetchDetails) {
            setMoreVisible(!isMoreDisplayed);
            if (!isMoreDisplayed) {
                try {
                    const tableResponse = await getTableById(order.dinningDeskId);
                    const tableResult = tableResponse ? await tableResponse.json() : null;
                    const tableNumber = tableResult ? tableResult.tableNumber : null;

                    const roomResponse = tableResult && tableResult.roomId ? await getRoomById(tableResult.roomId) : null;
                    const roomResult = roomResponse ? await roomResponse.json() : null;
                    const roomNumber = roomResult ? roomResult.id : null;

                    let totalPrice = 0;
                    const mealsResult = [];

                    for (const orderedMeal of order.orderedMeals) {
                        const mealResponse = await getMealById(orderedMeal.mealId);
                        const mealResult = await mealResponse.json();
                        const mealName = mealResult.name;
                        const mealPrice = mealResult.price;
                        const mealQuantity = orderedMeal.count;
                        let mealTotalPrice = mealPrice * mealQuantity;

                        const modificationsResult = [];

                        for (const modification of orderedMeal.modifications) {
                            const ingredientResponse = await getModifiableIngredientById(modification.modifiableIngredientId);
                            const ingredientResult = await ingredientResponse.json();
                            const ingredientName = ingredientResult.ingredient.name;
                            const baseCount = ingredientResult.baseCount;
                            const unitPrice = ingredientResult.price;
                            const modificationCount = modification.count;

                            if (modificationCount > baseCount) {
                                const extraCount = modificationCount - baseCount;
                                const extraCost = extraCount * unitPrice;
                                mealTotalPrice += extraCost * mealQuantity;
                                modificationsResult.push({
                                    name: ingredientName,
                                    type: "extra",
                                    count: extraCount,
                                    unitPrice: unitPrice.toFixed(2),
                                });
                            } else if (modificationCount < baseCount) {
                                const missingCount = baseCount - modificationCount;
                                modificationsResult.push({
                                    name: ingredientName,
                                    type: "missing",
                                    count: missingCount,
                                    unitPrice: unitPrice.toFixed(2),
                                });
                            }
                        }

                        totalPrice += mealTotalPrice;

                        mealsResult.push({
                            name: `${mealQuantity} x ${mealName}`,
                            price: mealPrice,
                            total: mealTotalPrice,
                            modifications: modificationsResult,
                        });
                    }

                    setDetails({
                        items: mealsResult,
                        totalPrice: totalPrice.toFixed(2),
                        table: tableNumber,
                        room: roomNumber
                    });
                    setDetailsLoaded(true);
                } catch (error) {
                    console.error("Error fetching order details", error);
                }
            }
        } else {
            setMoreVisible(!isMoreDisplayed);
        }
    };

    const convertPaymentMethod = (method) => {
        return method === "ON_SITE" ? "On Site" : "Online";
    };

    return (
        <div className="client-order-item">
            <span className={`client-order-status-label ${order.state.toLowerCase().replace("_", "-")}`}>
                {order.state.replace("_", " ")}
            </span>
            <div className="client-order-details">
                <h5 className="client-order-id">Order ID: {order.id}</h5>
                <p>Payment: {convertPaymentMethod(order.paymentType)}</p>
                <p>Order Date: {(order.createdAt).slice(0, 10)}</p>
                <div className="client-order-buttons">
                    <button className="client-order-more-button" onClick={displayDetails}>Details</button>
                </div>
            </div>
            {isMoreDisplayed && (
                <div className="client-order-more-info-window">
                    <div className="client-order-window-content">
                        <div className="client-order-details-section">
                            <h4>Order Details</h4>
                            <p>Order ID: {order.id}</p>
                            {details.table && details.room ? (
                                <>
                                    <p>Room: {details.room}</p>
                                    <p>Table: {details.table}</p>
                                </>
                            ) : (
                                <p>Order Type: Takeaway</p>
                            )}
                            <p>Payment: {convertPaymentMethod(order.paymentType)}</p>
                            <p>Total price: <strong>${details.totalPrice}</strong></p>
                            <p>Order Date: {(order.createdAt).slice(0, 10)}</p>
                        </div>
                        <div className="client-ordered-items-section">
                            <h5>Ordered Items:</h5>
                            <div className="client-ordered-items-list">
                                <ul>
                                    {details.items.map((item, index) => (
                                        <li key={index} className="client-ordered-item">
                                            <div className="client-order-item-info">
                                                <span>{item.name}</span>
                                                <span
                                                    className="client-order-item-price">${item.total.toFixed(2)}</span>
                                            </div>
                                            {item.modifications.length > 0 && (
                                                <div className="client-order-modifications">
                                                    {item.modifications.map((modification, index) => (
                                                        <span key={index}>
                                                            {modification.type === "extra" ? (
                                                                `+${modification.count} extra ${modification.name}`
                                                            ) : (
                                                                `-${modification.count} less ${modification.name}`
                                                            )}
                                                        </span>
                                                    ))}
                                                </div>
                                            )}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className="client-order-buttons-section">
                        <button className="client-order-button close" onClick={displayDetails}>Close</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default OrderItem;