import React, { useState, useRef, useEffect } from 'react';
import { OrbitProgress } from 'react-loading-indicators';
import { completePersonalInfo, getPersonalData } from '../../service/api/customerApi';
import './EditPersonalData.scss';
import { useNavigate } from "react-router-dom";

const EditPersonalData = () => {
    const navigate = useNavigate();

    const getToken = () => {
        const localStorageToken = localStorage.getItem("jwt_client");
        const sessionStorageToken = sessionStorage.getItem("jwt_client");
        return sessionStorageToken || localStorageToken;
    };

    const goToClientOrders = () => {
        navigate('/account/orders');
    };

    const goToClientReservations = () => {
        navigate('/account/reservations');
    };

    useEffect(() => {
        const getData = async () => {
            const token = getToken();
            const response = await getPersonalData(token);
            const userData = await response.json();

            const fullName = userData.name || "";
            const splitName = fullName.split(" ");
            setName(splitName[0] || "");
            setLastname(splitName[1] || "");
            setEmail(userData.email || "");
            setPhone(userData.phone || "");
            setEmailChangeable(userData.isChangeableEmail !== false);
            setIsInternalUser(userData.internalUser);
        };
        getData();
    }, []);

    const [name, setName] = useState("");
    const [lastname, setLastname] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [isEmailChangeable, setEmailChangeable] = useState(true);
    const [isLoading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});
    const [editDataErrorMessage, setEditDataErrorMessage] = useState("");
    const [editing, setEditing] = useState(false);
    const [isInternalUser, setIsInternalUser] = useState(false);

    const nameInputRef = useRef(null);

    const validateForm = () => {
        const newErrors = {};
        const namePattern = /^[A-Za-z]+$/;
        const phonePattern = /^\d{3}-\d{3}-\d{3}$/;
        const emailPattern = /\S+@\S+\.\S+/;

        if (!name.trim()) {
            newErrors.name = "Name cannot be empty";
        } else if (!namePattern.test(name)) {
            newErrors.name = "Name can only contain letters";
        }

        if (!lastname.trim()) {
            newErrors.lastname = "Last name cannot be empty";
        } else if (!namePattern.test(lastname)) {
            newErrors.lastname = "Last name can only contain letters";
        }

        if (!phone.trim()) {
            newErrors.phone = "Phone number cannot be empty";
        } else if (!phonePattern.test(phone)) {
            newErrors.phone = "Phone number must match pattern e.g. 123-456-789";
        }

        if (!email.trim()) {
            newErrors.email = "Email cannot be empty";
        } else if (!emailPattern.test(email)) {
            newErrors.email = "Email is invalid";
        }

        return newErrors;
    };

    const editData = () => {
        setEditing(true);
        setTimeout(() => nameInputRef.current && nameInputRef.current.focus(), 0);
    };

    const updatePersonalDataFunction = async (e) => {
        e.preventDefault();
        setLoading(true);
        const validationErrors = validateForm();
        if (Object.keys(validationErrors).length === 0) {
            try {
                const token = getToken();
                const response = await completePersonalInfo(name, lastname, phone, email, token, isEmailChangeable);
                if (response.ok) {
                    setEditing(false);
                    setErrors({});
                    setEditDataErrorMessage("");
                } else {
                    const body = await response.json();
                    if (body.code === "client/0001") {
                        setEditDataErrorMessage("Email cannot be changed.");
                    } else if (body.code === "client/0002") {
                        setEditDataErrorMessage("A user with this phone number already exists.");
                    } else {
                        setEditDataErrorMessage("Unknown error encountered during editing personal data");
                    }
                }
            } catch (error) {
                setEditDataErrorMessage("Server error. Please try again later.");
                console.error("Error during editing data:", error);
            }
        } else {
            setErrors(validationErrors);
        }
        setLoading(false);
    };

    return (
        <div className="client__personal-data--container">
            {isLoading ? (
                <div className="loading-container">
                    <OrbitProgress color="#666" size="large" />
                    <p style={{ color: "#666" }}>Saving your personal data...</p>
                </div>
            ) : (
                <form className="client__personal-data--form" onSubmit={updatePersonalDataFunction}>
                    <h2 className="client__personal-data--form-title">Your Account</h2>
                    <div className="client__personal-data--buttons">
                        <button type="button" className="button client__personal-data--edit-button" onClick={goToClientOrders} disabled={editing}>
                            My Orders
                        </button>
                        <button type="button" className="button client__personal-data--edit-button" onClick={goToClientReservations} disabled={editing}>
                            My Reservations
                        </button>
                    </div>
                    <div className="client__personal-data--form-field">
                        <label htmlFor="name">Your Name</label>
                        <input
                            type="text"
                            id="name"
                            ref={nameInputRef}
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            disabled={!editing}
                        />
                        {errors.name && <p className="client__personal-data--error-message">{errors.name}</p>}
                    </div>
                    <div className="client__personal-data--form-field">
                        <label htmlFor="lastname">Your Last Name</label>
                        <input
                            type="text"
                            id="lastname"
                            value={lastname}
                            onChange={(e) => setLastname(e.target.value)}
                            disabled={!editing}
                        />
                        {errors.lastname && <p className="client__personal-data--error-message">{errors.lastname}</p>}
                    </div>
                    <div className="client__personal-data--form-field">
                        <label htmlFor="email">Your Email</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            disabled={!editing}
                            readOnly={!isEmailChangeable}
                        />
                        {errors.email && <p className="client__personal-data--error-message">{errors.email}</p>}
                    </div>
                    <div className="client__personal-data--form-field">
                        <label htmlFor="phone">Your Phone Number</label>
                        <input
                            type="tel"
                            id="phone"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            disabled={!editing}
                        />
                        {errors.phone && <p className="client__personal-data--error-message">{errors.phone}</p>}
                    </div>
                    {editDataErrorMessage && <p className="client__personal-data--error-message">{editDataErrorMessage}</p>}
                    {isInternalUser && (
                        <div className="common__login--redirect" style={{ color: "black", fontSize: "16px", marginTop: "5px", marginBottom: "10px" }}>
                            Change your password <a href="/password/change">here</a>
                        </div>
                    )}
                    <div className="client__personal-data--buttons">
                        {!editing &&
                        <button type="button" className="button client__personal-data--edit-button" onClick={editData} disabled={editing}>
                            Edit
                        </button>
                        }
                        {editing &&
                        <button type="submit" className="button client__personal-data--save-button" disabled={!editing}>
                            Save
                        </button>
                        }
                    </div>
                </form>
            )}
        </div>
    );
};

export default EditPersonalData;