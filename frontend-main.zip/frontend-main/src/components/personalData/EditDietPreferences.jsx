import React, {useEffect, useState} from "react";
import "./EditDietPreferences.scss";
import {
    getDietsByClientId, getDiets, addClientDiet, deleteClientDiet, getPersonalData
} from "../../service/api/customerApi.js";

const EditDietPreferences = () => {
    const [clientId, setClientId] = useState(0);
    const [clientDiets, setClientDiets] = useState([]);
    const [availableDiets, setAvailableDiets] = useState([]);
    const [newDiet, setNewDiet] = useState("");

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };

    useEffect(() => {
        const getData = async () => {
            try {
                const token = getToken();
                const response = await getPersonalData(token);
                const userData = await response.json();
                setClientId(userData.id);

                const dietResponse = await getDietsByClientId(userData.id);
                const clientData = await dietResponse.json();
                const clientDietIds = clientData.dietsIds;

                const allDietsResponse = await getDiets();
                const allDiets = await allDietsResponse.json();

                const clientDiets = allDiets.filter(diet => clientDietIds.includes(diet.id));
                const availableDiets = allDiets.filter(diet => !clientDietIds.includes(diet.id));

                setClientDiets(clientDiets);
                setAvailableDiets(availableDiets);
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };
        getData();
    }, []);

    const addDiet = async () => {
        if (newDiet) {
            try {
                const token = getToken();
                await addClientDiet(token, newDiet);
                const addedDiet = availableDiets.find(diet => diet.id === parseInt(newDiet));
                setClientDiets([...clientDiets, addedDiet]);
                setAvailableDiets(availableDiets.filter(diet => diet.id !== parseInt(newDiet)));
                setNewDiet("");
            } catch (error) {
                console.error("Error adding diet:", error);
            }
        }
    };

    const removeDiet = async dietId => {
        try {
            const token = getToken();
            await deleteClientDiet(token, dietId);
            const removedDiet = clientDiets.find(diet => diet.id === dietId);
            setAvailableDiets([...availableDiets, removedDiet]);
            setClientDiets(clientDiets.filter(diet => diet.id !== dietId));
        } catch (error) {
            console.error("Error removing diet:", error);
        }
    };

    return (
        <div className="client__diet-preferences--container">
            <h2>Edit Your Diet Preferences</h2>
            <div className="client__diet-preferences--add-diet">
                <select value={newDiet} onChange={(e) => setNewDiet(e.target.value)}>
                    <option value="">Select a diet</option>
                    {availableDiets.map(diet => (
                        <option
                            key={diet.id}
                            value={diet.id}>
                            {diet.name}
                        </option>
                    ))}
                </select>
                <button onClick={addDiet} disabled={!newDiet}>Add Diet</button>
            </div>
            <div className="client__diet-preferences--diet-list">
                {clientDiets.map(diet => (
                    <div className="client__diet-preferences--diet-tile" key={diet.id}>
                        <span>{diet.name}</span>
                        <button onClick={() => removeDiet(diet.id)}>&times;</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default EditDietPreferences;