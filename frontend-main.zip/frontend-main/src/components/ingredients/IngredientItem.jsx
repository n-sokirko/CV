import React, {useState} from 'react';
import './IngredientItem.scss';
import {updateIngredientAvailability} from '../../service/api/restaurantApi.js';

const IngredientItem = ({id, name, isAvailable: initialIsAvailable}) => {
    const [isAvailable, setIsAvailable] = useState(initialIsAvailable);

    const updateIngredientAvailabilityFunction = async () => {
        const newAvailabilityStatus = !isAvailable;
        setIsAvailable(newAvailabilityStatus);
        try {
            await updateIngredientAvailability(id, newAvailabilityStatus);
        } catch (error) {
            console.error("Failed to update availability", error);
        }
    };

    return (
        <div className="restaurant__ingredient--item" data-available={isAvailable}>
            <div className="restaurant__ingredient--properties">
                <div className="restaurant__ingredient--header">
                    <h5 className="restaurant-ingredient-name">{name}</h5>
                </div>
                <button className="restaurant__ingredient--change-status-button"
                        onClick={updateIngredientAvailabilityFunction}>
                    {isAvailable ? "Mark as Not Available" : "Mark as Available"}
                </button>
            </div>
        </div>
    );
};

export default IngredientItem;