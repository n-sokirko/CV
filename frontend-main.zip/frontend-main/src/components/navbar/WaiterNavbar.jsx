import {Link, useLocation, useNavigate} from 'react-router-dom';
import './Navbar.scss';
import {useState, useEffect} from 'react';

const WaiterNavbar = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const [isLoggedIn, setLoggedIn] = useState(false);
    const [isMenuOpen, setMenuOpen] = useState(false);

    const checkIfLoggedIn = () => {
        const sessionStorageToken = sessionStorage.getItem('jwt_waiter');
        setLoggedIn(!!sessionStorageToken);
    };

    useEffect(() => {
        checkIfLoggedIn();
    }, [location.pathname]);

    useEffect(() => {
        const handleStorageChange = () => {
            checkIfLoggedIn();
        };

        window.addEventListener('storage', handleStorageChange);

        return () => {
            window.removeEventListener('storage', handleStorageChange);
        };
    }, []);

    const handleLogout = () => {
        sessionStorage.removeItem('jwt_waiter');
        setLoggedIn(false);
        navigate('/waiter/login');
    };

    const toggleMenu = () => {
        setMenuOpen(!isMenuOpen);
    };

    return (
        <header className='common__navbar--header'>
            <div className="common__navbar--menu-icon" onClick={toggleMenu}>
                <div></div>
                <div></div>
                <div></div>
            </div>
            <nav>
                <ul className={`common__navbar ${isMenuOpen && "open"}`}>
                    {isLoggedIn && (
                        <>
                            <li><Link to="/waiter/orders/unassigned"
                                      className={location.pathname === '/waiter/orders/unassigned' ? 'active' : ''}>Orders</Link></li>
                            <li><Link to="/waiter/reservations"
                                      className={location.pathname === '/waiter/reservations' ? 'active' : ''}>Reservations</Link>
                            </li>
                            <li>
                                <button onClick={handleLogout} className="common__navbar--logout-button">Logout</button>
                            </li>
                        </>
                    )}
                </ul>
            </nav>
        </header>
    );
};

export default WaiterNavbar;