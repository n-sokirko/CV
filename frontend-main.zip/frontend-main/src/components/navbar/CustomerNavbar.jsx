import { Link, useLocation, useNavigate } from 'react-router-dom';
import './Navbar.scss';
import { useState, useEffect } from 'react';

const CustomerNavbar = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const [isLoggedIn, setLoggedIn] = useState(false);
    const [isMenuOpen, setMenuOpen] = useState(false);

    const checkIfLoggedIn = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        setLoggedIn(!!localStorageToken || !!sessionStorageToken);
    };

    useEffect(() => {
        checkIfLoggedIn();
    }, [location.pathname]);

    useEffect(() => {
        const handleStorageChange = () => {
            checkIfLoggedIn();
        };

        window.addEventListener('storage', handleStorageChange);

        return () => {
            window.removeEventListener('storage', handleStorageChange);
        };
    }, []);

    const handleLogout = () => {
        sessionStorage.removeItem('jwt_client');
        localStorage.removeItem('jwt_client');
        setLoggedIn(false);
        navigate('/');
    };

    const toggleMenu = () => {
        setMenuOpen(!isMenuOpen);
    };

    return (
        <header className="common__navbar--header">
            <div className="common__navbar--menu-icon" onClick={toggleMenu}>
                <div></div>
                <div></div>
                <div></div>
            </div>
            <nav>
                <ul className={`common__navbar ${isMenuOpen ? 'open' : ''}`}>
                    <li>
                        <Link to="/" className={location.pathname === '/' ? 'active' : ''}>Home</Link>
                    </li>
                    <li>
                        <Link to="/menu" className={location.pathname === '/menu' ? 'active' : ''}>Menu</Link>
                    </li>
                    <li>
                        <Link to="/reservation" className={location.pathname === '/reservation' ? 'active' : ''}>Book a table</Link>
                    </li>
                    <li>
                        <Link to="/contact" className={location.pathname === '/contact' ? 'active' : ''}>Contact</Link>
                    </li>
                    {isLoggedIn ? (
                        <>
                            <li>
                                <Link to="/cart/summary" className={location.pathname === '/cart/summary' ? 'active' : ''}>Cart</Link>
                            </li>
                            <li>
                                <Link to="/menu/client" className={location.pathname === '/menu/client' ? 'active' : ''}>My Menu</Link>
                            </li>
                            <li>
                                <Link to="/account" className={location.pathname === '/account' ? 'active' : ''}>My Account</Link>
                            </li>
                            <li>
                                <button onClick={handleLogout} className="common__navbar--logout-button">Logout</button>
                            </li>
                        </>
                    ) : (
                        <li>
                            <Link to="/login" className={location.pathname === '/login' ? 'active' : ''}>Login</Link>
                        </li>
                    )}
                </ul>
            </nav>
        </header>
    );
};

export default CustomerNavbar;