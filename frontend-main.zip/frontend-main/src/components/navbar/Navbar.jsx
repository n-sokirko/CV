import {useLocation} from 'react-router-dom';
import './Navbar.scss';
import ManagerNavbar from "./ManagerNavbar.jsx";
import RestaurantNavbar from "./RestaurantNavbar.jsx";
import CustomerNavbar from "./CustomerNavbar.jsx";
import WaiterNavbar from "./WaiterNavbar.jsx";

const Navbar = () => {
    const location = useLocation();

    return (
        <>
            {location.pathname.startsWith('/waiter') && <WaiterNavbar/>}
            {location.pathname.startsWith('/restaurant') && <RestaurantNavbar/>}
            {location.pathname.startsWith('/manager') && <ManagerNavbar/>}
            {!location.pathname.startsWith('/waiter') &&
                !location.pathname.startsWith('/restaurant') &&
                !location.pathname.startsWith('/manager') && <CustomerNavbar/>}
        </>
    );
};

export default Navbar;