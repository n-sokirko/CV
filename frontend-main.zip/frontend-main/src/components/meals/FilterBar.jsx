import React, {useEffect, useState} from 'react';
import './FilterBar.scss';
import {
    getCategories,
    getCategoryById,
    getSubcategoriesByCategoryId,
    getSubcategoryById
} from "../../service/api/customerApi.js";

const FilterBar = (
    {
        onCategoryChange,
        onSubcategoryChange,
        onPriceFilterChange,
        onCaloriesFilterChange
    }) => {

    const [categoriesFilterBar, setCategoriesFilterBar] = useState([]);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);

    const [tempSelectedCategory, setTempSelectedCategory] = useState(null);
    const [categoryFilter, setCategoryFilter] = useState("All");
    const [subcategoryFilter, setSubcategoryFilter] = useState("");
    const [pricesFilter, setPricesFilter] = useState({min: "", max: ""});
    const [caloriesFilter, setCaloriesFilter] = useState({min: "", max: ""});

    const [isCategoryOpen, setIsCategoryOpen] = useState(false);
    const [isSubcategoryOpen, setIsSubcategoryOpen] = useState(false);
    const [isPriceOpen, setIsPriceOpen] = useState(false);
    const [isCaloriesOpen, setIsCaloriesOpen] = useState(false);

    const [categories, setCategories] = useState([]);
    const [subcategories, setSubcategories] = useState([]);

    const openSidebar = () => setIsSidebarOpen(true);

    const displaySidebarCategories = () => setIsCategoryOpen(!isCategoryOpen);
    const displaySidebarSubcategories = () => setIsSubcategoryOpen(!isSubcategoryOpen);
    const displaySidebarPrices = () => setIsPriceOpen(!isPriceOpen);
    const displaySidebarCalories = () => setIsCaloriesOpen(!isCaloriesOpen);

    const applyFilters = () => {
        onCategoryChange(tempSelectedCategory ? tempSelectedCategory.name : "All");
        onSubcategoryChange(subcategoryFilter);
        onPriceFilterChange(pricesFilter);
        onCaloriesFilterChange(caloriesFilter);
        setIsSidebarOpen(false);
    };

    const handleCategoryTileClick = async (category) => {
        onCategoryChange(category.name);
        setTempSelectedCategory(category);
        setCategoryFilter(category.name);
    };

    const handleAllClick = () => {
        clearFilters();
        onCategoryChange("All");
        setTempSelectedCategory(null);
        setCategoryFilter("All");
    };

    const updateCategoriesToFilter = async (event) => {
        const {value, checked} = event.target;
        if (checked) {
            const response = await getCategoryById(value);
            const categoryData = await response.json();
            setTempSelectedCategory(categoryData);
        } else {
            setTempSelectedCategory(null);
        }
    };

    const updateSubcategoriesToFilter = async (event) => {
        const {value, checked} = event.target;
        if (checked) {
            const response = await getSubcategoryById(value);
            const subcategoryData = await response.json();
            setSubcategoryFilter(subcategoryData.name);
        } else {
            setSubcategoryFilter("");
        }
    };

    const updatePriceRangeToFilter = (event) => {
        const {name, value} = event.target;
        setPricesFilter(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const updateCaloriesRangeToFilter = (event) => {
        const {name, value} = event.target;
        setCaloriesFilter(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const clearFilters = () => {
        onCategoryChange("All")
        onSubcategoryChange("");
        onPriceFilterChange({min: "", max: ""});
        onCaloriesFilterChange({min: "", max: ""});
        setIsSidebarOpen(false);
    };


    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await getCategories();
                const result = await response.json();
                setCategoriesFilterBar(result);
                setCategories(result);
            } catch (error) {
                console.error("Error fetching categories:", error);
            }
        };
        fetchCategories();
    }, []);

    useEffect(() => {
        if (tempSelectedCategory) {
            const fetchSubcategories = async () => {
                try {
                    const response = await getSubcategoriesByCategoryId(tempSelectedCategory.id);
                    const result = await response.json();
                    setSubcategories(result);
                } catch (error) {
                    console.error(`Error fetching subcategories for category ${tempSelectedCategory.id}:`, error);
                }
            };
            fetchSubcategories();
        } else {
            setSubcategories([]);
        }
    }, [tempSelectedCategory]);


    return (
        <div className="common__filter-bar">
            <div className="common__filter-bar--tiles">
                <button
                    className={`common__filter-bar--tile ${categoryFilter === "All" ? "selected" : ""}`}
                    onClick={handleAllClick}
                >
                    All
                </button>
                {categoriesFilterBar.map((category, index) => (
                    <button
                        key={index}
                        className={`common__filter-bar--tile ${categoryFilter === category.name ? "selected" : ""}`}
                        onClick={() => handleCategoryTileClick(category)}
                    >
                        {category.name}
                    </button>
                ))}
            </div>
            <button className="common__filter-bar--all-filters-button" onClick={openSidebar}>All Filters</button>

            {isSidebarOpen && (
                <div className="common__filter-bar--sidebar">
                    <div className="common__filter-bar--sidebar-filters">
                        <h4 onClick={displaySidebarCategories} className="common__filter-bar--filter-category">Categories</h4>
                        {isCategoryOpen && categories.map((category) => (
                            <label
                                key={category.id}
                                className={`common__filter-bar--filter-option ${tempSelectedCategory && tempSelectedCategory.id === category.id ? "selected" : ""}`}>
                                <input
                                    type="checkbox"
                                    value={category.id}
                                    checked={tempSelectedCategory && tempSelectedCategory.id === category.id}
                                    onChange={updateCategoriesToFilter}
                                />
                                {category.name}
                            </label>
                        ))}

                        <h4 onClick={displaySidebarSubcategories}
                            className="common__filter-bar--filter-category">
                            Subcategories
                        </h4>
                        {isSubcategoryOpen && subcategories.map((subcategory) => (
                            <label
                                key={subcategory.id}
                                className={`common__filter-bar--filter-option ${subcategoryFilter && subcategoryFilter === subcategory.name ? "selected" : ""}`}>
                                <input
                                    type="checkbox"
                                    value={subcategory.id}
                                    checked={subcategoryFilter === subcategory.name}
                                    onChange={updateSubcategoriesToFilter}
                                />
                                {subcategory.name}
                            </label>
                        ))}

                        <h4 onClick={displaySidebarPrices} className="common__filter-bar--filter-category">Price</h4>
                        {isPriceOpen && (
                            <div className="common__filter-bar--range-inputs">
                                <input
                                    type="number"
                                    name="min"
                                    value={pricesFilter.min}
                                    onChange={updatePriceRangeToFilter}
                                    placeholder="Min"
                                    min="0"
                                />
                                <input
                                    type="number"
                                    name="max"
                                    value={pricesFilter.max}
                                    onChange={updatePriceRangeToFilter}
                                    placeholder="Max"
                                    min="0"
                                />
                            </div>
                        )}

                        <h4 onClick={displaySidebarCalories} className="common__filter-bar--filter-category">Calories</h4>
                        {isCaloriesOpen && (
                            <div className="common__filter-bar--range-inputs">
                                <input
                                    type="number"
                                    name="min"
                                    value={caloriesFilter.min}
                                    onChange={updateCaloriesRangeToFilter}
                                    placeholder="Min"
                                    min="0"
                                />
                                <input
                                    type="number"
                                    name="max"
                                    value={caloriesFilter.max}
                                    onChange={updateCaloriesRangeToFilter}
                                    placeholder="Max"
                                    min="0"
                                />
                            </div>
                        )}
                    </div>

                    <div className="common__filter-bar--sidebar-buttons">
                        <button
                            className="common__filter-bar--clear-button"
                            onClick={clearFilters}>
                            Clear
                        </button>
                        <button
                            className="common__filter-bar--apply-button"
                            onClick={applyFilters}>
                            Apply
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default FilterBar;