import React, {useEffect, useState} from 'react';
import './MealDetails.scss';
import backgroundImage from '../../assets/coffee_photo.jpg';
import {getMealById, getModifiableIngredientsByMealId} from "../../service/api/customerApi.js";
import {useNavigate} from "react-router-dom";
import {DEFAULT_IMAGE_LINK} from "../../service/api/commonApi.js";

const MealDetails = ({mealId, onClose}) => {
    const imageUrl = backgroundImage;
    const navigate = useNavigate();
    const [ingredients, setIngredients] = useState([]);
    const [mealName, setMealName] = useState("");
    const [modifiers, setModifiers] = useState({});
    const [baseCounts, setBaseCounts] = useState({});
    const [totalPrice, setTotalPrice] = useState(0);
    const [unitPrice, setUnitPrice] = useState(0);
    const [mealQuantity, setMealQuantity] = useState(1);
    const [mealImage, setMealImage] = useState("");

    const addItemToCart = () => {
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        const localStorageToken = localStorage.getItem('jwt_client');
        if (!sessionStorageToken && !localStorageToken) {
            navigate('/login');
        }
            let token;
            if(sessionStorageToken){
                token = sessionStorageToken;
            }
            else{
                token = localStorageToken;
            }
        let cart = localStorage.getItem(`${token}_cart`);
        cart = cart ? JSON.parse(cart) : [];

        const finalPrice = totalPrice * mealQuantity;

        const item = {
            mealId,
            mealName,
            mealQuantity,
            modifiers: Object.entries(modifiers).map(([id, modifier]) => ({
                id: parseInt(id),
                name: modifier.name,
                count: modifier.count
            })),
            unitPrice,
            totalPrice: finalPrice
        };

        const existingItemIndex = cart.findIndex(
            cartItem =>
                cartItem.mealId === item.mealId &&
                JSON.stringify(cartItem.modifiers) === JSON.stringify(item.modifiers)
        );

        if (existingItemIndex > -1) {
            cart[existingItemIndex].mealQuantity += mealQuantity;
            cart[existingItemIndex].totalPrice += finalPrice;
        } else {
            cart.push(item);
        }

        localStorage.setItem(`${token}_cart`, JSON.stringify(cart));
        console.log("Updated Cart:", cart);
        onClose();
    };

    useEffect(() => {
        const fetchMealDetails = async () => {
            try {
                const modifiableIngredientsResponse = await getModifiableIngredientsByMealId(mealId);
                const modifiableIngredientsResult = await modifiableIngredientsResponse.json();
                setIngredients(modifiableIngredientsResult);

                const initialModifiers = {};
                const initialBaseCounts = {};

                modifiableIngredientsResult.forEach(ingredient => {
                    initialModifiers[ingredient.ingredient.id] = {
                        name: ingredient.ingredient.name,
                        count: ingredient.baseCount
                    };
                    initialBaseCounts[ingredient.ingredient.id] = ingredient.baseCount;
                });

                setModifiers(initialModifiers);
                setBaseCounts(initialBaseCounts);

                const mealResponse = await getMealById(mealId);
                const mealResult = await mealResponse.json();
                setMealName(mealResult.name);
                setTotalPrice(mealResult.price);
                setUnitPrice(mealResult.price);
                setMealImage(mealResult.imageLink);

            } catch (error) {
                console.error("Error fetching meal details: ", error);
            }
        };

        fetchMealDetails();
    }, [mealId]);

    const incrementIngredientQuantity = (modifiableIngredient) => {
        const {ingredient, maximumCount, price} = modifiableIngredient;

        setModifiers((prevModifiers) => {
            const currentQuantity = prevModifiers[ingredient.id].count;
            if (currentQuantity < maximumCount) {
                const newQuantity = currentQuantity + 1;
                if (newQuantity > baseCounts[ingredient.id]) {
                    setTotalPrice((prevPrice) => prevPrice + price);
                }
                return {
                    ...prevModifiers,
                    [ingredient.id]: {
                        ...prevModifiers[ingredient.id],
                        count: newQuantity
                    }
                };
            }
            return prevModifiers;
        });
    };

    const decrementIngredientQuantity = (modifiableIngredient) => {
        const {ingredient, minimumCount, price} = modifiableIngredient;

        setModifiers((prevModifiers) => {
            const currentQuantity = prevModifiers[ingredient.id].count;
            if (currentQuantity > minimumCount) {
                const newQuantity = currentQuantity - 1;
                if (currentQuantity > baseCounts[ingredient.id]) {
                    setTotalPrice((prevPrice) => prevPrice - price);
                }
                return {
                    ...prevModifiers,
                    [ingredient.id]: {
                        ...prevModifiers[ingredient.id],
                        count: newQuantity
                    }
                };
            }
            return prevModifiers;
        });
    };

    const incrementMealQuantity = () => {
        setMealQuantity((prevQuantity) => prevQuantity + 1);
    };

    const decrementMealQuantity = () => {
        setMealQuantity((prevQuantity) => Math.max(prevQuantity - 1, 1));
    };

    return (
        <div className="common__meal-details--add-to-cart-meal-item">
            <button className="common__meal-details--add-to-cart-close-button" onClick={onClose}>Go back</button>
            <div className="common__meal-details--add-to-cart-meal-image" style={{backgroundImage: `url(${mealImage || DEFAULT_IMAGE_LINK})`}}></div>
            <div className="common__meal-details--add-to-cart-meal-details">
                <h2>{mealName}</h2>
                <h4>Modify ingredients:</h4>
                <div className="common__meal-details--add-to-cart-modifiers">
                    {ingredients.map((modifiableIngredient, index) => (
                        <div key={index} className="common__meal-details--add-to-cart-modifier-item">
                            <span className="common__meal-details--add-to-cart-modifier-name">
                                {modifiableIngredient.ingredient.name}
                            </span>
                            <div className="common__meal-details--add-to-cart-modifier-buttons">
                                <button className="common__meal-details--add-to-cart-modifier-button"
                                        onClick={() =>
                                            decrementIngredientQuantity(modifiableIngredient)}
                                >
                                    -
                                </button>
                                <span className="common__meal-details--add-to-cart-modifier-quantity">
                                    {modifiers[modifiableIngredient.ingredient.id]?.count || 0}
                                </span>
                                <button className="common__meal-details--add-to-cart-modifier-button"
                                        onClick={() =>
                                            incrementIngredientQuantity(modifiableIngredient)}
                                >
                                    +
                                </button>
                                <span className="common__meal-details--add-to-cart-modifier-price">
                                    ${modifiableIngredient.price.toFixed(2)}
                                </span>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="common__meal-details--add-to-cart-border"></div>
                <div className="common__meal-details--add-to-cart-modifiers">
                    <div className="common__meal-details--add-to-cart-modifier-item">
                        <div className="common__meal-details--add-to-cart-modifier-buttons-quantity">
                            <span className="span-quantity">Quantity: </span>
                            <button className="common__meal-details--add-to-cart-modifier-button"
                                    onClick={decrementMealQuantity}
                            >
                                -
                            </button>
                            <span className="common__meal-details--add-to-cart-modifier-quantity">
                                {mealQuantity}
                            </span>
                            <button className="common__meal-details--add-to-cart-modifier-button"
                                    onClick={incrementMealQuantity}
                            >
                                +
                            </button>
                        </div>
                    </div>
                </div>
                <h3>Total Price: ${(totalPrice * mealQuantity).toFixed(2)}</h3>
                <button className="common__meal-details--add-to-cart-button" onClick={addItemToCart}>Add to cart</button>
            </div>
        </div>
    );
};

export default MealDetails;
