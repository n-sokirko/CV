import React from 'react';
import './SearchBar.scss';

const SearchBar = ({ placeholder, onChange, onKeyDown }) => {
    return (
        <input
            type="text"
            className="common__search-bar"
            placeholder={placeholder || "Search..."}
            onChange={onChange}
            onKeyDown={onKeyDown}
        />
    );
};

export default SearchBar;