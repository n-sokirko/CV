import React, {useState} from 'react';
import './SortingItem.scss';

const SortingItem = ({options, onSortChange}) => {
    const [areOptionsDisplayed, setOptionDisplayed] = useState(false);
    const [selectedSort, setSelectedSort] = useState(null);

    const displayOptions = () => {
        setOptionDisplayed(!areOptionsDisplayed);
    }

    const chooseSortOption = (option) => {
        setSelectedSort(option);
        setOptionDisplayed(false);
        onSortChange(option.value);
    }

    return (
        <div className="common__sorting-item">
            <button className="common__sorting-item--button" onClick={displayOptions}>
                {selectedSort ? selectedSort.label : "Sort by"}
            </button>
            {areOptionsDisplayed && (
                <div className="common__sorting-item--options">
                    {options.map((option) => (
                        <div
                            key={option.value}
                            className="common__sorting-item--option"
                            onClick={() => chooseSortOption(option)}
                        >
                            {option.label}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default SortingItem;