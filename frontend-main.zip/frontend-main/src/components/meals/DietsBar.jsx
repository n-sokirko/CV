import React, {useState} from "react";
import "./DietsBar.scss";

const DietsBar = ({diets}) => {
    const [showAll, setShowAll] = useState(false);

    const maxRowWidth = 600;
    const tileWidth = 120;
    const maxTilesInRow = Math.floor(maxRowWidth / tileWidth);

    const visibleDiets = showAll ? diets : diets.slice(0, maxTilesInRow);

    return (
        <div className="diets-bar">
            <div className="diets-container">
                <p>Your diets: </p>
                {visibleDiets.map((diet, index) => (
                    <div key={index} className="diet-tile">
                        {diet}
                    </div>
                ))}
                {diets.length > maxTilesInRow && (
                    <button
                        className="show-all-diets-button"
                        onClick={() => setShowAll(!showAll)}
                    >
                        {showAll ? "Show Less" : "All Your Diets"}
                    </button>
                )}
            </div>
        </div>
    );
};

export default DietsBar;