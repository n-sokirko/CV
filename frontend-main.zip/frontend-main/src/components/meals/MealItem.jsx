import React, {useState} from 'react';
import {FaShoppingCart} from 'react-icons/fa';
import './MealItem.scss';

const MealItem = (props) => {

    const [isMoreDisplayed, setMoreDisplay] = useState(false);

    const displayMealDetails = () => {
        setMoreDisplay(!isMoreDisplayed);
    };

    return (
        <div className={`common__meal-item ${isMoreDisplayed ? 'common__meal-item--more-details' : ''}`}>
            <div className="common__meal-item--meal-image" style={{backgroundImage: `url(${props.imageUrl})`}}>
                {!props.isAvailable && (
                    <div className="common__meal-item--meal-availability-status">Not Available</div>
                )}
            </div>
            <div className="common__meal-item--meal-properties">
                <div className="common__meal-item--meal-header">
                    <h5 className="common__meal-item--meal-name">{props.name}</h5>
                    <span className="common__meal-item--meal-price">${props.price.toFixed(2)}</span>
                </div>
                <p className="common__meal-item--meal-ingredients">{props.ingredients.join(', ')}</p>
                {isMoreDisplayed && (
                    <div className="common__meal-item--meal-details">
                        <div className="common__meal-item--meal-single-detail">
                            <span className="common__meal-item--meal-label">Category:</span>
                            <span className="common__meal-item--meal-value">{props.category}, {props.subcategory}</span>
                        </div>
                        {/*<div className="common__meal-item--meal-single-detail">*/}
                        {/*    <span className="common__meal-item--meal-label">Diets:</span>*/}
                        {/*    <span className="common__meal-item--meal-value">{props.diets.join(', ')}</span>*/}
                        {/*</div>*/}
                        <div className="common__meal-item--meal-single-detail">
                            <span className="common__meal-item--meal-label">Allergens:</span>
                            <span className="common__meal-item--meal-value">{props.allergens.join(', ')}</span>
                        </div>
                        <div className="common__meal-item--meal-single-detail">
                            <span className="common__meal-item--meal-label">Kcal:</span>
                            <span className="common__meal-item--meal-value">{props.calories}</span>
                        </div>
                        <button onClick={displayMealDetails} className="common__meal-item--meal-more-info">Less</button>
                    </div>
                )}
                {!isMoreDisplayed && (
                    <button onClick={displayMealDetails} className="common__meal-item--meal-more-info">More</button>
                )}
                {props.isAvailable && (
                    <FaShoppingCart className="common__meal-item--cart-icon" onClick={props.onCartClick}/>
                )}
            </div>
        </div>
    );
};

export default MealItem;