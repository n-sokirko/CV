import React, {useState} from 'react';
import './AuthenticationForm.scss';
import {Register} from '../../service/api/customerApi';
import {useNavigate} from "react-router-dom";
import {OrbitProgress} from 'react-loading-indicators';

export const RegisterForm = () => {
    const navigate = useNavigate();

    const [name, setName] = useState("");
    const [lastname, setLastname] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [password, setPassword] = useState("");
    const [repeatPassword, setRepeatPassword] = useState("");
    const [acceptTerms, setAcceptTerms] = useState(false);
    const [isLoading, setLoading] = useState(false);

    const [focused, setFocused] = useState({
        name: false,
        lastname: false,
        email: false,
        phone: false,
        password: false,
        repeatPassword: false,
    });

    const [errors, setErrors] = useState({});
    const [registerErrorMessage, setRegisterErrorMessage] = useState("");

    const handleFocus = (field) => {
        setErrors({...errors, [field]: ''});
        setFocused({...focused, [field]: true});
    };

    const handleBlur = (field) => {
        if (
            (field === 'name' && !name) ||
            (field === 'lastname' && !lastname) ||
            (field === 'email' && !email) ||
            (field === 'phone' && !phone) ||
            (field === 'password' && !password) ||
            (field === 'repeatPassword' && !repeatPassword)
        ) {
            setFocused({...focused, [field]: false});
        }
    };

    const validateForm = () => {
        const newErrors = {};
        const namePattern = /^[A-Za-z]+$/;
        const phonePattern = /^\d{3}-\d{3}-\d{3}$/;
        const emailPattern = /\S+@\S+\.\S+/;

        if (!name.trim()) {
            newErrors.name = "Name cannot be empty";
        } else if (!namePattern.test(name)) {
            newErrors.name = "Name can only contain letters";
        }

        if (!lastname.trim()) {
            newErrors.lastname = "Last name cannot be empty";
        } else if (!namePattern.test(lastname)) {
            newErrors.lastname = "Last name can only contain letters";
        }

        if (!email.trim()) {
            newErrors.email = "Email cannot be empty";
        } else if (!emailPattern.test(email)) {
            newErrors.email = "Email is invalid";
        }

        if (!phone.trim()) {
            newErrors.phone = "Phone number cannot be empty";
        } else if (!phonePattern.test(phone)) {
            newErrors.phone = "Phone number must match pattern e.g. 123-456-789";
        }

        if (!password.trim()) {
            newErrors.password = "Password cannot be empty";
        } else if (password.length < 8) {
            newErrors.password = "Password should be at least 8 characters."
        }

        if (!repeatPassword.trim()) {
            newErrors.repeatPassword = "Repeated password cannot be empty";
        } else if (password !== repeatPassword) {
            newErrors.repeatPassword = "Password and repeated password must be identical";
        }

        if (!acceptTerms) {
            newErrors.acceptTerms = "You must accept the Terms and Conditions";
        }

        return newErrors;
    };

    const registerFunction = async (e) => {
        e.preventDefault();
        setLoading(true);
        const validationErrors = validateForm();

        if (Object.keys(validationErrors).length === 0) {
            try {
                const response = await Register(name, lastname, email, phone, password, repeatPassword);

                if (response.ok) {
                    navigate("/activateAccount");
                } else {
                    const body = await response.json();
                    if (body.message === "auth/0005") {
                        setRegisterErrorMessage("A user with this email already exists.");
                    } else if (body.message === "auth/0006") {
                        setRegisterErrorMessage("A user with this phone number already exists.");
                    } else {
                        setRegisterErrorMessage("Unknown error encountered during registration");
                    }
                }
            } catch (error) {
                setRegisterErrorMessage("Server error. Please try again later.");
                console.error("Error during registration:", error);
            }
        } else {
            setErrors(validationErrors);
        }
        setLoading(false);
    };

    return (
        <div className="common__auth-container">
            {isLoading ? (
                <div className="loading-container">
                    <OrbitProgress color="#666" size="large"/>
                    <p style={{color: '#666'}}>Registering your account...</p>
                </div>
            ) : (
                <form className="common__auth-form" onSubmit={registerFunction}>
                    <h2 className="common__auth-form--title" style={{color: 'black'}}>Create an Account</h2>

                    <div className="common__auth-form--field">
                        <label htmlFor="name" className={focused.name ? 'focused' : ''}>
                            Your Name
                        </label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            value={name}
                            onFocus={() => handleFocus('name')}
                            onBlur={() => handleBlur('name')}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                        />
                        {errors.name && <p className="common__auth--error-message">{errors.name}</p>}
                    </div>

                    <div className="common__auth-form--field">
                        <label htmlFor="lastname" className={focused.lastname ? 'focused' : ''}>
                            Your Last Name
                        </label>
                        <input
                            type="text"
                            id="lastname"
                            name="lastname"
                            value={lastname}
                            onFocus={() => handleFocus('lastname')}
                            onBlur={() => handleBlur('lastname')}
                            onChange={(e) => {
                                setLastname(e.target.value);
                            }}
                        />
                        {errors.lastname && <p className="common__auth--error-message">{errors.lastname}</p>}
                    </div>

                    <div className="common__auth-form--field">
                        <label htmlFor="email" className={focused.email ? 'focused' : ''}>
                            Your Email
                        </label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={email}
                            onFocus={() => handleFocus('email')}
                            onBlur={() => handleBlur('email')}
                            onChange={(e) => {
                                setEmail(e.target.value);
                            }}
                        />
                        {errors.email && <p className="common__auth--error-message">{errors.email}</p>}
                    </div>

                    <div className="common__auth-form--field">
                        <label htmlFor="phone" className={focused.phone ? 'focused' : ''}>
                            Your Phone Number
                        </label>
                        <input
                            type="tel"
                            id="phone"
                            name="phone"
                            value={phone}
                            onFocus={() => handleFocus('phone')}
                            onBlur={() => handleBlur('phone')}
                            onChange={(e) => {
                                setPhone(e.target.value);
                            }}
                        />
                        {errors.phone && <p className="common__auth--error-message">{errors.phone}</p>}
                    </div>

                    <div className="common__auth-form--field">
                        <label htmlFor="password" className={focused.password ? 'focused' : ''}>
                            Password
                        </label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            value={password}
                            onFocus={() => handleFocus('password')}
                            onBlur={() => handleBlur('password')}
                            onChange={(e) => {
                                setPassword(e.target.value);
                            }}
                        />
                        {errors.password && <p className="common__auth--error-message">{errors.password}</p>}
                    </div>

                    <div className="common__auth-form--field" style={{marginBottom: '15px'}}>
                        <label htmlFor="repeatPassword" className={focused.repeatPassword ? 'focused' : ''}>
                            Repeat Password
                        </label>
                        <input
                            type="password"
                            id="repeatPassword"
                            name="repeatPassword"
                            value={repeatPassword}
                            onFocus={() => handleFocus('repeatPassword')}
                            onBlur={() => handleBlur('repeatPassword')}
                            onChange={(e) => {
                                setRepeatPassword(e.target.value);
                            }}
                        />
                        {errors.repeatPassword && <p className="common__auth--error-message">{errors.repeatPassword}</p>}
                    </div>

                    <div className="common__accept-terms">
                        <label htmlFor="acceptTerms">
                            <input
                                type="checkbox"
                                id="acceptTerms"
                                name="acceptTerms"
                                checked={acceptTerms}
                                onChange={(e) => setAcceptTerms(e.target.checked)}
                                onFocus={() => handleFocus('acceptTerms')}
                                onBlur={() => handleBlur('acceptTerms')}
                            />
                            <span></span> I Agree to the Terms and Conditions
                        </label>
                        {errors.acceptTerms && <p className="common__auth--error-message">{errors.acceptTerms}</p>}
                    </div>

                    {registerErrorMessage && <p className="common__auth--error-message">{registerErrorMessage}</p>}

                    <button type="submit" className="common__register-login--button">
                        Register
                    </button>

                    <div className="common__login--redirect" style={{color: 'black'}}>
                        Have already an account? <a href="/login">Login here</a>
                    </div>
                </form>
            )}
        </div>
    );
};