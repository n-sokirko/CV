import React from 'react';
import './Validation.scss';

const SentEmail = () => {
    return (
        <div className="common__verification-success--container">
            <div className="common__verification-message--container">
                <h1>Check your email</h1>
                <p>We’ve sent a link to reset your password to your email address. Please check your inbox and follow
                    the instructions to create a new password.</p>
            </div>
        </div>
    );
};

export default SentEmail;