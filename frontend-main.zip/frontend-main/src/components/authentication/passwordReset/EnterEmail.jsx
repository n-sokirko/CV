import React, {useState} from 'react';
import '../AuthenticationForm.scss';
import {sendEmailToResetPassword} from '../../../service/api/customerApi.js';
import {useNavigate} from "react-router-dom";
import {OrbitProgress} from "react-loading-indicators";

export const EnterEmail = () => {
    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [isLoading, setLoading] = useState(false);

    const [focused, setFocused] = useState({
        email: false
    });

    const [errors, setErrors] = useState({});
    const [sendEmailErrorMessage, setSendEmailErrorMessage] = useState("");

    const handleFocus = (field) => {
        setErrors({...errors, [field]: ''});
        setFocused({...focused, [field]: true});
    };

    const handleBlur = (field) => {
        if (
            (field === 'email' && !email)
        ) {
            setFocused({...focused, [field]: false});
        }
    };

    const validateForm = () => {
        const newErrors = {};
        const emailPattern = /\S+@\S+\.\S+/;

        if (!email.trim()) {
            newErrors.email = "Email cannot be empty";
        } else if (!emailPattern.test(email)) {
            newErrors.email = "Email is invalid";
        }
        return newErrors;
    };

    const sendEmailFunction = async (e) => {
        e.preventDefault();
        setLoading(true);
        const validationErrors = validateForm();

        if (Object.keys(validationErrors).length === 0) {
            try {
                const response = await sendEmailToResetPassword(email);

                if (response.ok) {
                    navigate("/password/reset/confirm");
                } else {
                    const body = await response.json();
                    setSendEmailErrorMessage("Error during sending email");
                }
            } catch (error) {
                setSendEmailErrorMessage("Server error. Please try again later.");
                console.error("Error during sending email:", error);
            }
        } else {
            setErrors(validationErrors);
        }
        setLoading(false);
    };

    return (
        <div className="common__auth-container">
            {isLoading ? (
                <div className="loading-container">
                    <OrbitProgress color="#666" size="large"/>
                    <p style={{color: '#666'}}>Sending email...</p>
                </div>
            ) : (
                <form className="common__auth-form" onSubmit={sendEmailFunction}>
                    <h2 className="common__auth-form--title" style={{color: 'black', marginTop: '-50px'}}>Reset your
                        password</h2>

                    <div className="common__auth-form--field">
                        <label htmlFor="email" className={focused.email ? 'focused' : ''}>
                            Your Email
                        </label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={email}
                            onFocus={() => handleFocus('email')}
                            onBlur={() => handleBlur('email')}
                            onChange={(e) => {
                                setEmail(e.target.value);
                            }}
                        />
                        {errors.email && <p className="common__auth--error-message">{errors.email}</p>}
                    </div>

                    {sendEmailErrorMessage && <p className="common__auth--error-message">{sendEmailErrorMessage}</p>}

                    <button type="submit" className="common__register-login--button">
                        Send email
                    </button>
                </form>
            )}
        </div>
    );
};