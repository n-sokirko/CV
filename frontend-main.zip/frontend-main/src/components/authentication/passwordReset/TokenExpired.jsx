import React from 'react';
import './Validation.scss';

const TokenExpired = () => {
    return (
        <div className="common__verification-success--container">
            <div className="common__verification-message--container">
                <h1>Token expired</h1>
                <p>Your authentication token has expired. A new email has been sent.</p>
            </div>
        </div>
    );
};

export default TokenExpired;