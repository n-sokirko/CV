import React from 'react';
import {Link} from 'react-router-dom';
import './Validation.scss';

const ResetSuccess = () => {
    return (
        <div className="common__verification-success--container">
            <div className="common__verification-message--container">
                <h1>Password Reset Successful</h1>
                <p>Your password has been successfully reset. You can now log in with your new password.</p>
                <Link to="/login" className="common__verification-login--link">Go to Login</Link>
            </div>
        </div>
    );
};

export default ResetSuccess;