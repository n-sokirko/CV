import React, {useEffect, useState} from 'react';
import '../AuthenticationForm.scss';
import {resetPassword, validateToken} from '../../../service/api/customerApi.js';
import {useLocation, useNavigate, useParams} from "react-router-dom";
import {OrbitProgress} from "react-loading-indicators";
import InvalidToken from "./InvalidToken.jsx";
import TokenExpired from "./TokenExpired.jsx";
import InvalidTokenType from "./InvalidTokenType.jsx";

export const PasswordReset = () => {
    const navigate = useNavigate();
    const location = useLocation();

    const [token, setToken] = useState(null);
    const [invalidTokenError, setInvalidTokenError] = useState(false);
    const [tokenExpiredError, setTokenExpiredError] = useState(false);
    const [invalidTokenTypeError, setInvalidTokenTypeError] = useState(false);
    const [password, setPassword] = useState("");
    const [repeatPassword, setRepeatPassword] = useState("");
    const [isLoading, setLoading] = useState(false);
    const [focused, setFocused] = useState({
        password: false,
        repeatPassword: false,
    });

    const [errors, setErrors] = useState({});
    const [resetPasswordErrorMessage, setResetPasswordErrorMessage] = useState("");

    const handleFocus = (field) => {
        setErrors({...errors, [field]: ''});
        setFocused({...focused, [field]: true});
    };

    const handleBlur = (field) => {
        if (
            (field === 'password' && !password) ||
            (field === 'repeatPassword' && !repeatPassword)
        ) {
            setFocused({...focused, [field]: false});
        }
    };

    const validateForm = () => {
        const newErrors = {};
        const minPasswordLength = 8;
        if (!password.trim()) {
            newErrors.password = "Password cannot be empty";
        } else if (password.length < minPasswordLength) {
            newErrors.password = "Password should be at least 8 characters."
        }

        if (!repeatPassword.trim()) {
            newErrors.repeatPassword = "Repeated password cannot be empty";
        } else if (password !== repeatPassword) {
            newErrors.repeatPassword = "Password and repeated password must be identical";
        }

        return newErrors;
    };

    const resetPasswordFunction = async (e) => {
        e.preventDefault();
        setLoading(true);
        const validationErrors = validateForm();

        if (Object.keys(validationErrors).length === 0) {
            try {
                const response = await resetPassword(password, repeatPassword, token);

                if (response.ok) {
                    navigate("/password/reset/success");
                } else {
                    const body = await response.json();
                    if (body.message === "auth/0013") {
                        setResetPasswordErrorMessage("Passwords do not match");
                    } else {
                        setResetPasswordErrorMessage("Unknown error encountered during password reset");
                    }
                }
            } catch (error) {
                setResetPasswordErrorMessage("Server error. Please try again later.");
                console.error("Error during password reset:", error);
            }
        } else {
            setErrors(validationErrors);
        }
        setLoading(false);
    };

    useEffect(async () => {
        const searchParams = new URLSearchParams(location.search);
        const token = searchParams.get('token');
        if (token) {
            setToken(token);
        }
        const response = await validateToken(token);
        if (!response.ok) {
            const body = await response.json();
            if (body.code === "auth/00014") {
                setInvalidTokenError(true);
            } else if (body.code === "auth/00015") {
                setTokenExpiredError(true);
            } else {
                setInvalidTokenTypeError(true);
            }
        }
    }, [location.search, navigate]);

    if (invalidTokenError) {
        return (
            <InvalidToken/>
        )
    } else if (tokenExpiredError) {
        return (
            <TokenExpired/>
        )
    } else if (invalidTokenTypeError) {
        return (
            <InvalidTokenType/>
        )
    } else {
        return (
            <div className="common__auth-container">
                {isLoading ? (
                    <div className="loading-container">
                        <OrbitProgress color="#666" size="large"/>
                        <p style={{color: '#666'}}>Resetting your password...</p>
                    </div>
                ) : (
                    <form className="common__auth-form" onSubmit={resetPasswordFunction}>
                        <h2 className="common__auth-form--title" style={{color: 'black', marginTop: '-50px'}}>Enter your new
                            password</h2>

                        <div className="common__auth-form--field">
                            <label htmlFor="password" className={focused.password ? 'focused' : ''}>
                                Password
                            </label>
                            <input
                                type="password"
                                id="password"
                                name="password"
                                value={password}
                                onFocus={() => handleFocus('password')}
                                onBlur={() => handleBlur('password')}
                                onChange={(e) => {
                                    setPassword(e.target.value);
                                }}
                            />
                            {errors.password && <p className="common__auth--error-message">{errors.password}</p>}
                        </div>

                        <div className="common__auth-form--field" style={{marginBottom: '15px'}}>
                            <label htmlFor="repeatPassword" className={focused.repeatPassword ? 'focused' : ''}>
                                Repeat Password
                            </label>
                            <input
                                type="password"
                                id="repeatPassword"
                                name="repeatPassword"
                                value={repeatPassword}
                                onFocus={() => handleFocus('repeatPassword')}
                                onBlur={() => handleBlur('repeatPassword')}
                                onChange={(e) => {
                                    setRepeatPassword(e.target.value);
                                }}
                            />
                            {errors.repeatPassword && <p className="common__auth--error-message">{errors.repeatPassword}</p>}
                        </div>

                        {resetPasswordErrorMessage && <p className="common__auth--error-message">{resetPasswordErrorMessage}</p>}

                        <button type="submit" className="common__register-login--button">
                            Reset password
                        </button>

                    </form>
                )}
            </div>
        );
    }
};