import React from 'react';
import './Validation.scss';

const InvalidToken = () => {
    return (
        <div className="common__verification-success--container">
            <div className="common__verification-message--container">
                <h1>404 Error</h1>
                <p>Invalid link</p>
            </div>
        </div>
    );
};

export default InvalidToken;