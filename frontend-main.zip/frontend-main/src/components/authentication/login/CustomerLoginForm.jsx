import React, {useState} from 'react';
import '../AuthenticationForm.scss';
import {FcGoogle} from "react-icons/fc";
import {FaFacebookSquare} from "react-icons/fa";
import {Login} from '../../../service/api/customerApi.js';
import {useNavigate} from "react-router-dom";
import {GOOGLE_REDIRECT_URL, FACEBOOK_REDIRECT_URL} from "../../../service/api/commonApi.js";

export const CustomerLoginForm = () => {
    const navigate = useNavigate();

    const [login, setLogin] = useState("");
    const [password, setPassword] = useState("");
    const [rememberMe, setRememberMe] = useState(false);

    const [focused, setFocused] = useState({
        login: false,
        password: false,
    });

    const [errors, setErrors] = useState({});
    const [loginErrorMessage, setLoginErrorMessage] = useState("");

    const handleFocus = (field) => {
        setErrors({...errors, [field]: ''});
        setFocused({...focused, [field]: true});
    };

    const handleBlur = (field) => {
        if (
            (field === 'login' && !login) ||
            (field === 'password' && !password)
        ) {
            setFocused({...focused, [field]: false});
        }
    };

    const validateForm = () => {
        const newErrors = {};
        if (!login.trim()) {
            newErrors.login = "Login cannot be empty";
        }
        if (!password.trim()) {
            newErrors.password = "Password cannot be empty";
        }
        return newErrors;
    };

    const loginFunction = async (e) => {
        e.preventDefault();
        const validationErrors = validateForm();
        if (Object.keys(validationErrors).length === 0) {
            try {
                const response = await Login(login, password);
                const body = await response.json();

                if (response.ok) {
                    if (rememberMe) {
                        localStorage.setItem("jwt_client", body.token);
                    } else {
                        sessionStorage.setItem("jwt_client", body.token);
                    }
                    navigate("/");
                } else {
                    const body = await response.json();
                    switch (response.status) {
                        case 404:
                            setLoginErrorMessage("404 error: Not found");
                            break;
                        case 400:
                            setLoginErrorMessage("400 error: Bad request");
                            break;
                        case 500:
                            setLoginErrorMessage("500 error: Internal server error");
                            break;
                        default:
                            if (body.message === "auth/0001") {
                                setLoginErrorMessage("Invalid login or password");
                            } else {
                                setLoginErrorMessage("Unknown error encountered");
                            }
                            break;
                    }
                }
            } catch (error) {
                setLoginErrorMessage("Unknown error encountered");
            }
        } else {
            setErrors(validationErrors);
        }
    };

    return (
        <div className="common__auth-container">
            <form className="common__auth-form" onSubmit={loginFunction}>
                <h2 className="common__auth-form--title" style={{color: 'black'}}>Sign in</h2>

                <div className="common__auth-form--field">
                    <label htmlFor="login" className={focused.login ? 'focused' : ''}>
                        Your Login
                    </label>
                    <input
                        type="text"
                        id="login"
                        name="login"
                        value={login}
                        onFocus={() => handleFocus('login')}
                        onBlur={() => handleBlur('login')}
                        onChange={(e) => {
                            setLogin(e.target.value);
                        }}
                    />
                    {errors.login && <p className="common__auth--error-message">{errors.login}</p>}
                </div>

                <div className="common__auth-form--field" style={{marginBottom: '15px'}}>
                    <label htmlFor="password" className={focused.password ? 'focused' : ''}>
                        Password
                    </label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={password}
                        onFocus={() => handleFocus('password')}
                        onBlur={() => handleBlur('password')}
                        onChange={(e) => {
                            setPassword(e.target.value);
                        }}
                    />
                    {errors.password && <p className="common__auth--error-message">{errors.password}</p>}
                </div>

                <div className="common__remember-me">
                    <label htmlFor="rememberMe">
                        <input
                            type="checkbox"
                            id="rememberMe"
                            name="rememberMe"
                            checked={rememberMe}
                            onChange={(e) => setRememberMe(e.target.checked)}
                        />
                        <span></span> Remember me
                    </label>
                </div>

                {loginErrorMessage && <p className="common__auth--error-message">{loginErrorMessage}</p>}

                <button type="submit" className="common__register-login--button">
                    Sign in
                </button>

                <div className="common__login--redirect" style={{color: 'black'}}>
                    Don't have an account yet? <a href="/register">Register now</a>
                </div>
                <div className="common__login--redirect" style={{color: 'black', marginTop: '10px'}}>
                    Can't log in? <a href="/password/reset">Click here to reset your password.</a>
                </div>

                <div className="common__auth--separator">
                    <hr className="common__auth--separator-line"/>
                    <span className="common__auth--separator-text">or sign in with</span>
                    <hr className="common__auth--separator-line"/>
                </div>

                <div className="common__social--login-buttons">
                    <button className="common__social--login-button" onClick={() =>
                        window.location.href = GOOGLE_REDIRECT_URL}>
                        <FcGoogle/>
                        Google
                    </button>
                    <button className="common__social--login-button" onClick={() =>
                        window.location.href = FACEBOOK_REDIRECT_URL}>
                        <FaFacebookSquare/>
                        Facebook
                    </button>
                </div>
            </form>
        </div>
    );
};