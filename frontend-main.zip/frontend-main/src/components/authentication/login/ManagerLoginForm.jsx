import React, {useState} from 'react';
import '../AuthenticationForm.scss';
import {ManagerLogin} from "../../../service/api/managerApi.js";
import {useNavigate} from "react-router-dom";

export const ManagerLoginForm = () => {
    const navigate = useNavigate();

    const [login, setLogin] = useState("");
    const [password, setPassword] = useState("");

    const [focused, setFocused] = useState({
        login: false,
        password: false,
    });

    const [errors, setErrors] = useState({});
    const [loginErrorMessage, setLoginErrorMessage] = useState("");

    const handleFocus = (field) => {
        setErrors({...errors, [field]: ''});
        setFocused({...focused, [field]: true});
    };

    const handleBlur = (field) => {
        if (
            (field === 'login' && !login) ||
            (field === 'password' && !password)
        ) {
            setFocused({...focused, [field]: false});
        }
    };

    const validateForm = () => {
        const newErrors = {};

        if (!login.trim()) {
            newErrors.login = "Login cannot be empty";
        }
        if (!password.trim()) {
            newErrors.password = "Password cannot be empty";
        }
        return newErrors;
    };

    const loginFunction = async (e) => {
        e.preventDefault();
        const validationErrors = validateForm();

        if (Object.keys(validationErrors).length === 0) {
            try {
                const response = await ManagerLogin(login, password);

                if (response.ok) {
                    const body = await response.json();
                    sessionStorage.setItem("jwt_manager", body.token);
                    navigate("/manager");

                } else {
                    const body = await response.json();
                    switch (response.status) {
                        case 404:
                            setLoginErrorMessage("404 error: Not found");
                            break;
                        case 400:
                            setLoginErrorMessage("400 error: Bad request");
                            break;
                        case 500:
                            setLoginErrorMessage("500 error: Internal server error");
                            break;
                        default:
                            if (body.message === "auth/0001") {
                                setLoginErrorMessage("Invalid login or password");
                            } else {
                                setLoginErrorMessage("Unknown error encountered");
                            }
                            break;
                    }
                }
            } catch (error) {
                setLoginErrorMessage("Unknown error encountered");
            }
        } else {
            setErrors(validationErrors);
        }
    };

    return (
        <div className="common__auth-container">
            <form className="common__auth-form" onSubmit={loginFunction}>
                <h2 className="common__auth-form--title" style={{color: 'black'}}>Sign in</h2>

                <div className="common__auth-form--field">
                    <label htmlFor="login" className={focused.login ? 'focused' : ''}>
                        Your Login
                    </label>
                    <input
                        type="text"
                        id="login"
                        name="login"
                        value={login}
                        onFocus={() => handleFocus('login')}
                        onBlur={() => handleBlur('login')}
                        onChange={(e) => {
                            setLogin(e.target.value);
                        }}
                    />
                    {errors.login && <p className="common__auth--error-message">{errors.login}</p>}
                </div>

                <div className="common__auth-form--field" style={{marginBottom: '15px'}}>
                    <label htmlFor="password" className={focused.password ? 'focused' : ''}>
                        Password
                    </label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={password}
                        onFocus={() => handleFocus('password')}
                        onBlur={() => handleBlur('password')}
                        onChange={(e) => {
                            setPassword(e.target.value);
                        }}
                    />
                    {errors.password && <p className="common__auth--error-message">{errors.password}</p>}
                </div>

                {loginErrorMessage && <p className="common__auth--error-message">{loginErrorMessage}</p>}

                <button type="submit" className="common__register-login--button" style={{marginTop: '40px', marginLeft: '10px'}}>
                    Sign in
                </button>

            </form>
        </div>
    );
};