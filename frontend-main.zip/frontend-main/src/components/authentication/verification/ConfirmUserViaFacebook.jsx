import React, {useEffect} from 'react';
import {useNavigate, useSearchParams} from 'react-router-dom';
import {OrbitProgress} from 'react-loading-indicators';
import './ConfirmUser.scss';

const ConfirmUserViaFacebook = () => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const token = searchParams.get('token');

    useEffect(() => {
        if (token) {
            sessionStorage.setItem("jwt_client", token);
            setTimeout(() => {
                navigate('/');
            }, 1500);
        }
    }, [token, navigate]);

    return (
        <div className="client__confirm-user--container">
            <div className="client__confirm-user--loading-wrapper">
                <OrbitProgress color="#042748" size="large"/>
                <p className="client__confirm-user--text">Confirming user...</p>
            </div>
        </div>
    );
};

export default ConfirmUserViaFacebook;