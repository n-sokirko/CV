import React from 'react';
import './../passwordReset/Validation.scss';

const ActivateAccountInfo = () => {
    return (
        <div className="common__verification-success--container">
            <div className="common__verification-message--container">
                <h1>Activate Your Account</h1>
                <p>To complete your registration, please check your email and click the link we sent.</p>
            </div>
        </div>
    );
};

export default ActivateAccountInfo;