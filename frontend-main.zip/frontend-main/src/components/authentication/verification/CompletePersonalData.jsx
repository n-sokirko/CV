import React, {useEffect, useState} from 'react';
import './../AuthenticationForm.scss';
import {useNavigate} from "react-router-dom";
import {OrbitProgress} from 'react-loading-indicators';
import {completePersonalInfo} from "../../../service/api/customerApi.js";

const CompletePersonalData = ({userData}) => {

    useEffect(() => {
        const fullName = userData.name || "";
        const splitName = fullName.split(" ");
        setName(splitName[0] || "");
        setLastname(splitName[1] || "");
        setEmail(userData.email || "");
        setPhone(userData.phone || "");
        setEmailChangeable(userData.isChangeableEmail !== false);
    }, [userData]);

    const navigate = useNavigate();

    const [name, setName] = useState("");
    const [lastname, setLastname] = useState("");
    const [email, setEmail] = useState("");
    const [isEmailChangeable, setEmailChangeable] = useState(true);
    const [phone, setPhone] = useState("");
    const [isLoading, setLoading] = useState(false);

    const [errors, setErrors] = useState({});
    const [completeDataErrorMessage, setCompleteDataErrorMessage] = useState("");

    const validateForm = () => {
        const newErrors = {};
        const namePattern = /^[A-Za-z]+$/;
        const emailPattern = /\S+@\S+\.\S+/;
        const phonePattern = /^\d{3}-\d{3}-\d{3}$/;

        if (!name.trim()) {
            newErrors.name = "Name cannot be empty";
        } else if (!namePattern.test(name)) {
            newErrors.name = "Name can only contain letters";
        }

        if (!lastname.trim()) {
            newErrors.lastname = "Last name cannot be empty";
        } else if (!namePattern.test(lastname)) {
            newErrors.lastname = "Last name can only contain letters";
        }

        if (!email.trim()) {
            newErrors.email = "Email cannot be empty";
        } else if (!emailPattern.test(email)) {
            newErrors.email = "Email is invalid";
        }

        if (!phone.trim()) {
            newErrors.phone = "Phone number cannot be empty";
        } else if (!phonePattern.test(phone)) {
            newErrors.phone = "Phone number must match pattern e.g. 123-456-789";
        }

        return newErrors;
    };

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };

    const completePersonalDataFunction = async (e) => {
        e.preventDefault();
        const token = getToken();
        setLoading(true);
        const validationErrors = validateForm();

        if (Object.keys(validationErrors).length === 0) {
            try {
                const response = await completePersonalInfo(name, lastname, phone, email, token, isEmailChangeable);

                if (response.ok) {
                    navigate("/", {state: {refreshData: true}});
                } else {
                    const body = await response.json();
                    if (body.code === "client/0001") {
                        setCompleteDataErrorMessage("Email cannot be changed.");
                    } else if (body.code === "client/0002") {
                        setCompleteDataErrorMessage("A user with this phone number already exists.");
                    } else {
                        setCompleteDataErrorMessage("Unknown error encountered during completing personal data");
                    }
                }
            } catch (error) {
                setCompleteDataErrorMessage("Server error. Please try again later.");
                console.error("Error during completing personal data:", error);
            }
        } else {
            setErrors(validationErrors);
        }
        setLoading(false);
    };

    return (
        <div className="common__auth-container">
            {isLoading ? (
                <div className="loading-container">
                    <OrbitProgress color="#666" size="large"/>
                    <p style={{color: '#666'}}>Completing your personal data...</p>
                </div>
            ) : (
                <form className="common__auth-form complete-personal-data-form" onSubmit={completePersonalDataFunction}>
                    <h2 className="common__auth-form--title" style={{color: 'black'}}>To continue, please complete your personal
                        information</h2>

                    <div className="common__auth-form--field">
                        <label htmlFor="name" className="focused">
                            Your Name
                        </label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            value={name}
                            onChange={(e) => {
                                setName(e.target.value);
                            }}
                        />
                        {errors.name && <p className="common__auth--error-message">{errors.name}</p>}
                    </div>

                    <div className="common__auth-form--field">
                        <label htmlFor="lastname" className="focused">
                            Your Last Name
                        </label>
                        <input
                            type="text"
                            id="lastname"
                            name="lastname"
                            value={lastname}
                            onChange={(e) => {
                                setLastname(e.target.value);
                            }}
                        />
                        {errors.lastname && <p className="common__auth--error-message">{errors.lastname}</p>}
                    </div>

                    <div className="common__auth-form--field">
                        <label htmlFor="email" className="focused">
                            Your Email
                        </label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={email}
                            readOnly={!isEmailChangeable}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                        {errors.email && <p className="common__auth--error-message">{errors.email}</p>}
                    </div>

                    <div className="common__auth-form--field">
                        <label htmlFor="phone" className="focused">
                            Your Phone Number
                        </label>
                        <input
                            type="tel"
                            id="phone"
                            name="phone"
                            value={phone}
                            onChange={(e) => {
                                setPhone(e.target.value);
                            }}
                        />
                        {errors.phone && <p className="common__auth--error-message">{errors.phone}</p>}
                    </div>

                    {completeDataErrorMessage && <p className="common__auth--error-message">{completeDataErrorMessage}</p>}

                    <button type="submit" className="common__register-login--button">
                        Save
                    </button>
                </form>
            )}
        </div>
    );
};

export default CompletePersonalData;