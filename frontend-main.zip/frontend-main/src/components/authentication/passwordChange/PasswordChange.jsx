import React, {useEffect, useState} from 'react';
import './../AuthenticationForm.scss';
import {useNavigate} from "react-router-dom";
import {OrbitProgress} from 'react-loading-indicators';
import {changePassword} from "../../../service/api/customerApi.js";

export const PasswordChange = () => {
    const navigate = useNavigate();

    const [oldPassword, setOldPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [repeatPassword, setRepeatPassword] = useState("");
    const [isLoading, setLoading] = useState(false);
    const [focused, setFocused] = useState({
        oldPassword: false,
        newPassword: false,
        repeatPassword: false,
    });

    const [errors, setErrors] = useState({});
    const [changePasswordErrorMessage, setChangePasswordErrorMessage] = useState("");

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, []);

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        return sessionStorageToken || localStorageToken;
    };

    const handleFocus = (field) => {
        setErrors({...errors, [field]: ''});
        setFocused({...focused, [field]: true});
    };

    const handleBlur = (field) => {
        if (
            (field === 'oldPassword' && !oldPassword) ||
            (field === 'newPassword' && !newPassword) ||
            (field === 'repeatPassword' && !repeatPassword)
        ) {
            setFocused({...focused, [field]: false});
        }
    };

    const validateForm = () => {
        const newErrors = {};
        const minPasswordLength = 8;
        if (!oldPassword.trim()) {
            newErrors.oldPassword = "Password cannot be empty";
        }
        if (!newPassword.trim()) {
            newErrors.newPassword = "New password cannot be empty";
        } else if (newPassword.length < minPasswordLength) {
            newErrors.newPassword = "New password should be at least 8 characters.";
        }

        if (!repeatPassword.trim()) {
            newErrors.repeatPassword = "Repeated password cannot be empty";
        } else if (newPassword !== repeatPassword) {
            newErrors.repeatPassword = "New password and repeated password must be identical";
        }

        return newErrors;
    };

    const changePasswordFunction = async (e) => {
        e.preventDefault();
        setLoading(true);
        const validationErrors = validateForm();
        const token = getToken();

        if (Object.keys(validationErrors).length === 0) {
            try {
                const response = await changePassword(oldPassword, newPassword, repeatPassword, token);

                if (response.status === 204) {
                    navigate("/password/change/success");
                } else {
                    const body = await response.json();
                    if (body.code === "auth/0012") {
                        setChangePasswordErrorMessage("Invalid current password");
                    } else if (body.code === "auth/0013") {
                        setChangePasswordErrorMessage("Passwords do not match");
                    } else {
                        setChangePasswordErrorMessage("Unknown error encountered during password change");
                    }
                }
            } catch (error) {
                setChangePasswordErrorMessage("Server error. Please try again later.");
                console.error("Error during password change:", error);
            }
        } else {
            setErrors(validationErrors);
        }
        setLoading(false);
    };

    return (
        <div className="common__auth-container">
            {isLoading ? (
                <div className="loading-container">
                    <OrbitProgress color="#666" size="large"/>
                    <p style={{color: '#666'}}>Changing your password...</p>
                </div>
            ) : (
                <form className="common__auth-form" onSubmit={changePasswordFunction}>
                    <h2 className="common__auth-form--title" style={{color: 'black', marginTop: '-50px'}}>Change your
                        password</h2>

                    <div className="common__auth-form--field">
                        <label htmlFor="oldPassword" className={focused.oldPassword ? 'focused' : ''}>
                            Current Password
                        </label>
                        <input
                            type="password"
                            id="oldPassword"
                            name="oldPassword"
                            value={oldPassword}
                            onFocus={() => handleFocus('oldPassword')}
                            onBlur={() => handleBlur('oldPassword')}
                            onChange={(e) => setOldPassword(e.target.value)}
                        />
                        {errors.oldPassword && <p className="common__auth--error-message">{errors.oldPassword}</p>}
                    </div>

                    <div className="common__auth-form--field">
                        <label htmlFor="newPassword" className={focused.newPassword ? 'focused' : ''}>
                            New Password
                        </label>
                        <input
                            type="password"
                            id="newPassword"
                            name="newPassword"
                            value={newPassword}
                            onFocus={() => handleFocus('newPassword')}
                            onBlur={() => handleBlur('newPassword')}
                            onChange={(e) => setNewPassword(e.target.value)}
                        />
                        {errors.newPassword && <p className="common__auth--error-message">{errors.newPassword}</p>}
                    </div>

                    <div className="common__auth-form--field" style={{marginBottom: '15px'}}>
                        <label htmlFor="repeatPassword" className={focused.repeatPassword ? 'focused' : ''}>
                            Repeat New Password
                        </label>
                        <input
                            type="password"
                            id="repeatPassword"
                            name="repeatPassword"
                            value={repeatPassword}
                            onFocus={() => handleFocus('repeatPassword')}
                            onBlur={() => handleBlur('repeatPassword')}
                            onChange={(e) => setRepeatPassword(e.target.value)}
                        />
                        {errors.repeatPassword && <p className="common__auth--error-message">{errors.repeatPassword}</p>}
                    </div>

                    {changePasswordErrorMessage && <p className="common__auth--error-message">{changePasswordErrorMessage}</p>}

                    <button type="submit" className="common__register-login--button">
                        Change password
                    </button>
                </form>
            )}
        </div>
    );
};