import React, {useEffect} from 'react';
import {Link, useNavigate} from 'react-router-dom';
import './../passwordReset/Validation.scss';

const ChangeSuccess = () => {
    const navigate = useNavigate();

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, []);

    return (
        <div className="common__verification-success--container">
            <div className="common__verification-message--container">
                <h1>Password Change Successful</h1>
                <p>Your password has been successfully changed.</p>
                <Link to="/" className="common__verification-login--link">Go Home</Link>
            </div>
        </div>
    );
};

export default ChangeSuccess;