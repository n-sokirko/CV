import React, { useState, useEffect, useRef } from 'react';
import {
  fetchRooms,
  fetchTablesByRoomId,
  addRoom,
  addTable,
  updateTable,
  deleteTable,
  deleteRoom,
} from '../../service/api/managerApi';
import RoomSelection from './RoomSelection';
import RoomLayout from './RoomLayout';
import EditTableForm from './EditTableForm';
import './RoomLayoutManager.scss';

function RoomLayoutManager() {
  const [rooms, setRooms] = useState([]);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [tables, setTables] = useState([]);
  const [newRoom, setNewRoom] = useState({ length: 0, width: 0 });
  const [newTable, setNewTable] = useState({
    tableNumber: 0,
    numberOfSeats: 2,
    coordinateY: 0,
    coordinateX: 0,
  });
  const [editingTable, setEditingTable] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const formRef = useRef(null);

  useEffect(() => {
    loadRooms();
  }, []);

  const loadRooms = async () => {
    try {
      const roomsData = await fetchRooms();
      setRooms(roomsData.content || []);
    } catch (error) {
      setErrorMessage('Failed to load rooms.');
    }
  };

  const loadTables = async (roomId) => {
    try {
      const tablesData = await fetchTablesByRoomId(roomId);
      setTables(tablesData.content.filter((table) => table.roomId === roomId) || []);
    } catch (error) {
      setErrorMessage('Failed to load tables.');
    }
  };

  const handleRoomSelect = (index) => {
    const room = rooms[index];
    if (room) {
      setSelectedRoom(room);
      loadTables(room.id);
      clearMessages();
    }
  };

  const handleAddRoom = async () => {
    if (newRoom.length < 1 || newRoom.width < 1) {
      setErrorMessage('Room size cannot be smaller than 1x1.');
      return;
    }

    if (newRoom.length > 50 || newRoom.width > 50) {
      setErrorMessage('Room size cannot be larger than 50x50.');
      return;
    }

    try {
      await addRoom(newRoom);
      setNewRoom({ length: 0, width: 0 });
      loadRooms();
      setSuccessMessage('Room added successfully.');
    } catch (error) {
      setErrorMessage('Error adding room.');
    }
  };

  const handleAddTable = async () => {
    if (selectedRoom) {
      let newTableNumber = 1;
      while (tables.some((table) => table.tableNumber === newTableNumber)) {
        newTableNumber++;
      }

      let newY = -1;
      let newX = -1;
      let positionFound = false;

      for (let y = 0; y < selectedRoom.width; y++) {
        for (let x = 0; x < selectedRoom.length; x++) {
          const positionExists = tables.some(
            (table) => table.coordinateY === y && table.coordinateX === x
          );
          if (!positionExists) {
            newY = y;
            newX = x;
            positionFound = true;
            break;
          }
        }
        if (positionFound) break;
      }

      if (!positionFound) {
        setErrorMessage('Room is full. Cannot add more tables.');
        return;
      }

      try {
        const addedTable = await addTable({
          ...newTable,
          roomId: selectedRoom.id,
          tableNumber: newTableNumber,
          coordinateY: newY,
          coordinateX: newX,
        });
        setTables((prevTables) => [...prevTables, addedTable]);
        setNewTable({
          tableNumber: 0,
          numberOfSeats: 2,
          coordinateY: 0,
          coordinateX: 0,
        });
        setSuccessMessage('Table added successfully.');
      } catch (error) {
        setErrorMessage('Error adding table.');
      }
    }
  };

  const handleEditTable = (table) => {
    setEditingTable(table);
  };

  const handleUpdateTableDetails = async (updatedTable) => {
    const tableNumberExists = tables.some(
      (table) =>
        table.tableNumber === updatedTable.tableNumber &&
        table.id !== updatedTable.id
    );

    if (tableNumberExists) {
      setErrorMessage('A table with this number already exists in the room. Please choose a different number.');
      return;
    }

    if (updatedTable.tableNumber < 1) {
      setErrorMessage('Table number must be positive.');
      return;
    }

    if (updatedTable.numberOfSeats < 1) {
      setErrorMessage('Number of seats must be positive.');
      return;
    }

    try {
      await updateTable(updatedTable.id, updatedTable);
      setTables((prevTables) =>
        prevTables.map((table) =>
          table.id === updatedTable.id ? updatedTable : table
        )
      );
      setEditingTable(null);
      setSuccessMessage('Table updated successfully.');
    } catch (error) {
      setErrorMessage('Error updating table.');
    }
  };

  const handleDeleteTable = async (tableId) => {
    setEditingTable(null);
    setIsDeleting(true);
    try {
      await deleteTable(tableId);
      setTables((prevTables) => prevTables.filter((table) => table.id !== tableId));
      setSuccessMessage('Table deleted successfully.');
    } catch (error) {
      setErrorMessage('Failed to delete table.');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleDeleteRoom = async () => {
    if (!selectedRoom) {
      setErrorMessage('No room selected to delete.');
      return;
    }

    if (!window.confirm('Are you sure you want to delete this room and all its tables?')) {
      return;
    }

    setIsDeleting(true);
    try {
      await deleteRoom(selectedRoom.id);
      setRooms((prevRooms) => prevRooms.filter((room) => room.id !== selectedRoom.id));
      setSelectedRoom(null);
      setTables([]);
      setSuccessMessage('Room and its tables deleted successfully.');
    } catch (error) {
      setErrorMessage('Error deleting room. Make sure all tables are deleted.');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleTablePositionChange = (tableId, newX, newY) => {
    const isOccupied = tables.some(
      (table) =>
        table.id !== tableId &&
        table.coordinateX === newX &&
        table.coordinateY === newY
    );

    if (isOccupied) {
      setErrorMessage('Cannot place two tables in the same position.');
      return;
    }

    setTables((prevTables) =>
      prevTables.map((t) =>
        String(t.id) === String(tableId) ? { ...t, coordinateX: newX, coordinateY: newY } : t
      )
    );
    setSuccessMessage('Table moved successfully.');
  };

  const toggleEditMode = () => {
    setIsEditMode((prevMode) => !prevMode);
    if (isEditMode) {
      handleSaveLayout();
    }
    clearMessages();
  };

  const handleSaveLayout = async () => {
    try {
      for (const table of tables) {
        await updateTable(table.id, table);
      }
      setSuccessMessage('Layout saved successfully.');
    } catch (error) {
      setErrorMessage('Error saving table positions.');
    }
  };

  const handleClickOutside = (e) => {
    if (formRef.current && !formRef.current.contains(e.target)) {
      setEditingTable(null);
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const clearMessages = () => {
    if (errorMessage) setErrorMessage('');
    if (successMessage) setSuccessMessage('');
  };

  useEffect(() => {
    if (errorMessage || successMessage) {
      const timer = setTimeout(() => {
        clearMessages();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage, successMessage]);

  const existingTableNumbers = tables
    .filter((t) => editingTable ? t.id !== editingTable.id : true)
    .map((t) => t.tableNumber);

  return (
    <div className="manager__room-layout-manager">
      <h1 className="manager__room-layout-manager--title">Room Layout Manager</h1>

      {errorMessage && <div className="manager__room-layout-manager--error-message">{errorMessage}</div>}
      {successMessage && <div className="manager__room-layout-manager--success-message">{successMessage}</div>}

      <RoomSelection
        rooms={rooms}
        handleRoomSelect={handleRoomSelect}
        handleAddRoom={handleAddRoom}
        newRoom={newRoom}
        setNewRoom={setNewRoom}
        disabled={editingTable !== null || isDeleting}
      />
      {selectedRoom && (
        <div className="manager__room-layout-manager--layout-and-editor">
          <div className="manager__room-layout-manager--controls">
            <button
              className="manager__room-layout-manager--button"
              onClick={handleAddTable}
              disabled={editingTable !== null || isDeleting}
            >
              Add New Table
            </button>
            <button
              className="manager__room-layout-manager--button"
              onClick={toggleEditMode}
              disabled={editingTable !== null || isDeleting}
            >
              {isEditMode ? 'Save' : 'Edit'}
            </button>
            <button
              className="manager__room-layout-manager--button manager__room-layout-manager--delete-button"
              onClick={handleDeleteRoom}
              disabled={isDeleting}
            >
              Delete Room
            </button>
          </div>
          <RoomLayout
            selectedRoom={selectedRoom}
            tables={tables}
            onTableClick={handleEditTable}
            onTablePositionChange={handleTablePositionChange}
            isEditing={isEditMode}
            editingTable={editingTable}
          />
          {editingTable && (
            <div ref={formRef}>
              <EditTableForm
                table={editingTable}
                onUpdateTable={handleUpdateTableDetails}
                onCancel={() => setEditingTable(null)}
                onDeleteTable={handleDeleteTable}
                existingTableNumbers={existingTableNumbers}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default RoomLayoutManager;
