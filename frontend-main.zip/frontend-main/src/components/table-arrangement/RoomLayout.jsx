import React, { useRef, useEffect } from 'react';
import './RoomLayout.scss';

function RoomLayout({
  selectedRoom,
  tables,
  onTableClick,
  onTablePositionChange,
  isEditing,
  editingTable,
}) {
  const roomLayoutRef = useRef(null);
  const gridSize = 80; 
  const tableSize = 80; 

  useEffect(() => {}, [tables]);

  const handleMouseDown = (e, tableId) => {
    if (!isEditing || e.button !== 0) return;
    e.preventDefault();

    const tableElement = e.target;
    const offsetX = e.clientX - tableElement.getBoundingClientRect().left;
    const offsetY = e.clientY - tableElement.getBoundingClientRect().top;

    const table = tables.find((t) => t.id === tableId);
    const previousPosition = {
      coordinateX: table.coordinateX,
      coordinateY: table.coordinateY,
    };

    const handleMouseMove = (moveEvent) => {
      moveEvent.preventDefault();

      const roomRect = roomLayoutRef.current.getBoundingClientRect();
      let newLeft = moveEvent.clientX - roomRect.left - offsetX;
      let newTop = moveEvent.clientY - roomRect.top - offsetY;

      newLeft = Math.round(newLeft / gridSize) * gridSize;
      newTop = Math.round(newTop / gridSize) * gridSize;

      const newY = newLeft / gridSize;
      const newX = newTop / gridSize;

      if (
        newX >= 0 &&
        newX < selectedRoom.length &&
        newY >= 0 &&
        newY < selectedRoom.width
      ) {
        const overlappingTable = tables.find(
          (t) =>
            t.id !== tableId &&
            t.coordinateX === newX &&
            t.coordinateY === newY
        );

        if (!overlappingTable) {
          if (onTablePositionChange) {
            onTablePositionChange(tableId, newX, newY);
          }
        }
      }
    };

    const handleMouseUp = () => {
      const overlappingTable = tables.find(
        (t) =>
          t.id !== tableId &&
          t.coordinateX === table.coordinateX &&
          t.coordinateY === table.coordinateY
      );

      if (overlappingTable) {
        onTablePositionChange(
          tableId,
          previousPosition.coordinateX,
          previousPosition.coordinateY
        );
      }

      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleTableClick = (e, table) => {
    e.stopPropagation();
    if (e.button === 2 && onTableClick) {
      e.preventDefault();
      onTableClick(table);
    }
  };

  return (
    <div className="manager_room-layout">
      <h2>Room Layout: {selectedRoom.id}</h2>
      <div className="manager_room-scroll-container">
        <div
          className="manager_room"
          ref={roomLayoutRef}
          style={{
            width: selectedRoom.width * gridSize,
            height: selectedRoom.length * gridSize,
            position: 'relative',
          }}
          onContextMenu={(e) => e.preventDefault()}
        >
          {tables.map((table) => (
            <div
              key={table.id}
              className={`manager_table ${
                editingTable && editingTable.id === table.id
                  ? 'table-highlight'
                  : ''
              }`}
              onMouseDown={(e) => handleMouseDown(e, table.id)}
              onContextMenu={(e) => handleTableClick(e, table)}
              title={`Table Number: ${table.tableNumber}`}
              style={{
                position: 'absolute',
                width: tableSize,
                height: tableSize,
                left: table.coordinateY * gridSize,
                top: table.coordinateX * gridSize,
              }}
            >
              <div className="manager_table-number">Table {table.tableNumber}</div>
              <div className="manager_table-seats">{table.numberOfSeats} Seats</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default RoomLayout;