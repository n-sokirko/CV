import React from 'react';
import './RoomSelection.scss';

function RoomSelection({ rooms, handleRoomSelect, handleAddRoom, newRoom, setNewRoom, disabled }) {
  return (
    <div className="manager_room-selection">
      <h2>Rooms</h2>
      <div className="manager_room-selection-input-group">
        <select onChange={(e) => handleRoomSelect(e.target.value)} disabled={disabled}>
          <option className="manager_room-selection-dropdown">Select Room</option>
          {Array.isArray(rooms) && rooms.map((room, index) => (
            <option key={room.id} value={index}>{`Room ${room.id}`}</option>
          ))}
        </select>
        <button onClick={handleAddRoom} disabled={disabled}>Add Room</button>
        
        <div className="manager_room-size-inputs">
          <label>
            Room Length:
            <input
              className="manager_room-selection-input"
              type="number"
              placeholder="Room Length"
              value={newRoom.length}
              onChange={(e) => setNewRoom({ ...newRoom, length: +e.target.value })}
              disabled={disabled}
              max={10} 
            />
          </label>
          <label>
            Room Width:
            <input
              className="manager_room-selection-input"
              type="number"
              placeholder="Room Width"
              value={newRoom.width}
              onChange={(e) => setNewRoom({ ...newRoom, width: +e.target.value })}
              disabled={disabled}
              max={10} 
            />
          </label>
        </div>
        <p className="manager_room-size-info">Room size must be between 1x1 and 10x10 .</p>
      </div>
    </div>
  );
}

export default RoomSelection;