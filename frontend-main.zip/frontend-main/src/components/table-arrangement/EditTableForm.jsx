import React, { useState, useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from "html5-qrcode";
import './EditTableForm.scss';

function EditTableForm({ table, onUpdateTable, onCancel, onDeleteTable }) {
  const [updatedTable, setUpdatedTable] = useState({ ...table });
  const [qrCodeUrl, setQrCodeUrl] = useState(null);
  const formRef = useRef(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUpdatedTable((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onUpdateTable(updatedTable);
  };

  const handleClickOutside = (e) => {
    if (formRef.current && !formRef.current.contains(e.target)) {
      onCancel();
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const generateQrCode = () => {
    const qrCodeData = `dinning_desk=${updatedTable.id}`;
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(qrCodeData)}&size=300x300`;

    setQrCodeUrl(qrCodeUrl);
  };

  const downloadQrCode = () => {
    if (!qrCodeUrl) return;

    fetch(qrCodeUrl)
      .then(response => response.blob())
      .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `table-${updatedTable.tableNumber}-qrcode.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      })
      .catch(err => console.error('Failed to download QR code', err));
  };

  return (
    <div className="manager__edit-table-form" ref={formRef}>
      <h3 className="manager__edit-table-form--title">Edit Table Details</h3>
      <form onSubmit={handleSubmit}>
        <label className="manager__edit-table-form--label">
          Table Number:
          <input
            className="manager__edit-table-form--input"
            type="number"
            name="tableNumber"
            value={updatedTable.tableNumber}
            onChange={handleChange}
          />
        </label>
        <label className="manager__edit-table-form--label">
          Number of Seats:
          <input
            className="manager__edit-table-form--input"
            type="number"
            name="numberOfSeats"
            value={updatedTable.numberOfSeats}
            onChange={handleChange}
          />
        </label>
        <div className="manager__edit-table-form--buttons">
          <button className="manager__edit-table-form--button" type="submit">Save Changes</button>
          <button className="manager__edit-table-form--button" type="button" onClick={onCancel}>
            Cancel
          </button>
          <button className="manager__edit-table-form--button manager__edit-table-form--delete-button" type="button" onClick={() => onDeleteTable(table.id)}>
            Delete Table
          </button>
          <button className="manager__edit-table-form--button" type="button" onClick={generateQrCode}>
            Generate QR Code
          </button>
          {qrCodeUrl && (
            <button className="manager__edit-table-form--button" type="button" onClick={downloadQrCode}>
              Download QR Code
            </button>
          )}
        </div>
      </form>
      {qrCodeUrl && (
        <div className="manager__edit-table-form--qr-code">
          <img src={qrCodeUrl} alt="QR Code" />
        </div>
      )}
    </div>
  );
}

export default EditTableForm;