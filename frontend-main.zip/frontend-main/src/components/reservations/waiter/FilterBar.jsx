import React, {useState} from 'react';
import './FilterBar.scss';

const FilterBar = ({onDateFilterChange}) => {
    const [datesFilter, setDatesFilter] = useState({start: "", end: ""});

    const applyFilters = () => {
        onDateFilterChange(datesFilter);
    };

    const clearFilters = () => {
        setDatesFilter({start: "", end: ""});
        onDateFilterChange({start: "", end: ""});
    };

    const updateDateRange = (event) => {
        const {name, value} = event.target;
        setDatesFilter(prev => ({
            ...prev,
            [name]: value
        }));
    };

    return (
        <div className="waiter__filter-bar--container">
            <div className="waiter__filter-bar--date-filter">
                <label>
                    Start Date:
                    <input
                        type="date"
                        name="start"
                        value={datesFilter.start}
                        onChange={updateDateRange}
                    />
                </label>
                <label>
                    End Date:
                    <input
                        type="date"
                        name="end"
                        value={datesFilter.end}
                        onChange={updateDateRange}
                    />
                </label>
            </div>
            <button className="waiter__filter-bar--filter-button apply" onClick={applyFilters}>Apply</button>
            <button className="waiter__filter-bar--filter-button clear" onClick={clearFilters}>Clear</button>
        </div>
    );
};

export default FilterBar;