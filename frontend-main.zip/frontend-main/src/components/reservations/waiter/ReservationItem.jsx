import React, { useState, useEffect } from "react";
import './ReservationItem.scss';
import { getTableById } from "../../../service/api/waiterApi.js";

const ReservationItem = ({ id, clientName, date, startTime, endTime, diningDeskIds, notes, status, numberOfGuests }) => {
    const [isMoreDisplayed, setMoreVisible] = useState(false);
    const [tablesDetails, setTablesDetails] = useState([]);

    const displayDetails = () => {
        setMoreVisible(!isMoreDisplayed);
    };

    useEffect(() => {
        const getTablesDetails = async () => {
            const details = await Promise.all(diningDeskIds.map(async (tableId) => {
                try {
                    const response = await getTableById(tableId);
                    const data = await response.json();
                    return `Room Number: ${data.roomId}, Table Number: ${data.tableNumber}`;
                } catch (error) {
                    console.error('Failed to get table details:', error);
                    return 'Fetching failed';
                }
            }));
            setTablesDetails(details);
        };

        getTablesDetails();
    }, [diningDeskIds]);

    return (
        <div className="waiter__reservation-item">
            <span className={`waiter__reservation-item--reservation-status-label ${status.toLowerCase()}`}>{status}</span>
            <div className="waiter__reservation-item--reservation-details">
                <h5 className="waiter__reservation-item--client-name">{clientName}</h5>
                <div className="waiter__reservation-item--reservation-id">Reservation ID: {id}</div>
                <div>Date: {date}</div>
                <div>Time: {startTime} - {endTime}</div>
                <div className="waiter__reservation-item--reservation-buttons">
                    <button className="waiter__reservation-item--reservation-more-button" onClick={displayDetails}>More</button>
                </div>
            </div>
            {isMoreDisplayed && (
                <div className="waiter__reservation-item--more-info-window">
                    <div className="waiter__reservation-item--window-content">
                        <div className="waiter__reservation-item--details-section">
                            <h4>Reservation Details</h4>
                            <div>Reservation ID: {id}</div>
                            <div>Client: {clientName}</div>
                            <div>Tables: <div className="waiter__reservation-item--reservation-tables-list">{tablesDetails.map((table, index) => <div key={index}>{table}</div>)}</div></div>
                            <div>Number of Guests: {numberOfGuests}</div>
                            <div>Additional info: {notes || "None"}</div>
                        </div>
                        <div className="waiter__reservation--buttons-section">
                            <button className="waiter__reservation-item--window-button" onClick={displayDetails}>Close</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ReservationItem;