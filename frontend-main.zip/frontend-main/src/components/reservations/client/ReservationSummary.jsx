import React, {useState, useEffect} from "react";
import {useNavigate} from 'react-router-dom';
import {getTableById, makeReservation} from "../../../service/api/customerApi.js";
import "./ReservationSummary.scss";

const ConfirmationWindow = ({isOpen, onClose, message}) => {
    if (!isOpen) return null;

    return (
        <div className="client__reservation-summary--modal-window">
            <div className="client__reservation-summary--modal-content">
                <p>{message}</p>
                <button className="client__reservation-summary--modal-close" onClick={onClose}>Go Home</button>
            </div>
        </div>
    );
};

const ReservationSummary = () => {
    const [reservation, setReservation] = useState({});
    const [tables, setTables] = useState([]);
    const [additionalComments, setAdditionalComments] = useState("");
    const [error, setError] = useState("");
    const [isConfirmationWindowOpen, setIsConfirmationWindowOpen] = useState(false);
    const [confirmationMessage, setConfirmationMessage] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem('jwt_client');
            const sessionStorageToken = sessionStorage.getItem('jwt_client');
            if (!(sessionStorageToken || localStorageToken)) {
                navigate('/login');
            }
        };
        checkIfLoggedIn();
    }, []);

    useEffect(() => {
        const token = getToken();
        const savedReservation = JSON.parse(localStorage.getItem(`${token}_reservation`));
        if (savedReservation) {
            setReservation(savedReservation);
        }

        const getTablesDetails = async () => {
            const chosenTables = JSON.parse(localStorage.getItem(`${token}_selected_tables`));
            if (chosenTables && chosenTables.length > 0) {
                const tablesResult = chosenTables.map(id =>
                    getTableById(id).then(response => {
                        return response.json();
                    }).catch(error => {
                        console.error("Error fetching table details:", error);
                    })
                );

                const tableDetails = await Promise.all(tablesResult);
                setTables(tableDetails.filter(table => table != null));
            }
        };

        getTablesDetails();
    }, []);

    const makeReservationFunction = async () => {
        const token = getToken();
        const diningDeskIds = tables.map(table => table.id);
        const formattedDate = reservation.date.replace(/-/g, "/");
        const reservationDetails = {
            diningDeskIds,
            reservationDate: formattedDate,
            startTime: reservation.startTime + ":00",
            endTime: reservation.endTime + ":00",
            numberOfPeople: parseInt(reservation.numberOfPeople),
            additionalComments
        };

        try {
            const response = await makeReservation(token, reservationDetails);
            if (response.ok) {
                setConfirmationMessage("Reservation successfully made! Please check your email to confirm the reservation.");
                localStorage.setItem(`${token}_reservation`, "");
                localStorage.setItem(`${token}_selected_tables`, "");
            } else {
                setConfirmationMessage("Reservation attempt unsuccessful. Please try again.");
            }
            setIsConfirmationWindowOpen(true);
        } catch (error) {
            console.error("Failed to make reservation:", error);
            setConfirmationMessage("Failed to make reservation");
            setIsConfirmationWindowOpen(true);
        }
    };

    const closeConfirmationWindow = () => {
        setIsConfirmationWindowOpen(false);
        navigate('/');
    };

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        return sessionStorageToken || localStorageToken;
    };

    return (
        <div className="client__reservation-summary--wrapper">
            <div className="client__reservation-summary">
                <h2>Reservation Summary</h2>
                <div className="client__reservation-summary--container">
                    <div className="client__reservation-summary--details">
                        <p><strong>Date:</strong> {reservation.date}</p>
                        <p><strong>Start Time:</strong> {reservation.startTime}</p>
                        <p><strong>End Time:</strong> {reservation.endTime}</p>
                        <p><strong>Number of Guests:</strong> {reservation.numberOfPeople}</p>
                        <div className="client__reservation-summary--table-list">
                            {tables.map((table, index) => (
                                <div key={index} className="client__reservation-summary--table-entry">
                                    <span><strong>Room Number:</strong> {table.roomId}</span>
                                    <span><strong>Table Number:</strong> {table.tableNumber}</span>
                                    <span><strong>Seats:</strong> {table.numberOfSeats}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                    {error && <p className="client__reservation--error-message">{error}</p>}
                    <div className="client__reservation-summary--comments-container">
                        <label htmlFor="comments">Additional Comments</label>
                        <textarea
                            id="comments"
                            name="comments"
                            value={additionalComments}
                            onChange={(e) => setAdditionalComments(e.target.value)}
                            placeholder="Add any additional details or needs..."
                        ></textarea>
                        <div className="client__reservation-summary--button-container">
                            <button className="client__reservation-summary--go-back-button"
                                    onClick={() => navigate('/tables')}>
                                Go Back
                            </button>
                            <button className="client__reservation-summary--submit-button"
                                    onClick={makeReservationFunction}>
                                Make a Reservation
                            </button>
                        </div>
                    </div>
                </div>
                <ConfirmationWindow
                    isOpen={isConfirmationWindowOpen}
                    onClose={closeConfirmationWindow}
                    message={confirmationMessage}
                />
            </div>
        </div>
    );
};

export default ReservationSummary;