import React, {useEffect, useState} from 'react';
import {useNavigate} from 'react-router-dom';
import './RoomSelection.scss';
import {getTableById, getTableRecommendation} from "../../../service/api/customerApi.js";

const RoomSelection = ({rooms, handleRoomSelect, disabled, setRecommendedTableIds, clearSelectedTables}) => {
    const navigate = useNavigate();
    const [isNextEnabled, setIsNextEnabled] = useState(false);
    const [selectedRoomId, setSelectedRoomId] = useState(null);
    const [tableSeatsError, setTableSeatsError] = useState(false);

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };

    const handleSelectChange = (value) => {
        const token = getToken();
        const index = parseInt(value, 10);
        if (index >= 0 && rooms[index]) {
            handleRoomSelect(index);
            setSelectedRoomId(rooms[index].id);
            setTimeout(() => {
                const selectedTables = localStorage.getItem(`${token}_selected_tables`);
                setIsNextEnabled(selectedTables && JSON.parse(selectedTables).length > 0);
            }, 0);
        }
    };

    const getTableRecommendationFunction = async () => {
        const token = getToken();
        const savedReservation = JSON.parse(localStorage.getItem(`${token}_reservation`));
        const formattedDate = savedReservation.date.replace(/-/g, "/");
        const startTime = savedReservation.startTime + ":00";
        const endTime = savedReservation.endTime + ":00";
        const numberOfGuests = parseInt(savedReservation.numberOfPeople);

        const reservationRequest = {
            numberOfGuests: numberOfGuests,
            roomId: selectedRoomId,
            date: formattedDate,
            startTime: startTime,
            endTime: endTime
        };

        try {
            const result = await getTableRecommendation(reservationRequest);
            const response = await result.json();

            if (response && Array.isArray(response)) {
                const recommendedIds = response.map(table => table.id);
                setRecommendedTableIds(recommendedIds);
            }
        } catch (error) {
            console.error("Failed to fetch recommendations:", error);
        }
    };

    const handleClear = () => {
        const token = getToken();
        setRecommendedTableIds([]);
        localStorage.removeItem(`${token}_selected_tables`);
        clearSelectedTables();
        setIsNextEnabled(false);
    };

    const handleNext = async () => {
        const token = getToken();
        const savedReservation = JSON.parse(localStorage.getItem(`${token}_reservation`));
        const numberOfGuests = parseInt(savedReservation.numberOfPeople);

        const selectedTables = localStorage.getItem(`${token}_selected_tables`);
        const tablesArray = JSON.parse(selectedTables);
        let seats = 0;
        for (const tableId of tablesArray){
            const resp = await getTableById(tableId);
            const result = await resp.json();
            seats += result.numberOfSeats;
        }
        if(seats >= numberOfGuests) {
            setTableSeatsError(false);
            navigate('/reservation/summary');
        }
        else{
            setTableSeatsError(true);
            console.log("ERRRRRROR SSS: ");
        }
    }

    useEffect(() => {
        const checkSelectedTables = () => {
            const token = getToken();
            const selectedTables = localStorage.getItem(`${token}_selected_tables`);
            const isEnabled = selectedTables && JSON.parse(selectedTables).length > 0;
            setIsNextEnabled(isEnabled);
        };

        checkSelectedTables();

        const intervalId = setInterval(checkSelectedTables, 1000);

        return () => clearInterval(intervalId);
    }, [rooms]);

    return (
        <div className="client__room-selection">
            <h2>Choose tables</h2>
            <div className="client__room-selection--input-group">
                <select onChange={(e) => handleSelectChange(e.target.value)} disabled={disabled}>
                    <option value="">Select Room</option>
                    {rooms.map((room, index) => (
                        <option key={room.id} value={index}>{`Room ${room.id}`}</option>
                    ))}
                </select>
                <button onClick={handleClear} className="client__room-selection--next-button">
                    Clear
                </button>
                <button onClick={getTableRecommendationFunction} className="client__room-selection--next-button">
                    Get Recommendation
                </button>
                <button onClick={() => navigate('/reservation')} className="client__room-selection--go-back-button">
                    Go Back
                </button>
                <button onClick={handleNext} disabled={!isNextEnabled}
                        className="client__room-selection--next-button">
                    Next
                </button>
            </div>
            {tableSeatsError &&
                <p>Insufficient seats. Please select enough tables to accommodate all the guests.</p>
            }
        </div>
    );
};

export default RoomSelection;
