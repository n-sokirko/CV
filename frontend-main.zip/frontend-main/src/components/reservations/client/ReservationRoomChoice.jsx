import React, {useState, useEffect, useRef} from 'react';
import {useNavigate} from 'react-router-dom';
import RoomLayout from "./RoomLayout";
import RoomSelection from "./RoomSelection";
import {fetchRooms} from "../../../service/api/managerApi";
import {getFreeTables} from "../../../service/api/customerApi.js";

export default function ReservationRoomChoice() {
    const navigate = useNavigate();
    const [rooms, setRooms] = useState([]);
    const [selectedRoom, setSelectedRoom] = useState(null);
    const [tables, setTables] = useState([]);
    const [recommendedTableIds, setRecommendedTableIds] = useState([]);
    const clearSelectedTablesRef = useRef(null);

    useEffect(() => {
        getRooms();
    }, []);

    const getRooms = async () => {
        try {
            const roomsData = await fetchRooms();
            setRooms(roomsData.content || []);
        } catch (error) {
            console.error("Failed to fetch rooms");
        }
    };

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };
    const loadTables = async (roomId) => {
        try {
            const token = getToken();
            const savedReservation = JSON.parse(localStorage.getItem(`${token}_reservation`));
            if (!savedReservation) {
                return;
            }

            const formattedDate = savedReservation.date.replace(/-/g, "/");
            const startTime = `${savedReservation.startTime}:00`;
            const endTime = `${savedReservation.endTime}:00`;

            const tablesResp = await getFreeTables(formattedDate, startTime, endTime, roomId);
            const tablesData = await tablesResp.json();

            if (Array.isArray(tablesData)) {
                setTables(tablesData);
            } else {
                setTables([]);
            }
        } catch (error) {
            console.error("Failed to load tables:", error);
        }
    };

    const handleRoomSelect = (index) => {
        const room = rooms[index];
        if (room) {
            setSelectedRoom(room);
            loadTables(room.id);
        }
    };

    const clearSelectedTables = (callback) => {
        clearSelectedTablesRef.current = callback;
    };

    const executeClearSelectedTables = () => {
        if (clearSelectedTablesRef.current) {
            clearSelectedTablesRef.current();
        }
    };

    return (
        <div className="room-wrapper">
            <div className="client__reservation-room-choice">
                <RoomSelection
                    rooms={rooms}
                    handleRoomSelect={handleRoomSelect}
                    disabled={false}
                    setRecommendedTableIds={setRecommendedTableIds}
                    clearSelectedTables={executeClearSelectedTables}
                />
                {selectedRoom && (
                    <RoomLayout
                        selectedRoom={selectedRoom}
                        tables={tables}
                        recommendedTableIds={recommendedTableIds}
                        clearSelectedTablesFunction={clearSelectedTables}
                    />
                )}
            </div>
        </div>
    );
}