import React, {useRef, useState, useEffect} from 'react';
import './RoomLayout.scss';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faUser} from '@fortawesome/free-solid-svg-icons';

function RoomLayout({selectedRoom, tables, recommendedTableIds, clearSelectedTablesFunction}) {
    const roomLayoutRef = useRef(null);
    const gridSize = window.innerWidth <= 1920 || window.innerHeight <= 1080 ? 64 : 80;
    const [selectedTableIds, setSelectedTableIds] = useState([]);

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        return sessionStorageToken || localStorageToken;
    };

    useEffect(() => {
        const token = getToken();
        try {
            const tableIds = JSON.parse(localStorage.getItem(`${token}_selected_tables`));
            if (Array.isArray(tableIds)) {
                setSelectedTableIds(tableIds);
            }
        } catch (error) {
            console.error("Failed to parse selected tables from localStorage:", error);
            setSelectedTableIds([]);
        }
    }, []);

    useEffect(() => {
        const token = getToken();
        localStorage.setItem(`${token}_selected_tables`, JSON.stringify(selectedTableIds));
    }, [selectedTableIds]);

    useEffect(() => {
        clearSelectedTablesFunction(() => {
            setSelectedTableIds([]);
        });
    }, [clearSelectedTablesFunction]);

    const handleTableClick = (tableId) => {
        setSelectedTableIds(prev => prev.includes(tableId) ? prev.filter(id => id !== tableId) : [...prev, tableId]);
    };

    return (
        <div className="client__room-layout">
            <div className="client__room-layout--scroll-container">
                <div
                    className="client__room-layout--room"
                    ref={roomLayoutRef}
                    style={{
                        width: selectedRoom.width * gridSize,
                        height: selectedRoom.length * gridSize,
                        position: "relative",
                        border: "1px solid #000",
                    }}
                >
                    {tables.map((table) => (
                        <div
                            key={table.id}
                            className={`client__room-layout--table ${selectedTableIds.includes(table.id) ? "selected" : ""} ${recommendedTableIds.includes(table.id) ? "recommended" : ""}`}
                            title={`Table Number: ${table.tableNumber}`}
                            onClick={() => handleTableClick(table.id)}
                            style={{
                                left: table.coordinateY * gridSize,
                                top: table.coordinateX * gridSize,
                            }}
                        >
                            <div className="client__room-layout--table-number">
                                Tab {table.tableNumber}
                            </div>
                            <div className="client__room-layout--table-seats">
                                <FontAwesomeIcon icon={faUser}/> {table.numberOfSeats}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default RoomLayout;