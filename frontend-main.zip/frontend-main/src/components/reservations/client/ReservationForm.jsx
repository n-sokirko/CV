import React, {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
import "./ReservationForm.scss";
import {getOpeningHours} from "../../../service/api/customerApi.js";

const ReservationForm = () => {
    const [date, setDate] = useState("");
    const [startTime, setStartTime] = useState("");
    const [endTime, setEndTime] = useState("");
    const [numberOfPeople, setNumberOfPeople] = useState(1);
    const [errors, setErrors] = useState({});
    const [openingHours, setOpeningHours] = useState([]);

    const navigate = useNavigate();

    useEffect(() => {
        const checkIfLoggedIn = () => {
            const localStorageToken = localStorage.getItem("jwt_client");
            const sessionStorageToken = sessionStorage.getItem("jwt_client");
            if (!(sessionStorageToken || localStorageToken)) {
                navigate("/login");
            }
        };
        checkIfLoggedIn();

        const fetchOpeningHours = async () => {
            try {
                const response = await getOpeningHours();
                const data = await response.json();
                setOpeningHours(data);
            } catch (error) {
                console.error("Error fetching opening hours:", error);
            }
        };
        fetchOpeningHours();
    }, []);

    useEffect(() => {
        const setReservationData = () => {
            const token = getToken();
            const reservationString = localStorage.getItem(`${token}_reservation`);
            if (reservationString) {
                const reservation = JSON.parse(reservationString);
                setDate(reservation.date || '');
                setStartTime(reservation.startTime || '');
                setEndTime(reservation.endTime || '');
                setNumberOfPeople(reservation.numberOfPeople || 1);
            } else {
                setDate('');
                setStartTime('');
                setEndTime('');
                setNumberOfPeople(1);
            }
        }
        setReservationData();
    }, []);

    const getWeekday = (dateString) => {
        const date = new Date(dateString);
        return date.getDay() === 0 ? 7 : date.getDay();
    };

    const getToken = () => {
        const localStorageToken = localStorage.getItem('jwt_client');
        const sessionStorageToken = sessionStorage.getItem('jwt_client');
        if (sessionStorageToken) {
            return sessionStorageToken;
        } else {
            return localStorageToken;
        }
    };

    const validateForm = async () => {
        const newErrors = {};
        const currentDate = new Date().toISOString().split("T")[0];
        const weekday = getWeekday(date);

        if (!date) {
            newErrors.date = "Date cannot be empty";
        } else if (date < currentDate) {
            newErrors.date = "Date cannot be in the past";
        }

        const openingHoursForChosenDay = openingHours.find(
            (entry) => entry.weekday === weekday
        );

        if (!openingHoursForChosenDay) {
            newErrors.date = "Selected day is not within opening hours";
        } else {
            const {openingTime, closingTime} = openingHoursForChosenDay;

            if (!startTime) {
                newErrors.startTime = "Start time cannot be empty";
            } else if (startTime < openingTime || startTime > closingTime) {
                newErrors.startTime = `Start time must be within opening hours (${openingTime.slice(0, 5)} - ${closingTime.slice(0, 5)})`;
            }

            if (!endTime) {
                newErrors.endTime = "End time cannot be empty";
            } else if (endTime <= startTime) {
                newErrors.endTime = "End time must be after start time";
            } else if (endTime < openingTime || endTime > closingTime) {
                newErrors.endTime = `End time must be within opening hours (${openingTime.slice(0, 5)} - ${closingTime.slice(0, 5)})`;
            }
        }

        return newErrors;
    };

    const submitReservationFunction = async (e) => {
        e.preventDefault();
        const token = getToken();
        const reservationErrors = await validateForm();
        if (Object.keys(reservationErrors).length === 0) {
            const reservation = {
                date,
                startTime,
                endTime,
                numberOfPeople,
            };
            localStorage.setItem(`${token}_reservation`, JSON.stringify(reservation));
            navigate("/tables");
        } else {
            setErrors(reservationErrors);
        }
    };

    return (
        <div className="client__reservation-form--form-wrapper">
            <div className="client__reservation-form--form-container">
                <div className="client__reservation-form">
                    <h2>Make a Reservation</h2>
                    <form onSubmit={submitReservationFunction}>
                        <div className="client__reservation-form--form-field">
                            <label htmlFor="date">Date</label>
                            <input
                                type="date"
                                id="date"
                                name="date"
                                value={date}
                                onChange={(e) => setDate(e.target.value)}
                            />
                            {errors.date && (
                                <p className="client__reservation-form--error-message">
                                    {errors.date}
                                </p>
                            )}
                        </div>
                        <div className="client__reservation-form--form-field">
                            <label htmlFor="start-time">Start Time</label>
                            <input
                                type="time"
                                id="start-time"
                                name="start-time"
                                value={startTime}
                                onChange={(e) => setStartTime(e.target.value)}
                            />
                            {errors.startTime && (
                                <p className="client__reservation-form--error-message">
                                    {errors.startTime}
                                </p>
                            )}
                        </div>
                        <div className="client__reservation-form--form-field">
                            <label htmlFor="end-time">End Time</label>
                            <input
                                type="time"
                                id="end-time"
                                name="end-time"
                                value={endTime}
                                onChange={(e) => setEndTime(e.target.value)}
                            />
                            {errors.endTime && (
                                <p className="client__reservation-form--error-message">
                                    {errors.endTime}
                                </p>
                            )}
                        </div>
                        <div className="client__reservation-form--form-field">
                            <label htmlFor="guests">Number of Guests</label>
                            <input
                                type="number"
                                id="guests"
                                name="guests"
                                value={numberOfPeople}
                                onChange={(e) => setNumberOfPeople(e.target.value)}
                                min="1"
                            />
                        </div>
                        <button
                            type="submit"
                            className="client__reservation-form--submit-button"
                        >
                            Check available tables
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default ReservationForm;