import React, { useState, useEffect } from 'react';
import {
  getAllIngredients,
  updateIngredientAvailability,
  deleteIngredient,
  addAllergenToIngredient,
  removeAllergenFromIngredient,
  fetchAllergens,
  updateIngredient,
  getAllModifiableIngredients,
} from '../../../service/api/managerApi';
import './ViewIngredient.scss';
import { FaCheckCircle, FaTimesCircle, FaEdit } from 'react-icons/fa';
import Select from 'react-select'; 

const ViewIngredient = () => {
  const [ingredients, setIngredients] = useState([]);
  const [selectedIngredient, setSelectedIngredient] = useState(null);
  const [newIngredientName, setNewIngredientName] = useState('');
  const [allAllergens, setAllAllergens] = useState([]);
  const [selectedAllergens, setSelectedAllergens] = useState([]); 
  const [editName, setEditName] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    const fetchIngredients = async () => {
      try {
        const data = await getAllIngredients();
        setIngredients(data.content || data);
      } catch (error) {
        setErrorMessage('Error fetching ingredients.');
      }
    };

    const fetchAllergenData = async () => {
      try {
        const allergenData = await fetchAllergens();
        setAllAllergens(allergenData.content || allergenData);
      } catch (error) {
        setErrorMessage('Error fetching allergens.');
      }
    };

    fetchIngredients();
    fetchAllergenData();
  }, []);

  const handleSelectIngredient = (ingredient) => {
    setSelectedIngredient(ingredient);
    setNewIngredientName(ingredient.name);

    const ingredientAllergens = ingredient.allergens.map((allergenId) => {
      const allergen = allAllergens.find((a) => a.id === allergenId);
      return allergen ? { value: allergen.id, label: allergen.name } : null;
    }).filter(Boolean);

    setSelectedAllergens(ingredientAllergens);
    setErrorMessage('');
    setSuccessMessage('');
  };

  const handleUpdateAvailability = async () => {
    if (selectedIngredient) {
      try {
        const availabilityStatus = !selectedIngredient.available;
        await updateIngredientAvailability(selectedIngredient.id, availabilityStatus);
        setIngredients(
          ingredients.map((ingredient) =>
            ingredient.id === selectedIngredient.id
              ? { ...ingredient, available: availabilityStatus }
              : ingredient
          )
        );
        setSelectedIngredient((prev) => ({
          ...prev,
          available: availabilityStatus,
        }));
        setErrorMessage('');
        setSuccessMessage('Ingredient availability updated.');
      } catch (error) {
        setErrorMessage('Error updating ingredient availability.');
      }
    }
  };

  const handleEditIngredientName = async () => {
    if (selectedIngredient && newIngredientName.trim()) {
      try {
        await updateIngredient(selectedIngredient.id, { name: newIngredientName.trim() });
        setIngredients(
          ingredients.map((ingredient) =>
            ingredient.id === selectedIngredient.id
              ? { ...ingredient, name: newIngredientName.trim() }
              : ingredient
          )
        );
        setSelectedIngredient((prev) => ({
          ...prev,
          name: newIngredientName.trim(),
        }));
        setEditName(false);
        setErrorMessage('');
        setSuccessMessage('Ingredient name updated.');
      } catch (error) {
        setErrorMessage('Error updating ingredient name.');
      }
    } else {
      setErrorMessage('Ingredient name cannot be empty.');
    }
  };

  const handleDeleteIngredient = async () => {
    if (selectedIngredient) {
      try {
        const modifiableIngredients = await getAllModifiableIngredients();

        if (!Array.isArray(modifiableIngredients)) {
          setErrorMessage('Failed to fetch modifiable ingredients data: Unexpected data format.');
          setSuccessMessage('');
          return;
        }

        const isUsedInModifiableIngredients = modifiableIngredients.some((modifiableIngredient) => {
          return modifiableIngredient.ingredient?.id === selectedIngredient.id;
        });

        if (isUsedInModifiableIngredients) {
          setErrorMessage('Cannot delete ingredient because it is associated with existing modifiable ingredients.');
          setSuccessMessage('');
          return;
        }
        await deleteIngredient(selectedIngredient.id);
        setIngredients(
          ingredients.filter((ingredient) => ingredient.id !== selectedIngredient.id)
        );
        setSelectedIngredient(null);
        setErrorMessage('');
        setSuccessMessage('Ingredient deleted successfully.');
      } catch (error) {
        setErrorMessage(`Failed to delete ingredient: ${error.message || error.toString()}`);
        setSuccessMessage('');
      }
    }
  };

  
  const handleAllergenChange = async (selectedOptions) => {
    if (!selectedIngredient) return;

    const previousAllergenIds = selectedAllergens.map((option) => option.value);
    const newAllergenIds = selectedOptions.map((option) => option.value);

    const addedAllergenIds = newAllergenIds.filter((id) => !previousAllergenIds.includes(id));
    const removedAllergenIds = previousAllergenIds.filter((id) => !newAllergenIds.includes(id));

    try {
    
      for (const allergenId of addedAllergenIds) {
        await addAllergenToIngredient(selectedIngredient.id, allergenId);
      }

      for (const allergenId of removedAllergenIds) {
        await removeAllergenFromIngredient(selectedIngredient.id, allergenId);
      }

      setSelectedAllergens(selectedOptions);
      setIngredients(
        ingredients.map((ingredient) =>
          ingredient.id === selectedIngredient.id
            ? { ...ingredient, allergens: newAllergenIds }
            : ingredient
        )
      );
      setSelectedIngredient((prev) => ({
        ...prev,
        allergens: newAllergenIds,
      }));
      setErrorMessage('');
      setSuccessMessage('Allergens updated successfully.');
    } catch (error) {
      setErrorMessage('Error updating allergens.');
    }
  };

  return (
    <div className="view-ingredient-container">
      <h2>Ingredients List</h2>
      <div className="ingredient-list">
        {ingredients.map((ingredient) => (
          <div
            key={ingredient.id}
            className={`ingredient-item ${selectedIngredient?.id === ingredient.id ? 'selected' : ''}`}
            onClick={() => handleSelectIngredient(ingredient)}
          >
            {ingredient.name}
          </div>
        ))}
      </div>

      {selectedIngredient ? (
        <div className="ingredient-details">
          <h3>
            {editName ? (
              <input
                type="text"
                value={newIngredientName}
                onChange={(e) => {
                  setNewIngredientName(e.target.value);
                  setErrorMessage('');
                  setSuccessMessage('');
                }}
                onBlur={handleEditIngredientName}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleEditIngredientName();
                  }
                }}
                autoFocus
              />
            ) : (
              <>
                {selectedIngredient.name}
                <FaEdit className="edit-icon" onClick={() => setEditName(true)} />
              </>
            )}
          </h3>
          <button className="availability-button" onClick={handleUpdateAvailability}>
            {selectedIngredient.available ? 'Mark as Unavailable' : 'Mark as Available'}
            {selectedIngredient.available ? (
              <FaCheckCircle className="availability-icon" color="green" />
            ) : (
              <FaTimesCircle className="availability-icon" color="red" />
            )}
          </button>

          <div className="form-group">
            <label className="label">Allergens:</label>
            <Select
              isMulti
              options={allAllergens.map((allergen) => ({
                value: allergen.id,
                label: allergen.name,
              }))}
              value={selectedAllergens}
              onChange={handleAllergenChange}
              className="multi-select"
              classNamePrefix="select"
              placeholder="Select allergens..."
            />
          </div>

          <button onClick={handleDeleteIngredient} className="delete-btn">
            Delete Ingredient
          </button>
        </div>
      ) : (
        <p>Select an ingredient to view details</p>
      )}
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      {successMessage && <p className="success-message">{successMessage}</p>}
    </div>
  );
};

export default ViewIngredient;
