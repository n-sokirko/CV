import { useState, useEffect } from 'react';
import './AddIngredient.scss';
import { addIngredient, getAllergens } from '../../../service/api/managerApi';
import Select from 'react-select';

function AddIngredient() {
  const [name, setName] = useState('');
  const [available, setAvailable] = useState(true);
  const [allergens, setAllergens] = useState([]);
  const [selectedAllergens, setSelectedAllergens] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchAllergens = async () => {
      try {
        const result = await getAllergens();
        setAllergens(result);
      } catch (error) {
     
        setErrorMessage('Failed to fetch allergens.');
      }
    };

    fetchAllergens();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');
  
  
    if (!name.trim()) {
      setErrorMessage('Ingredient name is required.');
      return;
    }
  
    const newIngredient = {
      name: name.trim(),
      available,
      allergens: selectedAllergens.map((allergen) => allergen.value), 
    };
  
    try {
      setIsSubmitting(true);
      await addIngredient(newIngredient);
      setSuccessMessage('Ingredient added successfully.');
   
      setName('');
      setAvailable(true);
      setSelectedAllergens([]);
    } catch (error) {
      setErrorMessage('Failed to add ingredient.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form className="add-ingredient-container" onSubmit={handleSubmit}>
      <h2>Add New Ingredient</h2>
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      {successMessage && <p className="success-message">{successMessage}</p>}
      
      <div className="form-group">
        <label className="label" htmlFor="ingredient-name">Name:</label>
        <input
          className="input"
          type="text"
          id="ingredient-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </div>

      <div className="form-group checkbox-group">
        <label className="label" htmlFor="ingredient-available">
          Available:
          <input
            className="input-checkbox"
            type="checkbox"
            id="ingredient-available"
            checked={available}
            onChange={(e) => setAvailable(e.target.checked)}
          />
        </label>
      </div>

      <div className="form-group">
        <label className="label">Allergens:</label>
        <Select
          isMulti
          options={allergens.map((allergen) => ({
            value: allergen.id,
            label: allergen.name,
          }))}
          value={selectedAllergens}
          onChange={(selectedOptions) => {
            setSelectedAllergens(selectedOptions || []);
          }}
          className="multi-select"
          classNamePrefix="select"
          placeholder="Select allergens..."
          isDisabled={isSubmitting}
        />
      </div>

      <button className="submit-button" type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Adding...' : 'Add Ingredient'}
      </button>
    </form>
  );
}

export default AddIngredient;
