import React, { useState } from 'react';
import Select from 'react-select';
import './IngredientsManagement.scss';

function IngredientsManagement({
  mealIngredients = [],
  availableIngredients = [],
  handleAddIngredient,
  handleRemoveIngredient,
  loading,
}) {
  const [selectedIngredient, setSelectedIngredient] = useState(null);

  
  const filteredAvailableIngredients = availableIngredients.filter(
    (ing) => !mealIngredients.some((mealIng) => mealIng.id === ing.id)
  );

  const ingredientOptions = filteredAvailableIngredients.map((ing) => ({
    value: ing.id,
    label: ing.name,
  }));

  const handleAdd = () => {
    if (selectedIngredient) {
      handleAddIngredient(selectedIngredient.value);
      setSelectedIngredient(null);
    }
  };

  return (
    <div className="ingredients-management">
      <h3>Ingredients</h3>
      <ul className="ingredients-list">
        {mealIngredients.length > 0 ? (
          mealIngredients.map((ingredient) => (
            <li key={ingredient.id} className="ingredient-item">
              <span className="ingredient-name">{ingredient.name}</span>
              <button
                className="remove-btn"
                onClick={() => handleRemoveIngredient(ingredient.id)}
                disabled={loading}
              >
                Remove
              </button>
            </li>
          ))
        ) : (
          <li className="no-ingredients">No ingredients added yet.</li>
        )}
      </ul>

      <div className="add-ingredient">
        <Select
          options={ingredientOptions}
          value={selectedIngredient}
          onChange={setSelectedIngredient}
          placeholder="Select an ingredient"
          isDisabled={loading}
          className="ingredient-select"
          classNamePrefix="select"
        />
        <button
          onClick={handleAdd}
          disabled={loading || !selectedIngredient}
          className="add-btn"
        >
          Add
        </button>
      </div>
    </div>
  );
}

export default IngredientsManagement;
