import React, { useState, useEffect } from 'react';
import './AddSubcategory.scss';
import { addSubcategory, getAllCategories } from '../../../service/api/managerApi';
import { FaPlus } from 'react-icons/fa';

function AddSubcategory() {
    const [subcategoryName, setSubcategoryName] = useState('');
    const [categoryId, setCategoryId] = useState('');
    const [categories, setCategories] = useState([]);
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const data = await getAllCategories();
                if (data && data.content && Array.isArray(data.content)) {
                    setCategories(data.content);
                } else {
                    setErrorMessage('Fetched categories data is not in expected format.');
                }
            } catch (error) {
                setErrorMessage(error.message || 'Error fetching categories.');
            }
        };

        fetchCategories();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (subcategoryName.trim() && categoryId) {
            try {
                await addSubcategory({ name: subcategoryName.trim(), categoryId: parseInt(categoryId) });
                setSubcategoryName('');
                setCategoryId('');
                setErrorMessage('');
                setSuccessMessage('Subcategory added successfully.');
            } catch (error) {
                setErrorMessage(error.message || 'Failed to add subcategory.');
                setSuccessMessage('');
            }
        } else {
            setErrorMessage('Subcategory name or category is empty or invalid.');
            setSuccessMessage('');
        }
    };

    return (
        <div className="add-subcategory-page">
            <div className="add-subcategory-container">
                <h2>Add Subcategory</h2>
                <form onSubmit={handleSubmit}>
                    <label>
                        Subcategory Name:
                        <input
                            type="text"
                            value={subcategoryName}
                            onChange={(e) => setSubcategoryName(e.target.value)}
                            placeholder="Enter subcategory name"
                        />
                    </label>
                    <label>
                        Category:
                        <select
                            value={categoryId}
                            onChange={(e) => setCategoryId(e.target.value)}
                        >
                            <option value="">Select Category</option>
                            {categories.map(category => (
                                <option key={category.id} value={category.id}>
                                    {category.name}
                                </option>
                            ))}
                        </select>
                    </label>
                    <button type="submit" className="add-btn">
                        <FaPlus /> Add Subcategory
                    </button>
                </form>
                {errorMessage && <p className="error-message">{errorMessage}</p>}
                {successMessage && <p className="success-message">{successMessage}</p>}
            </div>
        </div>
    );
}

export default AddSubcategory;
