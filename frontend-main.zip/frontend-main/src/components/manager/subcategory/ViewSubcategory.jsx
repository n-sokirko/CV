import React, { useState, useEffect } from 'react';
import { getAllSubcategories, updateSubcategory, deleteSubcategory, getAllCategories,getAllMeals, } from '../../../service/api/managerApi';
import './ViewSubcategory.scss';
import { FaEdit, FaTrash } from 'react-icons/fa';

const ViewSubcategory = () => {
    const [subcategories, setSubcategories] = useState([]);
    const [categories, setCategories] = useState([]);
    const [selectedSubcategory, setSelectedSubcategory] = useState(null);
    const [editName, setEditName] = useState(false);
    const [newSubcategoryName, setNewSubcategoryName] = useState('');
    const [newCategoryId, setNewCategoryId] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    useEffect(() => {
        const fetchSubcategories = async () => {
            try {
                const data = await getAllSubcategories();
                if (Array.isArray(data)) {
                    setSubcategories(data);
                } else {
                    setErrorMessage('Fetched subcategories data is not an array.');
                }
            } catch (error) {
                setErrorMessage('Error fetching subcategories.');
            }
        };

        const fetchCategories = async () => {
            try {
                const data = await getAllCategories();
                if (data && data.content && Array.isArray(data.content)) {
                    setCategories(data.content);
                } else {
                    setErrorMessage('Fetched categories data is not in expected format.');
                }
            } catch (error) {
                setErrorMessage('Error fetching categories.');
            }
        };

        fetchSubcategories();
        fetchCategories();
    }, []);

    const handleSelectSubcategory = (subcategory) => {
        setSelectedSubcategory(subcategory);
        setNewSubcategoryName(subcategory.name);
        setNewCategoryId(subcategory.categoryId);
        setErrorMessage('');
    };

    const handleEditSubcategory = async () => {
        if (selectedSubcategory && newSubcategoryName && newCategoryId) {
            try {
                await updateSubcategory(selectedSubcategory.id, { name: newSubcategoryName, categoryId: newCategoryId });
                setSubcategories(subcategories.map(subcategory =>
                    subcategory.id === selectedSubcategory.id ? { ...subcategory, name: newSubcategoryName, categoryId: newCategoryId } : subcategory
                ));
                setSelectedSubcategory(prev => ({
                    ...prev,
                    name: newSubcategoryName,
                    categoryId: newCategoryId
                }));
                setEditName(false);
            } catch (error) {
                setErrorMessage('Failed to update subcategory.');
            }
        }
    };

    const handleDeleteSubcategory = async () => {
        if (selectedSubcategory) {
            try {
                const mealsData = await getAllMeals();
                let meals = [];
                if (Array.isArray(mealsData)) {
                  meals = mealsData;
                } else if (Array.isArray(mealsData.content)) {
                  meals = mealsData.content;
                } else {
                  setErrorMessage('Failed to fetch meals data: Unexpected data format.');
                  return;
                }
        
                const isSubcategoryUsed = meals.some((meal) => {
                  const subcategoryId = meal?.subcategory?.id;
                  return (
                    subcategoryId !== undefined &&
                    subcategoryId !== null &&
                    Number(subcategoryId) === Number(selectedSubcategory.id)
                  );
                });
        
                if (isSubcategoryUsed) {
                  setErrorMessage('Cannot delete subcategory because it is associated with existing meals.');
                
                  return; 
                }
              } catch (error) {
                setErrorMessage(`Failed to check subcategory usage: ${error.message}`);
         
                return; 
              }
        
        try {
            await deleteSubcategory(selectedSubcategory.id);
            setSubcategories(subcategories.filter(subcategory => subcategory.id !== selectedSubcategory.id));
            setSelectedSubcategory(null);
            setSuccessMessage('Subcategory deleted successfully.');
            setErrorMessage('');
        } catch (error) {
            setErrorMessage('Cannot delete subcategory because it is associated with existing dishes.');
     
        }
    }
    };

    const getCategoryNameById = (id) => {
        const category = categories.find(category => category.id === id);
        return category ? category.name : 'Unknown Category';
    };

    return (
        <div className="view-subcategory-container">
            <h2>Subcategories List</h2>
            <div className="subcategory-list">
                {subcategories.map(subcategory => (
                    <div
                        key={subcategory.id}
                        className={`subcategory-item ${selectedSubcategory?.id === subcategory.id ? 'active' : ''}`}
                        onClick={() => handleSelectSubcategory(subcategory)}
                    >
                        {subcategory.name}
                    </div>
                ))}
            </div>

            {selectedSubcategory ? (
                <div className="subcategory-details">
                    <h3>
                        {editName ? (
                            <>
                                <input
                                    type="text"
                                    value={newSubcategoryName}
                                    onChange={(e) => setNewSubcategoryName(e.target.value)}
                                    onBlur={handleEditSubcategory}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            handleEditSubcategory();
                                        }
                                    }}
                                />
                                <select
                                    value={newCategoryId}
                                    onChange={(e) => setNewCategoryId(e.target.value)}
                                    onBlur={handleEditSubcategory}
                                >
                                    <option value="">Select Category</option>
                                    {categories.map(category => (
                                        <option key={category.id} value={category.id}>
                                            {category.name}
                                        </option>
                                    ))}
                                </select>
                            </>
                        ) : (
                            <>
                                {selectedSubcategory.name} (Category: {getCategoryNameById(selectedSubcategory.categoryId)})
                                <FaEdit className="edit-icon" onClick={() => setEditName(true)} />
                            </>
                        )}
                    </h3>
                    <div className="subcategory-actions">
                        <button onClick={handleDeleteSubcategory} className="delete-btn">
                            Delete Subcategory <FaTrash />
                        </button>
                    </div>
                    {errorMessage && <p className="error-message">{errorMessage}</p>}
                </div>
            ) : (
                <p>Select a subcategory to view details</p>
            )}
        </div>
    );
};

export default ViewSubcategory;
