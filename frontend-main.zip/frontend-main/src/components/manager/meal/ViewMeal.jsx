import React, { useEffect, useState } from 'react';
import './ViewMeal.scss';
import { getAllMealsManager } from '../../../service/api/managerApi';

function ViewMeal({ onMealSelect }) {
  const [meals, setMeals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchMealsData = async () => {
      try {
        const response = await getAllMealsManager();
        setMeals(response?.content || []);
      } catch (error) {
        setError("Error fetching meals: " + error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchMealsData();
  }, []);

  const handleMealClick = (meal) => {
    if (onMealSelect) {
      onMealSelect(meal.id); 
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div className="view-meals-container">
      <h2>Available Meals</h2>
      <div className="meal-card-container">
        {meals.map(meal => (
          <div
            key={meal.id}
            className={`meal-card ${!meal.isAvailable ? 'meal-unavailable' : ''}`}
            onClick={() => handleMealClick(meal)}
          >
            {meal.imageLink && (
              <img src={meal.imageLink} alt={meal.name} className="meal-image" />
            )}
            <h3>{meal.name}</h3>
            <p>Price: ${meal.price}</p>
            <p>Calories: {meal.calories} kcal</p>
            <p>Subcategory: {meal.subcategory?.name || 'N/A'}</p>
            {!meal.isAvailable && <p className="not-available-label">Not Available</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

export default ViewMeal;
