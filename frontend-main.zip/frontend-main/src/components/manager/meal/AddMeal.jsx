import { useState, useEffect } from 'react';
import './AddMeal.scss';
import {
  getAllSubcategories,
  getAllIngredients,
  addMealWithImage,
  addModifiableIngredient,
} from '../../../service/api/managerApi';
import AddModifiableIngredient from '../modifiable-ingredient/AddModifiableIngredient';
import Select from 'react-select';

function AddMeal() {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [calories, setCalories] = useState('');
  const [available, setAvailable] = useState(false);
  const [mealSubcategoryId, setMealSubcategoryId] = useState('');
  const [ingredients, setIngredients] = useState([]);
  const [allIngredients, setAllIngredients] = useState([]);
  const [image, setImage] = useState(null);
  const [subcategories, setSubcategories] = useState([]);
  const [modifiableIngredients, setModifiableIngredients] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [subcategoriesData, ingredientsData] = await Promise.all([
          getAllSubcategories(),
          getAllIngredients(),
        ]);
        setSubcategories(subcategoriesData);
        setAllIngredients(ingredientsData);
      } catch (error) {
        setError('Error fetching data: ' + error.message);
      }
    };
    fetchData();
  }, []);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
    }
  };

  const addModifiableIngredientToList = (ingredient) => {
    setModifiableIngredients([...modifiableIngredients, ingredient]);
  };

  const removeModifiableIngredient = (index) => {
    setModifiableIngredients(modifiableIngredients.filter((_, i) => i !== index));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    if (!name || !price || !calories || !mealSubcategoryId) {
      setError('Please fill in all required fields.');
      setLoading(false);
      return;
    }

    const mealData = {
      name: name,
      price: parseFloat(price),
      calories: parseInt(calories, 10),
      isAvailable: available,
      subcategoryId: parseInt(mealSubcategoryId, 10),
      ingredientsIds: ingredients.map((ingredient) => ingredient.value),
    };

    try {
      const newMeal = await addMealWithImage(mealData, image);

  
      setSuccess(`Meal "${newMeal.name}" added successfully!`);

      const mealId = newMeal.id;

      for (const modIngredient of modifiableIngredients) {
        const modifiableIngredientData = {
          ...modIngredient,
          mealId: mealId,
        };

        await addModifiableIngredient(modifiableIngredientData);
      }

      resetForm();
    } catch (error) {
      setError('Error adding meal or modifiable ingredients: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setName('');
    setPrice('');
    setCalories('');
    setAvailable(false);
    setMealSubcategoryId('');
    setIngredients([]);
    setModifiableIngredients([]);
    setImage(null);
    setError('');
    setSuccess('');
  };

  return (
    <div className="add-meal-wrapper">
      <form className="add-meal-container" onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="label">Name:</label>
          <input
            className="input"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label className="label">Image:</label>
          <input
            className="input"
            type="file"
            accept="image/*"
            onChange={handleImageChange}
          />
        </div>
        <div className="form-group">
          <label className="label">Price:</label>
          <input
            className="input"
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
            step="0.01"
          />
        </div>
        <div className="form-group">
          <label className="label">Calories:</label>
          <input
            className="input"
            type="number"
            value={calories}
            onChange={(e) => setCalories(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label className="label">Available:</label>
          <input
            type="checkbox"
            checked={available}
            onChange={(e) => setAvailable(e.target.checked)}
          />
        </div>
        <div className="form-group">
          <label className="label">Meal Subcategory:</label>
          <select
            className="select"
            value={mealSubcategoryId}
            onChange={(e) => setMealSubcategoryId(e.target.value)}
            required
          >
            <option value="">Select a subcategory</option>
            {subcategories.map((subcategory) => (
              <option key={subcategory.id} value={subcategory.id}>
                {subcategory.name}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label className="label">Ingredients:</label>
          <Select
            isMulti
            options={allIngredients.map((ingredient) => ({
              value: ingredient.id,
              label: ingredient.name,
            }))}
            value={ingredients}
            onChange={(selectedOptions) => {
              setIngredients(selectedOptions || []);
            }}
            placeholder="Select ingredients..."
            className="multi-select"
            classNamePrefix="select"
          />
        </div>

        <button className="submit-button" type="submit" disabled={loading}>
          {loading ? 'Loading...' : 'Add Meal'}
        </button>
        {error && <div className="error-message">{error}</div>}
        {success && <div className="success-message">{success}</div>}
      </form>

      <div className="add-modifiable-ingredient-container">
        <AddModifiableIngredient onAdd={addModifiableIngredientToList} />

        <div className="modifiable-ingredients-list">
          <h3>Modifiable Ingredients:</h3>
          {modifiableIngredients.length > 0 ? (
            <ul>
              {modifiableIngredients.map((ingredient, index) => (
                <li key={index}>
                  Ingredient ID: {ingredient.ingredientId}, Base Count: {ingredient.baseCount}, Price: {ingredient.price}
                  <button
                    type="button"
                    onClick={() => removeModifiableIngredient(index)}
                  >
                    Remove
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p>No modifiable ingredients added.</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default AddMeal;
