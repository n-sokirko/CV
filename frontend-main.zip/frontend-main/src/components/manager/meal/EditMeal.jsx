import React, { useEffect, useState } from 'react';
import './EditMeal.scss';
import {
  getMealManager,
  getAllIngredients,
  getAllSubcategories,
  getAllMeals,
  updateMealMultipart,
  addIngredientToMeal,
  removeIngredientFromMeal,
  addModifiableIngredient,
  removeModifiableIngredient,
  getMealModifiableIngredients,
} from '../../../service/api/managerApi';
import IngredientsManagement from '../ingredient/IngredientsManagement';
import ModifiableIngredientsManagement from '../modifiable-ingredient/ModifiableIngredientsManagement';
import ConfirmationModal from '../confirmationModal/ConfirmationModal';

function EditMeal({ mealId, onClose }) {
  const [meal, setMeal] = useState(null);
  const [initialMeal, setInitialMeal] = useState(null);
  const [allIngredients, setAllIngredients] = useState([]);
  const [allSubcategories, setAllSubcategories] = useState([]);
  const [allMeals, setAllMeals] = useState([]);
  const [modifiableIngredients, setModifiableIngredients] = useState([]);

  const [ingredientsIds, setIngredientsIds] = useState([]);
  const [availableIngredients, setAvailableIngredients] = useState([]);

  const [newImage, setNewImage] = useState(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [ingredientToDelete, setIngredientToDelete] = useState(null);

  const [isChangingImage, setIsChangingImage] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [
          mealData,
          ingredients,
          subcategories,
          modifiableIngredientsData,
          meals,
        ] = await Promise.all([
          getMealManager(mealId),
          getAllIngredients(),
          getAllSubcategories(),
          getMealModifiableIngredients(mealId),
          getAllMeals(),
        ]);

        const safeModifiableIngredients = Array.isArray(modifiableIngredientsData)
          ? modifiableIngredientsData
          : [];

        setModifiableIngredients(safeModifiableIngredients);
        setAllIngredients(Array.isArray(ingredients) ? ingredients : []);
        setAllSubcategories(Array.isArray(subcategories) ? subcategories : []);
        setAllMeals(Array.isArray(meals) ? meals : []);

        const mergedIngredients = (mealData.ingredients || []).map((pi) => {
          const ingredient = ingredients.find((ing) => ing.id === pi.id);
          if (ingredient) {
            return { ...ingredient, isVisibleForClientInMenu: pi.isVisibleForClientInMenu };
          }
          return pi;
        });

        const fetchedMeal = {
          id: mealData.id,
          name: mealData.name,
          price: mealData.price,
          calories: mealData.calories,
          ingredients: mergedIngredients || [],
          subcategoryId: mealData.subcategory?.id || null,
          imageLink: mealData.imageLink || '',
        };

        setMeal(fetchedMeal);
        setInitialMeal(fetchedMeal);

        const mealIngredientsIds = mergedIngredients.map((ingredient) => ingredient.id);
        setIngredientsIds(mealIngredientsIds);
      } catch (err) {
        setError(`Error fetching data: ${err.message}`);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [mealId]);

  useEffect(() => {
    if (meal && Array.isArray(allIngredients) && allIngredients.length > 0) {
      const available = allIngredients.filter((ingredient) => !ingredientsIds.includes(ingredient.id));
      setAvailableIngredients(available);
    }
  }, [meal, allIngredients, ingredientsIds]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setMeal((prevMeal) => ({
      ...prevMeal,
      [name]: value,
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setNewImage(file);
  };

  const toggleChangeImage = () => {
    setIsChangingImage((prev) => !prev);
    if (isChangingImage) {
      setNewImage(null);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const isNameDuplicate = allMeals.some((m) => m.name === meal.name && m.id !== meal.id);
      if (isNameDuplicate) {
        setError('Meal name already exists. Please choose a different name.');
        setLoading(false);
        return;
      }

      const changedFields = {};

      if (initialMeal.name !== meal.name) {
        changedFields.name = meal.name;
      }
      if (initialMeal.price !== meal.price) {
        changedFields.price = meal.price;
      }
      if (initialMeal.calories !== meal.calories) {
        changedFields.calories = meal.calories;
      }
      if (initialMeal.subcategoryId !== meal.subcategoryId) {
        changedFields.subcategoryId = meal.subcategoryId;
      }

      const allIngredientIds = [
        ...ingredientsIds,
        ...modifiableIngredients.map((ing) => ing.id),
      ];

      const mealData = {
        ...changedFields,
        ingredientsIds: allIngredientIds,
      };

      await updateMealMultipart(meal.id, mealData, newImage);

      setSuccess('Meal updated successfully.');
      setTimeout(onClose, 2000);
    } catch (err) {
      setError(`Error updating meal: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleAddIngredient = async (ingredientId) => {
    if (ingredientsIds.includes(ingredientId)) {
      return;
    }
  
    setLoading(true);
    setError('');
    setSuccess('');
  
    try {
      await addIngredientToMeal(meal.id, ingredientId);
  
      const addedIngredient = allIngredients.find((ing) => ing.id === ingredientId);
  
      setIngredientsIds((prevIds) => [...prevIds, ingredientId]);
      setMeal((prevMeal) => ({
        ...prevMeal,
        ingredients: [...prevMeal.ingredients, addedIngredient],
      }));
  
      setSuccess(`Ingredient "${addedIngredient.name}" added successfully.`);
    } catch (err) {
      setError(`Error adding ingredient: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };
  

  const handleRemoveIngredient = (ingredientId) => {
    setIngredientToDelete(ingredientId);
    setShowDeleteConfirmation(true);
  };

  const confirmRemoveIngredient = async () => {
    if (ingredientToDelete === null) return;

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      await removeIngredientFromMeal(meal.id, ingredientToDelete);

      setIngredientsIds((prevIds) => prevIds.filter((id) => id !== ingredientToDelete));
      setMeal((prevMeal) => ({
        ...prevMeal,
        ingredients: prevMeal.ingredients.filter((ing) => ing.id !== ingredientToDelete),
      }));

      setSuccess('Ingredient removed successfully.');
    } catch (err) {
      setError(`Error removing ingredient: ${err.message}`);
    } finally {
      setLoading(false);
      setShowDeleteConfirmation(false);
      setIngredientToDelete(null);
    }
  };

  const cancelRemoveIngredient = () => {
    setShowDeleteConfirmation(false);
    setIngredientToDelete(null);
  };

  const handleAddModifiableIngredient = async (modifiableIngredient) => {
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const newModifiableIngredient = await addModifiableIngredient({
        ...modifiableIngredient,
        mealId: meal.id,
      });

      setModifiableIngredients((prev) => [...prev, newModifiableIngredient]);
      setSuccess('Modifiable ingredient added successfully.');
    } catch (err) {
      setError(`Error adding modifiable ingredient: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleEditModifiableIngredient = (index, updatedIngredient) => {
    setModifiableIngredients((prev) =>
      prev.map((ingredient, idx) => (idx === index ? updatedIngredient : ingredient))
    );
    setSuccess('Modifiable ingredient updated successfully.');
  };

  const handleRemoveModifiableIngredient = async (ingredientId) => {
    if (!ingredientId) {
      setError('No ingredient ID provided for removal.');
      return;
    }

    try {
      await removeModifiableIngredient(ingredientId);

      setModifiableIngredients((prevIngredients) =>
        prevIngredients.filter((ingredient) => ingredient.id !== ingredientId)
      );
    } catch (error) {
      setError('Failed to remove the ingredient.');
    }
  };

  if (loading && !meal) {
    return <div className="loading">Loading...</div>;
  }

  if (error && !meal) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div className="edit-meal-container">
      <div className="meal-grid">
       
        <div className="meal-form-container">
          <h2>Edit Meal</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="label">Name:</label>
              <input
                className="input"
                type="text"
                name="name"
                value={meal.name}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="label">Price:</label>
              <input
                className="input"
                type="number"
                name="price"
                value={meal.price}
                onChange={handleInputChange}
                required
                step="0.01"
              />
            </div>

            <div className="form-group">
              <label className="label">Calories:</label>
              <input
                className="input"
                type="number"
                name="calories"
                value={meal.calories}
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="label">Subcategory:</label>
              <select
                name="subcategoryId"
                value={meal.subcategoryId || ''}
                onChange={handleInputChange}
                required
              >
                <option value="">Select a subcategory</option>
                {allSubcategories.map((subcategory) => (
                  <option key={subcategory.id} value={subcategory.id}>
                    {subcategory.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="label">Current Image:</label>
              {meal.imageLink ? (
                <img src={meal.imageLink} alt={`${meal.name}`} className="current-image" />
              ) : (
                <p>No image available.</p>
              )}
            </div>

            <div className="form-group">
              <button
                type="button"
                onClick={toggleChangeImage}
                className="button change-image-button"
              >
                {isChangingImage ? 'Cancel Change' : 'Change Image'}
              </button>
            </div>

            {isChangingImage && (
              <div className="form-group">
                <label className="label">New Image:</label>
                <input
                  className="input"
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                />
              </div>
            )}

            <div className="button-group">
              <button className="button submit-button" type="submit" disabled={loading}>
                {loading ? 'Updating...' : 'Update Meal'}
              </button>
              <button className="button cancel-button" type="button" onClick={onClose}>
                Cancel
              </button>
            </div>
          </form>
        </div>

        <IngredientsManagement
          mealIngredients={meal.ingredients}
          availableIngredients={availableIngredients}
          handleAddIngredient={handleAddIngredient}
          handleRemoveIngredient={handleRemoveIngredient}
          loading={loading}
        />
  
        <ModifiableIngredientsManagement
          modifiableIngredients={modifiableIngredients}
          handleAddModifiableIngredient={handleAddModifiableIngredient}
          handleEditModifiableIngredient={handleEditModifiableIngredient}
          handleRemoveModifiableIngredient={handleRemoveModifiableIngredient}
          loading={loading}
          error={error}
        />
      </div>

      {showDeleteConfirmation && (
        <ConfirmationModal
          message="Are you sure you want to remove this ingredient?"
          onConfirm={confirmRemoveIngredient}
          onCancel={cancelRemoveIngredient}
          loading={loading}
        />
      )}
      {success && <div className="success-message">{success}</div>}
      {error && <div className="error-message">{error}</div>}
    </div>
  );
}

export default EditMeal;
