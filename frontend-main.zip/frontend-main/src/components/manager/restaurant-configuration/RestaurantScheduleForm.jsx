import React, { useState, useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import './RestaurantScheduleForm.scss';
import TimePicker from 'react-time-picker';
import 'react-time-picker/dist/TimePicker.css';
import 'react-clock/dist/Clock.css';
import { fetchSchedule, updateSchedule } from '../../../service/api/managerApi';

const daysOfWeek = [
  "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
];

const Button = ({ children, onClick, type, disabled, className }) => (
  <button
    className={`manager__schedule_button ${className || ''}`}
    onClick={onClick}
    type={type}
    disabled={disabled}
  >
    {children}
  </button>
);

const Card = ({ children, className }) => (
  <div className={`manager__schedule_card ${className || ''}`}>
    {children}
  </div>
);

const Toast = ({ title, description, variant, onClose }) => (
  <div className={`manager__schedule_toast ${variant}`}>
    <div className="manager__schedule_toast-content">
      <strong>{title}</strong>
      <p>{description}</p>
    </div>
    <button
      className="manager__schedule_toast-close"
      onClick={onClose}
      aria-label="Close Notification"
    >
      ×
    </button>
  </div>
);

export default function RestaurantScheduleForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toastData, setToastData] = useState(null);
  const [initialValues, setInitialValues] = useState([]);

  const { control, handleSubmit, setValue, watch, formState: { errors } } = useForm({
    defaultValues: {
      schedules: daysOfWeek.map((_, index) => ({
        dayOfWeek: index,
        openingTime: "09:00",
        closingTime: "18:00",
      }))
    },
  });

  useEffect(() => {
    const loadSchedule = async () => {
      try {
        const schedule = await fetchSchedule();
        setInitialValues(schedule);
        schedule.forEach((day) => {
          setValue(`schedules.${day.weekday - 1}.openingTime`, day.openingTime.slice(0, 5));
          setValue(`schedules.${day.weekday - 1}.closingTime`, day.closingTime.slice(0, 5));
        });
      } catch (error) {
        setToastData({
          title: "Error Loading Schedule",
          description: error.message || "There was an issue loading the schedule.",
          variant: "error",
        });
      }
    };

    loadSchedule();
  }, [setValue]);

  const onSubmit = async (values) => {
    const isValidSchedule = values.schedules.every(schedule => {
      const [openHour, openMinute] = schedule.openingTime.split(':').map(Number);
      const [closeHour, closeMinute] = schedule.closingTime.split(':').map(Number);
      if (closeHour > openHour) return true;
      if (closeHour === openHour && closeMinute > openMinute) return true;
      return false;
    });

    if (!isValidSchedule) {
      setToastData({
        title: "Invalid Schedule",
        description: "Closing time must be later than opening time.",
        variant: "error",
      });
      return;
    }

    setIsSubmitting(true);
    setToastData(null);
    try {
      const updatePromises = values.schedules.map(async (schedule, index) => {
        const initialSchedule = initialValues.find(day => day.weekday === index + 1);
        if (
          initialSchedule &&
          (initialSchedule.openingTime.slice(0, 5) !== schedule.openingTime ||
          initialSchedule.closingTime.slice(0, 5) !== schedule.closingTime)
        ) {
          const openingTime = new Date(`1970-01-01T${schedule.openingTime}:00`);
          const closingTime = new Date(`1970-01-01T${schedule.closingTime}:00`);
          return updateSchedule(schedule.dayOfWeek + 1, openingTime, closingTime);
        }
        return Promise.resolve();
      });

      await Promise.all(updatePromises);
      setToastData({
        title: "Schedule Updated",
        description: "The restaurant schedule has been successfully updated.",
        variant: "success",
      });
    } catch (error) {
      setToastData({
        title: "Error Updating Schedule",
        description: error.message || "There was an issue updating the schedule.",
        variant: "error",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="manager__schedule_form-container">
      {toastData && <Toast {...toastData} onClose={() => setToastData(null)} />}
      <form onSubmit={handleSubmit(onSubmit)} className="manager__schedule_form">
        <div className="manager__schedule_cards-grid">
          {daysOfWeek.map((day, index) => (
            <Card
              key={day}
              className={`manager__schedule_card ${
                errors.schedules?.[index] ? 'manager__schedule_card--error' : ''
              }`}
            >
              <div className="manager__schedule_card-header">
                <h3>{day}</h3>
              </div>
              <div className="manager__schedule_card-content">
                <div className="manager__schedule_time-inputs">
                  <div className="manager__schedule_time-group">
                    <label>Opening Time</label>
                    <Controller
                      name={`schedules.${index}.openingTime`}
                      control={control}
                      rules={{
                        required: "Required",
                        pattern: {
                          value: /^([0-1]\d|2[0-3]):([0-5]\d)$/i,
                          message: "Invalid time format",
                        }
                      }}
                      render={({ field }) => (
                        <TimePicker
                          onChange={(time) => field.onChange(time)}
                          value={field.value}
                          disableClock
                          clearIcon={null}
                          format="HH:mm"
                          className="manager__schedule_time-picker"
                        />
                      )}
                    />
                  </div>
                </div>
                <div className="manager__schedule_time-inputs">
                  <div className="manager__schedule_time-group">
                    <label>Closing Time</label>
                    <Controller
                      name={`schedules.${index}.closingTime`}
                      control={control}
                      rules={{
                        required: "Required",
                        pattern: {
                          value: /^([0-1]\d|2[0-3]):([0-5]\d)$/i,
                          message: "Invalid time format",
                        }
                      }}
                      render={({ field }) => (
                        <TimePicker
                          onChange={(time) => field.onChange(time)}
                          value={field.value}
                          disableClock
                          clearIcon={null}
                          format="HH:mm"
                          className="manager__schedule_time-picker"
                        />
                      )}
                    />
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
        <Button type="submit" disabled={isSubmitting} className="manager__schedule_submit-button">
          {isSubmitting ? "Saving..." : "Save Schedule"}
        </Button>
      </form>
    </div>
  );
}
