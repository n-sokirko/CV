import React, {useState, useEffect} from 'react';
import './ViewAllergen.scss';
import {
    fetchAllergens,
    deleteAllergen,
    updateAllergen,
    getAllIngredients,
    getAllDiets,
} from '../../../service/api/managerApi';

function ViewAllergen() {
    const [allergens, setAllergens] = useState([]);
    const [selectedAllergen, setSelectedAllergen] = useState(null);
    const [editMode, setEditMode] = useState(false);
    const [allergenName, setAllergenName] = useState('');
    const [allergenCode, setAllergenCode] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            try {
                const data = await fetchAllergens();
                setAllergens(data.content || data);
            } catch (error) {
                setErrorMessage('Error fetching allergens.');
            }
        };

        fetchData();
    }, []);

    const handleAllergenClick = (allergen) => {
        if (!editMode) {
            if (selectedAllergen && selectedAllergen.id === allergen.id) {

                setSelectedAllergen(null);
            } else {

                setSelectedAllergen(allergen);
            }
            setErrorMessage('');
            setSuccessMessage('');
        }
    };

    const handleDeleteAllergen = async (allergenId) => {

        try {

            const ingredientsData = await getAllIngredients();
            const ingredients = ingredientsData.content || ingredientsData;

            const isUsedInIngredients = ingredients.some((ingredient) =>
                ingredient.allergens.some(
                    (allergen) => allergen.id === allergenId
                )
            );

            const dietsData = await getAllDiets();
            const diets = dietsData.content || dietsData;

            const isUsedInDiets = diets.some((diet) =>
                diet.allergens.some((allergen) => allergen.id === allergenId)
            );

            if (isUsedInIngredients || isUsedInDiets) {
                setErrorMessage(
                    'Cannot delete allergen because it is associated with existing ingredients or diets.'
                );
                setSuccessMessage('');
                return;
            }

            await deleteAllergen(allergenId);
            const updatedAllergens = allergens.filter(
                (allergen) => allergen.id !== allergenId
            );
            setAllergens(updatedAllergens);
            if (selectedAllergen && selectedAllergen.id === allergenId) {
                setSelectedAllergen(null);
            }
            setErrorMessage('');
            setSuccessMessage('Allergen deleted successfully.');
        } catch (error) {
            setErrorMessage(
                error.message || 'Error deleting allergen.'
            );
            setSuccessMessage('');
        }
    };

    const handleEditAllergen = () => {
        if (selectedAllergen) {
            setEditMode(true);
            setAllergenName(selectedAllergen.name);
            setAllergenCode(selectedAllergen.code);
            setErrorMessage('');
            setSuccessMessage('');
        }
    };

    const handleSaveAllergen = async () => {
        if (selectedAllergen) {
            if (!allergenName.trim() || !allergenCode.trim()) {
                setErrorMessage('Allergen name and code cannot be empty.');
                setSuccessMessage('');
                return;
            }
            try {
                await updateAllergen(selectedAllergen.id, {
                    name: allergenName.trim(),
                    code: allergenCode.trim(),
                });
                const updatedAllergens = allergens.map((allergen) =>
                    allergen.id === selectedAllergen.id
                        ? {
                            ...allergen,
                            name: allergenName.trim(),
                            code: allergenCode.trim(),
                        }
                        : allergen
                );
                setAllergens(updatedAllergens);
                setSelectedAllergen({
                    ...selectedAllergen,
                    name: allergenName.trim(),
                    code: allergenCode.trim(),
                });
                setEditMode(false);
                setErrorMessage('');
                setSuccessMessage('Allergen updated successfully.');
            } catch (error) {
                setErrorMessage(
                    error.message || 'Error updating allergen.'
                );
                setSuccessMessage('');
            }
        }
    };

    const handleCancelEdit = () => {
        setEditMode(false);
        setAllergenName(selectedAllergen ? selectedAllergen.name : '');
        setAllergenCode(selectedAllergen ? selectedAllergen.code : '');
        setErrorMessage('');
        setSuccessMessage('');
    };

    return (
        <div className="view-allergen-container">
            <h2>Allergens List</h2>
            <div className="allergen-list">
                {allergens.map((allergen) => (
                    <div
                        key={allergen.id}
                        className={`allergen-item ${
                            selectedAllergen?.id === allergen.id ? 'active' : ''
                        }`}
                        onClick={() => handleAllergenClick(allergen)}
                    >
                        {allergen.name}
                    </div>
                ))}
            </div>

            {selectedAllergen ? (
                <div className="allergen-details">
                    <h3>{selectedAllergen.name}</h3>
                    <p>Code: {selectedAllergen.code}</p>
                    <div className="allergen-actions">
                        <button
                            className="edit-allergen-button"
                            onClick={handleEditAllergen}
                        >
                            Edit Allergen
                        </button>
                        <button
                            className="delete-allergen-button"
                            onClick={() =>
                                handleDeleteAllergen(selectedAllergen.id)
                            }
                        >
                            Delete Allergen
                        </button>
                    </div>

                    {editMode && (
                        <div className="edit-allergen">
                            <label htmlFor="allergenName">
                                Name:
                                <input
                                    id="allergenName"
                                    type="text"
                                    value={allergenName}
                                    onChange={(e) => {
                                        setAllergenName(e.target.value);
                                        setErrorMessage('');
                                        setSuccessMessage('');
                                    }}
                                />
                            </label>
                            <label htmlFor="allergenCode">
                                Code:
                                <input
                                    id="allergenCode"
                                    type="text"
                                    value={allergenCode}
                                    onChange={(e) => {
                                        setAllergenCode(e.target.value);
                                        setErrorMessage('');
                                        setSuccessMessage('');
                                    }}
                                />
                            </label>
                            <div className="edit-buttons">
                                <button
                                    className="save-button"
                                    onClick={handleSaveAllergen}
                                >
                                    Save
                                </button>
                                <button
                                    className="cancel-button"
                                    onClick={handleCancelEdit}
                                >
                                    Cancel
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            ) : (
                <p>Select an allergen to view details</p>
            )}

            {errorMessage && <p className="error-message">{errorMessage}</p>}
            {successMessage && (
                <p className="success-message">{successMessage}</p>
            )}
        </div>
    );
}

export default ViewAllergen;
