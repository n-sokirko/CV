import {useState, useEffect} from 'react';
import './AddAllergen.scss';
import {addAllergen, getAllergens} from '../../../service/api/managerApi';

function AddAllergenComponent() {
    const [allergenName, setAllergenName] = useState('');
    const [allergenCode, setAllergenCode] = useState('');
    const [ingredients, setIngredients] = useState([]);

    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    const [existingAllergens, setExistingAllergens] = useState([]);


    useEffect(() => {
        const fetchExistingAllergens = async () => {
            try {
                const allergens = await getAllergens();
                setExistingAllergens(allergens);
            } catch (error) {
                setErrorMessage('Failed to fetch existing allergens.');

                setTimeout(() => {
                    setErrorMessage('');
                }, 5000);
            }
        };

        fetchExistingAllergens();
    }, []);

    const handleTagRemove = (id) => {
        setIngredients(ingredients.filter(ingredient => ingredient.id !== id));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();


        setErrorMessage('');
        setSuccessMessage('');

        const trimmedName = allergenName.trim();
        const trimmedCode = allergenCode.trim();


        if (!trimmedName) {
            setErrorMessage('Allergen name is required.');
            return;
        }

        if (!trimmedCode) {
            setErrorMessage('Allergen code is required.');
            return;
        }


        const isDuplicate = existingAllergens.some(
            (allergen) => allergen.name.toLowerCase() === trimmedName.toLowerCase()
        );

        if (isDuplicate) {
            setErrorMessage('An allergen with this name already exists.');
            return;
        }

        const newAllergen = {
            name: trimmedName,
            code: trimmedCode,
            ingredients: ingredients.map(ingredient => ingredient.id)
        };

        try {
            await addAllergen(newAllergen);
            setSuccessMessage('Allergen added successfully!');
            setAllergenName('');
            setAllergenCode('');
            setIngredients([]);


            setExistingAllergens((prevAllergens) => [...prevAllergens, newAllergen]);


            setTimeout(() => {
                setSuccessMessage('');
            }, 3000);
        } catch (error) {
            setErrorMessage('Failed to add allergen. Please try again.');


            setTimeout(() => {
                setErrorMessage('');
            }, 5000);
        }
    };

    return (
        <form className="add-allergen-container" onSubmit={handleSubmit}>
            <h2>Add New Allergen</h2>

            {errorMessage && <div className="error-message">{errorMessage}</div>}
            {successMessage && <div className="success-message">{successMessage}</div>}

            <div className="form-group">
                <label className="label" htmlFor="allergen-name">Allergen Name:</label>
                <input
                    className="input"
                    type="text"
                    id="allergen-name"
                    value={allergenName}
                    onChange={(e) => setAllergenName(e.target.value)}
                    required
                />
            </div>

            <div className="form-group">
                <label className="label" htmlFor="allergen-code">Allergen Code:</label>
                <input
                    className="input"
                    type="text"
                    id="allergen-code"
                    value={allergenCode}
                    onChange={(e) => setAllergenCode(e.target.value)}
                    required
                />
            </div>

            <div className="tags-container">
                {ingredients.map((ingredient) => (
                    <div key={ingredient.id} className="tag">
                        {ingredient.name}
                        <span className="remove-tag" onClick={() => handleTagRemove(ingredient.id)}>x</span>
                    </div>
                ))}
            </div>

            <button className="submit-button" type="submit">OK</button>
        </form>
    );
}

export default AddAllergenComponent;
