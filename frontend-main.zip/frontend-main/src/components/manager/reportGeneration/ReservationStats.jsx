import React from 'react';
import './ReservationStats.scss';

export default function ReservationStats({ reservations }) {
  const totalReservations = reservations.length;
  const totalPeople = reservations.reduce((acc, curr) => acc + curr.numberOfPeople, 0);
  const averagePeople = totalReservations > 0 ? (totalPeople / totalReservations).toFixed(2) : 0;
  const statusCounts = reservations.reduce((acc, curr) => {
    acc[curr.state] = (acc[curr.state] || 0) + 1;
    return acc;
  }, {});
  const timeCounts = reservations.reduce((acc, curr) => {
    const time = `${curr.startTime} - ${curr.endTime}`;
    acc[time] = (acc[time] || 0) + 1;
    return acc;
  }, {});
  const popularTime = Object.keys(timeCounts).reduce((a, b) => (timeCounts[a] > timeCounts[b] ? a : b), 'N/A');
  const deskCounts = reservations.reduce((acc, curr) => {
    curr.diningDeskIds.forEach((deskId) => {
      acc[deskId] = (acc[deskId] || 0) + 1;
    });
    return acc;
  }, {});
  const mostReservedDesk = Object.keys(deskCounts).reduce((a, b) => (deskCounts[a] > deskCounts[b] ? a : b), 'N/A');

  return (
    <div className="manager__reservation-stats">
      <h3 className="manager__reservation-stats--title">Reservation Statistics</h3>
      <div className="manager__reservation-stats--cards">
        <div className="manager__stat-card">
          <span className="manager__stat-card--number">{totalReservations}</span>
          <span className="manager__stat-card--label">Total Reservations</span>
        </div>
        <div className="manager__stat-card">
          <span className="manager__stat-card--number">{totalPeople}</span>
          <span className="manager__stat-card--label">Total People</span>
        </div>
        <div className="manager__stat-card">
          <span className="manager__stat-card--number">{averagePeople}</span>
          <span className="manager__stat-card--label">Average People per Reservation</span>
        </div>
        <div className="manager__stat-card">
          <span className="manager__stat-card--number">{popularTime || 'N/A'}</span>
          <span className="manager__stat-card--label">Most Popular Time</span>
        </div>
        <div className="manager__stat-card">
          <span className="manager__stat-card--number">{mostReservedDesk || 'N/A'}</span>
          <span className="manager__stat-card--label">Most Reserved Desk</span>
        </div>
      </div>
    </div>
  );
}
