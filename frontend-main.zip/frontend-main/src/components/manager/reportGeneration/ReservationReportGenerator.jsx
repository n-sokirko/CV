import React, { useState, useEffect } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { jsPDF } from 'jspdf';
import { FaFilePdf, FaCalendarAlt, FaArrowLeft } from 'react-icons/fa';
import './ReportGenerator.scss';
import { getReservationsByDate } from '../../../service/api/managerApi';
import ReservationStats from './ReservationStats';

const generatePDF = (reportType, date, reservations) => {
  const totalReservations = reservations.length;
  const totalPeople = reservations.reduce((acc, curr) => acc + curr.numberOfPeople, 0);
  const averagePeople = totalReservations > 0 ? (totalPeople / totalReservations).toFixed(2) : 0;

  const statusCounts = reservations.reduce((acc, curr) => {
    acc[curr.state] = (acc[curr.state] || 0) + 1;
    return acc;
  }, {});

  const timeCounts = reservations.reduce((acc, curr) => {
    const time = `${curr.startTime} - ${curr.endTime}`;
    acc[time] = (acc[time] || 0) + 1;
    return acc;
  }, {});
  const popularTime = Object.keys(timeCounts).reduce((a, b) => (timeCounts[a] > timeCounts[b] ? a : b), 'N/A');

  const deskCounts = reservations.reduce((acc, curr) => {
    curr.diningDeskIds.forEach((deskId) => {
      acc[deskId] = (acc[deskId] || 0) + 1;
    });
    return acc;
  }, {});
  const mostReservedDesk = Object.keys(deskCounts).reduce((a, b) => (deskCounts[a] > deskCounts[b] ? a : b), 'N/A');

  const doc = new jsPDF();

  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text(`${reportType}`, 105, 30, { align: 'center' });

  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text(`Date: ${date.toLocaleDateString()}`, 20, 50);

  doc.setDrawColor(0);
  doc.setLineWidth(0.5);
  doc.line(20, 55, 190, 55);

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(50, 100, 150);
  doc.text('Statistics:', 20, 70);

  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);
  let y = 80;

  doc.setFont('helvetica', 'bold');
  doc.text('Total Reservations:', 20, y);
  doc.setFont('helvetica', 'normal');
  doc.text(`${totalReservations}`, 150, y);
  y += 10;

  doc.setFont('helvetica', 'bold');
  doc.text('Total People:', 20, y);
  doc.setFont('helvetica', 'normal');
  doc.text(`${totalPeople}`, 150, y);
  y += 10;

  doc.setFont('helvetica', 'bold');
  doc.text('Average People per Reservation:', 20, y);
  doc.setFont('helvetica', 'normal');
  doc.text(`${averagePeople}`, 150, y);
  y += 10;

  doc.setFont('helvetica', 'bold');
  doc.text('Most Popular Time:', 20, y);
  doc.setFont('helvetica', 'normal');
  doc.text(`${popularTime}`, 150, y);
  y += 10;

  doc.setFont('helvetica', 'bold');
  doc.text('Most Reserved Desk:', 20, y);
  doc.setFont('helvetica', 'normal');
  doc.text(`${mostReservedDesk}`, 150, y);
  y += 20;

  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(50, 100, 150);
  doc.text('Reservations by Status:', 20, y);
  y += 10;

  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);

  Object.entries(statusCounts).forEach(([status, count]) => {
    const color = getStatusColor(status);
    doc.setFillColor(color.r, color.g, color.b);
    doc.circle(20, y - 3, 2, 'F');
    doc.text(`${status}: ${count}`, 25, y);
    y += 10;
  });

  y += 10;
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.5);
  doc.line(20, y, 190, y);
  y += 10;

  doc.save(`${reportType.replace(/\s+/g, '_')}_${date.toISOString().split('T')[0]}.pdf`);
};

const getStatusColor = (status) => {
  switch (status.toLowerCase()) {
    case 'confirmed':
      return { r: 0, g: 128, b: 0 };
    case 'pending':
      return { r: 255, g: 165, b: 0 };
    case 'cancelled':
      return { r: 255, g: 0, b: 0 };
    default:
      return { r: 0, g: 0, b: 0 };
  }
};

const reports = [
  { id: 'reservations', name: 'Reservations Report' },
];

export default function ReservationReportGenerator({ goBack }) {
  const [selectedReport, setSelectedReport] = useState(null);
  const [reportDates, setReportDates] = useState({});
  const [reservations, setReservations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleDateChange = (date, reportId) => {
    setReportDates((prevDates) => ({
      ...prevDates,
      [reportId]: date,
    }));
  };

  const fetchReservations = async (date) => {
    setLoading(true);
    setError('');
    try {
      const filteredReservations = await getReservationsByDate(date);
    
      setReservations(filteredReservations);
    } catch (err) {
      setError(err.message || 'Error fetching reservations');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  

  const handleSelect = (reportId) => {
    setSelectedReport(reportId);
    const date = reportDates[reportId];
    if (date) {
      fetchReservations(date);
    } else {
      setError('Please select a date');
    }
  };

  const handleGeneratePDF = () => {
    const reportName = reports.find((r) => r.id === selectedReport)?.name;
    const date = reportDates[selectedReport];
    if (reportName && date) {
      generatePDF(reportName, date, reservations);
    }
  };

  useEffect(() => {
    setReservations([]);
    setError('');
  }, [selectedReport]);

  return (
    <div className="manager__report-generator">
      <button className="manager__back-button" onClick={goBack}>
        <FaArrowLeft /> Back
      </button>
      <h1 className="manager__report-generator--title">Reservation Manager Reports</h1>
      <div className="manager__report-generator--content">
        <div className="manager__report-generator--reports">
          <div className="manager__report-generator--reports-grid">
            {reports.map((report) => (
              <div key={report.id} className="manager__report-card">
                <div className="manager__report-card--header">
                  <FaFilePdf className="manager__report-card--icon" />
                  <h2 className="manager__report-card--title">{report.name}</h2>
                </div>
                <div className="manager__report-card--date-picker">
                  <FaCalendarAlt className="manager__date-picker--icon" />
                  <DatePicker
                    id={`date-${report.id}`}
                    selected={reportDates[report.id]}
                    onChange={(date) => handleDateChange(date, report.id)}
                    dateFormat="yyyy-MM-dd"
                    placeholderText="Choose a date"
                    className="manager__date-picker--input"
                  />
                </div>
                <div className="manager__report-card--buttons">
                  <button
                    className="manager__report-card--button select-button"
                    onClick={() => handleSelect(report.id)}
                  >
                    Select
                  </button>
                  <button
                    className={`manager__report-card--button generate-button ${
                      !reportDates[report.id] ? 'disabled' : ''
                    }`}
                    onClick={handleGeneratePDF}
                    disabled={!reportDates[report.id]}
                  >
                    Generate PDF
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="manager__report-generator--preview">
          <div className="manager__report-preview">
            <h2 className="manager__report-preview--title">
              {selectedReport
                ? `${reports.find((r) => r.id === selectedReport)?.name} Preview`
                : 'Select a Report'}
            </h2>
            {selectedReport ? (
              <div className="manager__report-preview--content">
                {loading ? (
                  <p>Loading reservations...</p>
                ) : error ? (
                  <p className="error">{error}</p>
                ) : (
                  <>
                    <p className="manager__report-preview--description">
                      Reservations for{' '}
                      <span className="manager__report-preview--highlight">
                        {reportDates[selectedReport]?.toLocaleDateString()}
                      </span>
                      :
                    </p>
                    <div className="manager__report-preview--reservations">
                      <ReservationStats reservations={reservations} />
                    </div>
                  </>
                )}
              </div>
            ) : (
              <p className="manager__report-preview--instruction">Please select a report from the left to view its preview.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
