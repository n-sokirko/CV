import React, { useState, useEffect } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { jsPDF } from 'jspdf';
import { FaFilePdf, FaCalendarAlt, FaArrowLeft } from 'react-icons/fa';
import './ReportGenerator.scss';
import { getOrdersByDate } from '../../../service/api/managerApi';
import OrderStats from './OrderStats';

const generateOrderPDF = (reportType, date, orders) => {
  const totalOrders = orders.length;
  const totalRevenue = orders.reduce((acc, curr) => acc + curr.amount, 0);
  const averageRevenue = totalOrders > 0 ? (totalRevenue / totalOrders).toFixed(2) : 0;

  const statusCounts = orders.reduce((acc, curr) => {
    acc[curr.status] = (acc[curr.status] || 0) + 1;
    return acc;
  }, {});

  const doc = new jsPDF();

  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text(`${reportType}`, 105, 30, { align: 'center' });

  doc.setFontSize(14);
  doc.setFont('helvetica', 'normal');
  doc.text(`Date: ${date.toLocaleDateString()}`, 20, 50);

  doc.setDrawColor(0);
  doc.setLineWidth(0.5);
  doc.line(20, 55, 190, 55);

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(50, 100, 150);
  doc.text('Statistics:', 20, 70);

  let y = 80;
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);

  doc.text(`- Total Orders: ${totalOrders}`, 20, y);
  y += 10;
  doc.text(`- Total Revenue: $${totalRevenue.toFixed(2)}`, 20, y);
  y += 10;
  doc.text(`- Average Revenue per Order: $${averageRevenue}`, 20, y);
  y += 20;

  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(50, 100, 150);
  doc.text('Orders by Status:', 20, y);
  y += 10;

  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);

  Object.entries(statusCounts).forEach(([status, count]) => {
    doc.text(`- ${status}: ${count}`, 20, y);
    y += 10;
  });

  doc.save(`${reportType.replace(/\s+/g, '_')}_${date.toISOString().split('T')[0]}.pdf`);
};

const reports = [
  { id: 'orders', name: 'Orders Report' },
];

const OrderReportGenerator = ({ goBack }) => {
  const [selectedReport, setSelectedReport] = useState(null);
  const [reportDates, setReportDates] = useState({});
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleDateChange = (date, reportId) => {
    setReportDates((prevDates) => ({
      ...prevDates,
      [reportId]: date,
    }));
  };

  const fetchOrders = async (date) => {
    setLoading(true);
    setError('');
    try {
      const filteredOrders = await getOrdersByDate(date);
      setOrders(filteredOrders);
    } catch (err) {
      setError(err.message || 'Error fetching orders');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (reportId) => {
    setSelectedReport(reportId);
    const date = reportDates[reportId];
    if (date) {
      fetchOrders(date);
    } else {
      setError('Please select a date');
    }
  };

  const handleGeneratePDF = () => {
    const reportName = reports.find((r) => r.id === selectedReport)?.name;
    const date = reportDates[selectedReport];
    if (reportName && date) {
      generateOrderPDF(reportName, date, orders);
    }
  };

  useEffect(() => {
    setOrders([]);
    setError('');
  }, [selectedReport]);

  return (
    <div className="manager__report-generator">
      <button className="manager__back-button" onClick={goBack}>
        <FaArrowLeft /> Back
      </button>
      <h1 className="manager__report-generator--title">Orders Manager Reports</h1>
      <div className="manager__report-generator--content">
        <div className="manager__report-generator--reports">
          <div className="manager__report-generator--reports-grid">
            {reports.map((report) => (
              <div key={report.id} className="manager__report-card">
                <div className="manager__report-card--header">
                  <FaFilePdf className="manager__report-card--icon" />
                  <h2 className="manager__report-card--title">{report.name}</h2>
                </div>
                <div className="manager__report-card--date-picker">
                  <FaCalendarAlt className="manager__date-picker--icon" />
                  <DatePicker
                    id={`date-${report.id}`}
                    selected={reportDates[report.id]}
                    onChange={(date) => handleDateChange(date, report.id)}
                    dateFormat="yyyy-MM-dd"
                    placeholderText="Choose a date"
                    className="manager__date-picker--input"
                    maxDate={new Date()}
                  />
                </div>
                <div className="manager__report-card--buttons">
                  <button
                    className="manager__report-card--button select-button"
                    onClick={() => handleSelect(report.id)}
                  >
                    Select
                  </button>
                  <button
                    className={`manager__report-card--button generate-button ${
                      !reportDates[report.id] ? 'disabled' : ''
                    }`}
                    onClick={handleGeneratePDF}
                    disabled={!reportDates[report.id]}
                  >
                    Generate PDF
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="manager__report-generator--preview">
          <div className="manager__report-preview">
            <h2 className="manager__report-preview--title">
              {selectedReport
                ? `${reports.find((r) => r.id === selectedReport)?.name} Preview`
                : 'Select a Report'}
            </h2>
            {selectedReport ? (
              <div className="manager__report-preview--content">
                {loading ? (
                  <p>Loading orders...</p>
                ) : error ? (
                  <p className="error">{error}</p>
                ) : (
                  <>
                    <p className="manager__report-preview--description">
                      Orders for{' '}
                      <span className="manager__report-preview--highlight">
                        {reportDates[selectedReport]?.toLocaleDateString()}
                      </span>
                      :
                    </p>
                    <div className="manager__report-preview--reservations">
                      <OrderStats orders={orders} />
                    </div>
                  </>
                )}
              </div>
            ) : (
              <p className="manager__report-preview--instruction">Please select a report from the left to view its preview.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderReportGenerator;
