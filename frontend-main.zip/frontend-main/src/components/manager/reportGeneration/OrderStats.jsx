import React from 'react';
import './OrderStats.scss';

export default function OrderStats({ orders }) {
  const totalOrders = orders.length;

  const totalRevenue = orders.reduce((acc, curr) => acc + (curr.amount || 0), 0);

  const averageRevenue = totalOrders > 0 ? (totalRevenue / totalOrders).toFixed(2) : 0;

  const statusCounts = orders.reduce((acc, curr) => {
    acc[curr.state] = (acc[curr.state] || 0) + 1;
    return acc;
  }, {});

  const mealCounts = orders.flatMap(order => order.orderedMeals).reduce((acc, meal) => {
    acc[meal.mealId] = (acc[meal.mealId] || 0) + meal.count;
    return acc;
  }, {});
  const mostOrderedMeal = Object.keys(mealCounts).reduce(
    (a, b) => (mealCounts[a] > mealCounts[b] ? a : b),
    'N/A'
  );

  return (
    <div className="manager__order-stats">
      <h3 className="manager__order-stats--title">Order Statistics</h3>
      <div className="manager__order-stats--cards">
        <div className="manager__stat-card">
          <span className="manager__stat-card--number">{totalOrders}</span>
          <span className="manager__stat-card--label">Total Orders</span>
        </div>
        <div className="manager__stat-card">
          <span className="manager__stat-card--number">${totalRevenue.toFixed(2)}</span>
          <span className="manager__stat-card--label">Total Revenue</span>
        </div>
        <div className="manager__stat-card">
          <span className="manager__stat-card--number">${averageRevenue}</span>
          <span className="manager__stat-card--label">Average Revenue per Order</span>
        </div>
        <div className="manager__stat-card">
          <span className="manager__stat-card--number">{mostOrderedMeal || 'N/A'}</span>
          <span className="manager__stat-card--label">Most Ordered Meal</span>
        </div>
      </div>
      <div className="manager__order-stats--details">
        <h4 className="manager__order-stats--subtitle">Orders by Status:</h4>
        <ul className="manager__order-stats--list">
          {Object.entries(statusCounts).map(([status, count]) => (
            <li key={status} className="manager__order-stats--list-item">
              <strong>{status}:</strong> {count}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
