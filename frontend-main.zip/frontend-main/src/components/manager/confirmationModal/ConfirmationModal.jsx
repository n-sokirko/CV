
import React from 'react';
import './ConfirmationModal.scss';

const ConfirmationModal = ({ message, onConfirm, onCancel, loading }) => {
  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <p>{message}</p>
        <button onClick={onConfirm} disabled={loading}>
          Yes
        </button>
        <button onClick={onCancel} disabled={loading}>
          No
        </button>
      </div>
    </div>
  );
};

export default ConfirmationModal;
