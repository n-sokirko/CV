import React, {useState} from 'react';
import './AddCategory.scss';
import {addCategory} from '../../../service/api/managerApi';
import {FaPlus} from 'react-icons/fa';

function AddCategory() {
    const [categoryName, setCategoryName] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (categoryName.trim()) {
            try {
                await addCategory({name: categoryName.trim()});
                setCategoryName('');
                setErrorMessage('');
                setSuccessMessage('Category added successfully.');
            } catch (error) {
                setErrorMessage(error.message || 'Failed to add category.');
                setSuccessMessage('');
            }
        } else {
            setErrorMessage('Category name is empty or invalid.');
            setSuccessMessage('');
        }
    };

    return (
        <div className="add-category-page">
            <div className="add-category-container">
                <h2>Add Category</h2>
                <form onSubmit={handleSubmit}>
                    <label>
                        Category Name:
                        <input
                            type="text"
                            value={categoryName}
                            onChange={(e) => {
                                setCategoryName(e.target.value);
                                setErrorMessage('');
                                setSuccessMessage('');
                            }}
                            placeholder="Enter category name"
                        />
                    </label>
                    <button type="submit" className="add-btn">
                        <FaPlus/> Add Category
                    </button>
                </form>
                {errorMessage && <p className="error-message">{errorMessage}</p>}
                {successMessage && <p className="success-message">{successMessage}</p>}
            </div>
        </div>
    );
}

export default AddCategory;
