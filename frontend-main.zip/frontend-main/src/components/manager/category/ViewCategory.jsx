import React, { useState, useEffect } from 'react';
import { getAllCategories, updateCategory, deleteCategory,getAllMeals,getAllSubcategories} from '../../../service/api/managerApi';
import './ViewCategory.scss';
import { FaEdit, FaTrash } from 'react-icons/fa';

const ViewCategory = () => {
    const [categories, setCategories] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState(null);
    const [editName, setEditName] = useState(false);
    const [newCategoryName, setNewCategoryName] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const data = await getAllCategories();
                if (data && Array.isArray(data.content)) {
                    setCategories(data.content);
                } else {
                    setErrorMessage('Fetched categories data is not in expected format.');
                }
            } catch (error) {
                setErrorMessage('Error fetching categories.');
            }
        };

        fetchCategories();
    }, []);

    const handleSelectCategory = (category) => {
        setSelectedCategory(category);
        setNewCategoryName(category.name);
        setErrorMessage('');
        setSuccessMessage('');
    };

    const handleEditCategoryName = async () => {
        if (selectedCategory && newCategoryName.trim()) {
            try {
                await updateCategory(selectedCategory.id, { name: newCategoryName.trim() });
                setCategories(categories.map(category =>
                    category.id === selectedCategory.id ? { ...category, name: newCategoryName.trim() } : category
                ));
                setSelectedCategory(prev => ({
                    ...prev,
                    name: newCategoryName.trim()
                }));
                setEditName(false);
                setSuccessMessage('Category updated successfully.');
                setErrorMessage('');
            } catch (error) {
                setErrorMessage('Failed to update category.');
            }
        } else {
            setErrorMessage('Category name cannot be empty.');
        }
    };

    const handleDeleteCategory = async () => {
        if (selectedCategory) {
            try {
                const subcategoriesData = await getAllSubcategories();
                let subcategories = [];
          
                if (Array.isArray(subcategoriesData)) {
                  subcategories = subcategoriesData;
                } else if (Array.isArray(subcategoriesData.content)) {
                  subcategories = subcategoriesData.content;
                } else {
                  setErrorMessage('Failed to fetch subcategories data: Unexpected data format.');
                  setSuccessMessage('');
                  return; 
                }
          
                const selectedCategoryId = Number(selectedCategory.id);
          
                const hasSubcategories = subcategories.some(
                  (subcat) => Number(subcat.categoryId) === selectedCategoryId
                );
          
                if (hasSubcategories) {
                  setErrorMessage(
                    'Cannot delete category because it has associated subcategories.'
                  );
                  setSuccessMessage('');
                  return;
                }
              } catch (error) {
                setErrorMessage(`Failed to check category usage: ${error.message}`);
                setSuccessMessage('');
                return; 
              }
          
           
              try {
                await deleteCategory(selectedCategory.id);
                setCategories(
                  categories.filter((category) => category.id !== selectedCategory.id)
                );
                setSelectedCategory(null);
                setErrorMessage('');
                setSuccessMessage('Category deleted successfully.');
              } catch (error) {
                setErrorMessage(error.message || 'Failed to delete category.');
                setSuccessMessage('');
              }
        }
      };
      

    const handleCancelEdit = () => {
        setEditName(false);
        setNewCategoryName(selectedCategory?.name || '');
        setErrorMessage('');
        setSuccessMessage('');
    };

    return (
        <div className="view-category-container">
            <h2>Categories List</h2>
            <div className="category-list">
                {categories.map(category => (
                    <div
                        key={category.id}
                        className={`category-item ${selectedCategory?.id === category.id ? 'active' : ''}`}
                        onClick={() => handleSelectCategory(category)}
                    >
                        {category.name}
                    </div>
                ))}
            </div>

            {selectedCategory ? (
                <div className="category-details">
                    <h3>
                        {editName ? (
                            <>
                                <input
                                    type="text"
                                    value={newCategoryName}
                                    onChange={(e) => setNewCategoryName(e.target.value)}
                                    onBlur={handleEditCategoryName}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            handleEditCategoryName();
                                        }
                                    }}
                                />
                                <div className="edit-buttons">
                                    <button onClick={handleEditCategoryName} className="save-btn">
                                        Save
                                    </button>
                                    <button onClick={handleCancelEdit} className="cancel-btn">
                                        Cancel
                                    </button>
                                </div>
                            </>
                        ) : (
                            <>
                                {selectedCategory.name}
                                <FaEdit className="edit-icon" onClick={() => setEditName(true)} />
                            </>
                        )}
                    </h3>
                    <div className="category-actions">
                        <button onClick={handleDeleteCategory} className="delete-btn">
                            Delete Category <FaTrash />
                        </button>
                    </div>
                    {errorMessage && <p className="error-message">{errorMessage}</p>}
                    {successMessage && <p className="success-message">{successMessage}</p>}
                </div>
            ) : (
                <p>Select a category to view details</p>
            )}
        </div>
    );
};

export default ViewCategory;
