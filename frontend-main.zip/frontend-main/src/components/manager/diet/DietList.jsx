import React, { useEffect, useState } from 'react';
import {
  getAllDiets,
  addAllergenToDiet,
  deleteAllergenFromDiet,
  fetchAllergens,
  deleteDiet,
} from '../../../service/api/managerApi';
import './DietList.scss';
import Select from 'react-select'; 
const DietList = () => {
  const [diets, setDiets] = useState([]);
  const [selectedDiet, setSelectedDiet] = useState(null);
  const [allAllergens, setAllAllergens] = useState([]);
  const [selectedAllergens, setSelectedAllergens] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    const fetchDiets = async () => {
      try {
        const data = await getAllDiets();
        setDiets(data.content || data);
      } catch (error) {
    
          setErrorMessage('Failed to fetch diets.');
      }
    };

    const fetchAllergenData = async () => {
      try {
        const data = await fetchAllergens();
        setAllAllergens(data.content || data);
      } catch (error) {
       
        setErrorMessage('Failed to fetch allergens.');
      }
    };

    fetchDiets();
    fetchAllergenData();
  }, []);

  useEffect(() => {
    if (selectedDiet) {
     
      const dietAllergens = selectedDiet.allergens.map((allergen) => ({
        value: allergen.id,
        label: allergen.name,
      }));
      setSelectedAllergens(dietAllergens);
      setErrorMessage('');
      setSuccessMessage('');
    }
  }, [selectedDiet]);

  const handleAllergenChange = async (selectedOptions) => {
    if (!selectedDiet) return;

    const previousAllergenIds = selectedAllergens.map((option) => option.value);
    const newAllergenIds = selectedOptions.map((option) => option.value);

    const addedAllergenIds = newAllergenIds.filter((id) => !previousAllergenIds.includes(id));
    const removedAllergenIds = previousAllergenIds.filter((id) => !newAllergenIds.includes(id));

    try {
      
      for (const allergenId of addedAllergenIds) {
        await addAllergenToDiet(selectedDiet.id, allergenId);
      }


      for (const allergenId of removedAllergenIds) {
        await deleteAllergenFromDiet(selectedDiet.id, allergenId);
      }

      setSelectedAllergens(selectedOptions);
      setDiets(
        diets.map((diet) =>
          diet.id === selectedDiet.id
            ? {
                ...diet,
                allergens: allAllergens.filter((allergen) =>
                  newAllergenIds.includes(allergen.id)
                ),
              }
            : diet
        )
      );
      setSelectedDiet((prev) => ({
        ...prev,
        allergens: allAllergens.filter((allergen) =>
          newAllergenIds.includes(allergen.id)
        ),
      }));
      setErrorMessage('');
      setSuccessMessage('Allergens updated successfully.');
    } catch (error) {
   
      setErrorMessage('Failed to update allergens.');
    }
  };

  const handleDeleteDiet = async () => {
    if (selectedDiet) {
      try {
        await deleteDiet(selectedDiet.id);
        setDiets(diets.filter((diet) => diet.id !== selectedDiet.id));
        setSelectedDiet(null);
        setErrorMessage('');
        setSuccessMessage('Diet deleted successfully.');
      } catch (error) {
     
        setErrorMessage('Failed to delete diet.');
      }
    }
  };

  return (
    <div className="diet-list">
      <div className="diet-list__header">
        <h2>All Diets</h2>
      </div>
      <div className="diet-list__items">
        {diets.map((diet) => (
          <div
            key={diet.id}
            onClick={() => setSelectedDiet(diet)}
            className={`diet-list__item ${
              selectedDiet?.id === diet.id ? 'diet-list__item--selected' : ''
            }`}
          >
            {diet.name}
          </div>
        ))}
      </div>

      {selectedDiet && (
        <div className="diet-details">
          <h3>Allergens in {selectedDiet.name}</h3>
          <button onClick={handleDeleteDiet} className="button button--delete-diet">
            Delete Diet
          </button>

          <div className="form-group">
            <label className="label">Allergens:</label>
            <Select
              isMulti
              options={allAllergens.map((allergen) => ({
                value: allergen.id,
                label: allergen.name,
              }))}
              value={selectedAllergens}
              onChange={handleAllergenChange}
              className="multi-select"
              classNamePrefix="select"
              placeholder="Select allergens..."
            />
          </div>
        </div>
      )}
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      {successMessage && <p className="success-message">{successMessage}</p>}
    </div>
  );
};

export default DietList;
