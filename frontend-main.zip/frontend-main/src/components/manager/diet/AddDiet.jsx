import { useState, useEffect } from 'react';
import './AddDiet.scss';
import { fetchAllergens, addDiet } from '../../../service/api/managerApi';
import Select from 'react-select';

function AddDietComponent({ dietId }) {
  const [dietName, setDietName] = useState('');
  const [allAllergens, setAllAllergens] = useState([]);
  const [selectedAllergens, setSelectedAllergens] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    fetchAllergens()
      .then((data) => {
        if (data && Array.isArray(data.content || data)) {
          setAllAllergens(data.content || data);
        } else {
          setErrorMessage('Failed to fetch allergens.');
        }
      })
      .catch((error) => {
        setErrorMessage('Failed to fetch allergens.');
      });
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!dietName.trim()) {
      setErrorMessage('Diet name is required.');
      return;
    }

    const dietData = {
      name: dietName.trim(),
      allergens: selectedAllergens.map((allergen) => allergen.value),
    };

    try {
      await addDiet(dietData);
      setDietName('');
      setSelectedAllergens([]);
      setSuccessMessage('Diet added successfully.');
      setErrorMessage('');
    } catch (error) {
      setErrorMessage(error.message || 'Failed to add diet.');
      setSuccessMessage('');
    }
  };

  return (
    <div className="add-diet-container">
      <h2>{dietId ? 'Edit Diet' : 'Add New Diet'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Diet Name:</label>
          <input
            type="text"
            value={dietName}
            onChange={(e) => setDietName(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label>Allergens:</label>
          <Select
            isMulti
            options={allAllergens.map((allergen) => ({
              value: allergen.id,
              label: allergen.name,
            }))}
            value={selectedAllergens}
            onChange={(selectedOptions) => {
              setSelectedAllergens(selectedOptions || []);
            }}
            className="multi-select"
            classNamePrefix="select"
            placeholder="Select allergens..."
          />
        </div>
        <button type="submit">{dietId ? 'Save Diet' : 'Add Diet'}</button>
      </form>
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      {successMessage && <p className="success-message">{successMessage}</p>}
    </div>
  );
}

export default AddDietComponent;
