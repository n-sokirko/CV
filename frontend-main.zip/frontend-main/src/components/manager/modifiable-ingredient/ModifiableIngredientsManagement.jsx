import React, { useState } from 'react';
import { FaEdit, FaTrash } from 'react-icons/fa';
import './ModifiableIngredientsManagement.scss';
import AddModifiableIngredient from './AddModifiableIngredient';
import EditModifiableIngredient from './EditModifiableIngredient';
import ConfirmationModal from '../confirmationModal/ConfirmationModal';

function ModifiableIngredientsManagement({
  modifiableIngredients,
  handleAddModifiableIngredient,
  handleEditModifiableIngredient,
  handleRemoveModifiableIngredient,
  loading,
  error,
}) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingIngredientId, setEditingIngredientId] = useState(null);
  const [ingredientToDelete, setIngredientToDelete] = useState(null);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);

  const initiateRemove = (ingredient) => {
  
    setIngredientToDelete(ingredient);
    setShowDeleteConfirmation(true);
  };

  const confirmRemove = () => {
    if (ingredientToDelete && ingredientToDelete.id) {
    
      handleRemoveModifiableIngredient(ingredientToDelete.id);
      setIngredientToDelete(null);
      setShowDeleteConfirmation(false);
    } else {
   
    }
  };

  const cancelRemove = () => {
  
    setIngredientToDelete(null);
    setShowDeleteConfirmation(false);
  };

  const cancelAdd = () => {
  
    setIsAdding(false);
  };

  const cancelEdit = () => {
 
    setEditingIngredientId(null);
  };

  return (
    <div className="modifiable-ingredients-management">
      <ul className="modifiable-ingredients-list">
        {modifiableIngredients.length > 0 ? (
          modifiableIngredients.map((ingredient) => (
            <li key={ingredient.id} className="modifiable-ingredient-item">
              <div className="ingredient-details">
                <span className="ingredient-name">{ingredient.ingredient?.name || 'Base'}</span>
                <span className="ingredient-description">{ingredient.ingredient?.description || 'No description available.'}</span>
                <span className="ingredient-quantity">
                  Base: {ingredient.baseCount}, Min: {ingredient.minimumCount}, Max: {ingredient.maximumCount}, Price: ${ingredient.price}
                </span>
              </div>
              <div className="ingredient-actions">
                <button
                  className="edit-btn"
                  onClick={() => {
           
                    setEditingIngredientId(ingredient.id);
                  }}
                  disabled={loading}
                  aria-label={`Edit ${ingredient.ingredient?.name || 'ingredient'}`}
                >
                  <FaEdit /> Edit
                </button>
                <button
                  className="remove-btn"
                  onClick={() => initiateRemove(ingredient)}
                  disabled={loading}
                  aria-label={`Remove ${ingredient.ingredient?.name || 'ingredient'}`}
                >
                  <FaTrash /> Remove
                </button>
              </div>
            </li>
          ))
        ) : (
          <li className="no-ingredients">No modifiable ingredients added yet.</li>
        )}
      </ul>

      {!isAdding && (
        <button
          className="add-modifiable-btn"
          onClick={() => {
      
            setIsAdding(true);
          }}
          disabled={loading}
        >
          Add Modifiable Ingredient
        </button>
      )}

      {isAdding && (
        <AddModifiableIngredient
          onAdd={handleAddModifiableIngredient}
          onCancel={cancelAdd}
          loading={loading}
        />
      )}

      {editingIngredientId && (
        <EditModifiableIngredient
          modifiableIngredientId={editingIngredientId}
          onUpdate={handleEditModifiableIngredient}
          onClose={cancelEdit}
        />
      )}

      {showDeleteConfirmation && (
        <ConfirmationModal
          message={`Are you sure you want to remove "${ingredientToDelete.ingredient?.name || 'this ingredient'}"?`}
          onConfirm={confirmRemove}
          onCancel={cancelRemove}
          loading={loading}
        />
      )}

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
    </div>
  );
}

export default ModifiableIngredientsManagement;
