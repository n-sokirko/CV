import React, { useEffect, useState, useRef } from 'react';
import './AddModifiableIngredient.scss';
import { getAllIngredients } from '../../../service/api/managerApi';

function AddModifiableIngredient({ onAdd, onCancel, loading }) {
  const [modifiableIngredient, setModifiableIngredient] = useState({
    baseCount: '',
    maximumCount: '',
    minimumCount: '',
    price: '',
    ingredientId: '',
  });
  const [allIngredients, setAllIngredients] = useState([]);
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState('');
  const nameInputRef = useRef(null);

  useEffect(() => {
    const fetchAllIngredients = async () => {
      try {
        const ingredients = await getAllIngredients();
        setAllIngredients(ingredients);
      } catch (error) {
        setErrors({ fetch: 'Error fetching ingredients: ' + error.message });
      }
    };

    fetchAllIngredients();
  }, []);

  useEffect(() => {
    if (nameInputRef.current) {
      nameInputRef.current.focus();
    }
  }, [loading]);

  const validate = () => {
    const newErrors = {};

    const { baseCount, minimumCount, maximumCount, price, ingredientId } = modifiableIngredient;

    if (!ingredientId) {
      newErrors.ingredientId = 'Ingredient is required.';
    }

    if (!baseCount) {
      newErrors.baseCount = 'Base count is required.';
    } else if (Number(baseCount) <= 0) {
      newErrors.baseCount = 'Base count must be greater than 0.';
    }

    if (minimumCount === '') {
      newErrors.minimumCount = 'Minimum count is required.';
    } else if (Number(minimumCount) < 0) {
      newErrors.minimumCount = 'Minimum count cannot be negative.';
    }

    if (!maximumCount) {
      newErrors.maximumCount = 'Maximum count is required.';
    } else if (Number(maximumCount) <= Number(minimumCount)) {
      newErrors.maximumCount = 'Maximum count must be greater than minimum count.';
    }

    if (!price && price !== 0) {
      newErrors.price = 'Price is required.';
    } else if (Number(price) < 0) {
      newErrors.price = 'Price cannot be negative.';
    }

    setErrors(newErrors);


    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setModifiableIngredient((prev) => ({ ...prev, [name]: value }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: undefined }));
    setSuccess('');
  };

  const handleAddIngredient = () => {
    setErrors({});
    setSuccess('');

    if (validate()) {
      try {
        onAdd(modifiableIngredient);
        setSuccess('Modifiable ingredient added successfully.');
        
        setModifiableIngredient({
          baseCount: '',
          maximumCount: '',
          minimumCount: '',
          price: '',
          ingredientId: '',
        });
      } catch (error) {
        setErrors({ submit: 'Error adding modifiable ingredient: ' + error.message });
      }
    }
  };

  return (
    <div className="add-modifiable-ingredient">
      <h3>Add Modifiable Ingredient</h3>
      {errors.fetch && <div className="error-message">{errors.fetch}</div>}
      <div className="form-group">
        <label htmlFor="ingredientId">Ingredient:</label>
        <select
          name="ingredientId"
          id="ingredientId"
          value={modifiableIngredient.ingredientId}
          onChange={handleInputChange}
          required
          disabled={loading}
          ref={nameInputRef}
        >
          <option value="">Select an ingredient</option>
          {allIngredients.map((ingredient) => (
            <option key={ingredient.id} value={ingredient.id}>
              {ingredient.name}
            </option>
          ))}
        </select>
        {errors.ingredientId && <span className="error-text">{errors.ingredientId}</span>}
      </div>
      <div className="form-group">
        <label htmlFor="baseCount">Base Count:</label>
        <input
          type="number"
          name="baseCount"
          id="baseCount"
          value={modifiableIngredient.baseCount}
          onChange={handleInputChange}
          required
          disabled={loading}
          min="1"
        />
        {errors.baseCount && <span className="error-text">{errors.baseCount}</span>}
      </div>
      <div className="form-group">
        <label htmlFor="minimumCount">Minimum Count:</label>
        <input
          type="number"
          name="minimumCount"
          id="minimumCount"
          value={modifiableIngredient.minimumCount}
          onChange={handleInputChange}
          required
          disabled={loading}
          min="0"
        />
        {errors.minimumCount && <span className="error-text">{errors.minimumCount}</span>}
      </div>
      <div className="form-group">
        <label htmlFor="maximumCount">Maximum Count:</label>
        <input
          type="number"
          name="maximumCount"
          id="maximumCount"
          value={modifiableIngredient.maximumCount}
          onChange={handleInputChange}
          required
          disabled={loading}
          min={modifiableIngredient.minimumCount || "1"}
        />
        {errors.maximumCount && <span className="error-text">{errors.maximumCount}</span>}
      </div>
      <div className="form-group">
        <label htmlFor="price">Price:</label>
        <input
          type="number"
          name="price"
          id="price"
          value={modifiableIngredient.price}
          onChange={handleInputChange}
          required
          disabled={loading}
          min="0"
          step="0.01"
        />
        {errors.price && <span className="error-text">{errors.price}</span>}
      </div>
      <div className="form-actions">
        <button
          className="submit-btn"
          type="button"
          onClick={handleAddIngredient}
          disabled={loading}
        >
          {loading ? 'Adding...' : 'Add'}
        </button>
        <button
          className="cancel-btn"
          type="button"
          onClick={onCancel}
          disabled={loading}
        >
          Cancel
        </button>
      </div>
      {success && <div className="success-message">{success}</div>}
      {errors.submit && <div className="error-message">{errors.submit}</div>}
    </div>
  );
}

export default AddModifiableIngredient;
