import React, { useState, useEffect, useRef } from 'react';
import './EditModifiableIngredient.scss';
import { getModifiableIngredient, updateModifiableIngredient, getAllIngredients } from '../../../service/api/managerApi';

function EditModifiableIngredient({ modifiableIngredientId, onUpdate, onClose }) {
  const [modifiableIngredientData, setModifiableIngredientData] = useState({
    baseCount: '',
    maximumCount: '',
    minimumCount: '',
    price: '',
    ingredientId: '',
  });
  const [allIngredients, setAllIngredients] = useState([]);
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(true);

  const nameInputRef = useRef(null);

  useEffect(() => {
    if (!modifiableIngredientId) {
      setErrors({ fetch: 'Modifiable ingredient ID is undefined.' });
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      try {
        const ingredientData = await getModifiableIngredient(modifiableIngredientId);
    
        setModifiableIngredientData({
          baseCount: ingredientData.baseCount || '',
          maximumCount: ingredientData.maximumCount || '',
          minimumCount: ingredientData.minimumCount || '',
          price: ingredientData.price || '',
          ingredientId: ingredientData.ingredientId || (ingredientData.ingredient?.id) || '',
        });
      } catch (error) {
   
        setErrors({ fetch: 'Error fetching modifiable ingredient: ' + error.message });
      } finally {
        setLoading(false);
      }
    };

    const fetchIngredients = async () => {
      try {
        const ingredients = await getAllIngredients();
      
        setAllIngredients(ingredients);
      } catch (error) {
   
        setErrors(prev => ({ ...prev, fetchIngredients: 'Error fetching ingredients: ' + error.message }));
      }
    };

    fetchData();
    fetchIngredients();
  }, [modifiableIngredientId]);

  useEffect(() => {
    if (nameInputRef.current) {
      nameInputRef.current.focus();
    }
  }, [loading]);

  const validate = (data) => {
    const newErrors = {};
    const { baseCount, minimumCount, maximumCount, price, ingredientId } = data;

    if (!ingredientId) {
      newErrors.ingredientId = 'Ingredient is required.';
    }

    if (baseCount === '') {
      newErrors.baseCount = 'Base count is required.';
    } else if (Number(baseCount) <= 0) {
      newErrors.baseCount = 'Base count must be greater than 0.';
    }

    if (minimumCount === '') {
      newErrors.minimumCount = 'Minimum count is required.';
    } else if (Number(minimumCount) < 0) {
      newErrors.minimumCount = 'Minimum count cannot be negative.';
    }

    if (maximumCount === '') {
      newErrors.maximumCount = 'Maximum count is required.';
    } else if (Number(maximumCount) <= Number(minimumCount)) {
      newErrors.maximumCount = 'Maximum count must be greater than minimum count.';
    }

    if (Number(minimumCount) > Number(maximumCount)) {
      newErrors.minimumCount = 'Minimum count cannot be greater than maximum count.';
    }

    if (price === '') {
      newErrors.price = 'Price is required.';
    } else if (Number(price) < 0) {
      newErrors.price = 'Price cannot be negative.';
    }

    if (Number(baseCount) < Number(minimumCount) || Number(baseCount) > Number(maximumCount)) {
      newErrors.baseCount = 'Base count must be between minimum count and maximum count.';
    }

    return newErrors;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    const newData = { ...modifiableIngredientData, [name]: value };
    setModifiableIngredientData(newData);
    setSuccess('');

    const newErrors = validate(newData);
    setErrors(newErrors);

  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrors({});
    setSuccess('');

    const currentErrors = validate(modifiableIngredientData);
    if (Object.keys(currentErrors).length > 0) {
      setErrors(currentErrors);
     
      return;
    }

    setLoading(true);

    try {
      const updatedData = {
        baseCount: Number(modifiableIngredientData.baseCount),
        maximumCount: Number(modifiableIngredientData.maximumCount),
        minimumCount: Number(modifiableIngredientData.minimumCount),
        price: Number(modifiableIngredientData.price),
        ingredientId: Number(modifiableIngredientData.ingredientId),
        mealId: null, 
      };

     
      await updateModifiableIngredient(modifiableIngredientId, updatedData);
      setSuccess('Modifiable ingredient updated successfully.');
      onUpdate({ id: modifiableIngredientId, ...updatedData });
      setTimeout(onClose, 2000); 
    } catch (error) {
    
      setErrors({ submit: 'Error updating modifiable ingredient: ' + error.message });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="edit-modifiable-ingredient">
      <h2>Edit Modifiable Ingredient</h2>
      {errors.fetch && <div className="error-message">{errors.fetch}</div>}
      {errors.fetchIngredients && <div className="error-message">{errors.fetchIngredients}</div>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="ingredientId">Ingredient:</label>
          <select
            name="ingredientId"
            id="ingredientId"
            value={modifiableIngredientData.ingredientId}
            onChange={handleInputChange}
            required
            disabled={loading}
            ref={nameInputRef}
          >
            <option value="">Select an ingredient</option>
            {allIngredients.map((ingredient) => (
              <option key={ingredient.id} value={ingredient.id}>
                {ingredient.name}
              </option>
            ))}
          </select>
          {errors.ingredientId && <span className="error-text">{errors.ingredientId}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="baseCount">Base Count:</label>
          <input
            type="number"
            name="baseCount"
            id="baseCount"
            value={modifiableIngredientData.baseCount}
            onChange={handleInputChange}
            required
            disabled={loading}
            min="1"
          />
          {errors.baseCount && <span className="error-text">{errors.baseCount}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="minimumCount">Minimum Count:</label>
          <input
            type="number"
            name="minimumCount"
            id="minimumCount"
            value={modifiableIngredientData.minimumCount}
            onChange={handleInputChange}
            required
            disabled={loading}
            min="0"
          />
          {errors.minimumCount && <span className="error-text">{errors.minimumCount}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="maximumCount">Maximum Count:</label>
          <input
            type="number"
            name="maximumCount"
            id="maximumCount"
            value={modifiableIngredientData.maximumCount}
            onChange={handleInputChange}
            required
            disabled={loading}
            min={modifiableIngredientData.minimumCount || "1"}
          />
          {errors.maximumCount && <span className="error-text">{errors.maximumCount}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="price">Price:</label>
          <input
            type="number"
            name="price"
            id="price"
            value={modifiableIngredientData.price}
            onChange={handleInputChange}
            required
            disabled={loading}
            min="0"
            step="0.01"
          />
          {errors.price && <span className="error-text">{errors.price}</span>}
        </div>
        <div className="form-actions">
          <button
            className="submit-btn"
            type="submit"
            disabled={loading || Object.keys(errors).length > 0}
          >
            {loading ? 'Updating...' : 'Update Modifiable Ingredient'}
          </button>
          <button
            className="cancel-btn"
            type="button"
            onClick={onClose}
            disabled={loading}
          >
            Cancel
          </button>
        </div>
        {success && <div className="success-message">{success}</div>}
        {errors.submit && <div className="error-message">{errors.submit}</div>}
      </form>
    </div>
  );

}

export default EditModifiableIngredient;
