import React, { useState, useEffect } from 'react';
import { fetchWaiters, addWaiter, deleteWaiter, updateWaiter } from '../../../service/api/managerApi';
import styles from './WaiterManagement.module.scss';

const WaiterManagement = () => {
    const [waiters, setWaiters] = useState([]);
    const [newWaiter, setNewWaiter] = useState({
        firstName: '',
        lastName: '',
        login: '',
        password: '',
    });
    const [activeTab, setActiveTab] = useState('active');
    const [message, setMessage] = useState({ type: '', text: '' });

    useEffect(() => {
        loadWaiters();
    }, []);

    useEffect(() => {
        if (message.text) {
            const timer = setTimeout(() => {
                setMessage({ type: '', text: '' });
            }, 2000); 
            return () => clearTimeout(timer);
        }
    }, [message]);

    const loadWaiters = async () => {
        try {
            const response = await fetchWaiters();
            if (response && Array.isArray(response.content)) {
                const correctedData = response.content
                    .filter(waiter => waiter && waiter.id && waiter.firsName && waiter.lastName)
                    .map(waiter => ({
                        id: waiter.id,
                        firstName: waiter.firsName || 'Unknown',
                        lastName: waiter.lastName || 'Unknown',
                        isActive: waiter.isActive ?? false,
                    }));
                setWaiters(correctedData);
            } else {
                setWaiters([]);
                setMessage({ type: 'error', text: 'Failed to load waiters.' });
            }
        } catch (error) {
            console.error('Error fetching waiters:', error);
            setMessage({ type: 'error', text: 'An error occurred while loading waiters.' });
        }
    };

    const handleAddWaiter = async () => {
        try {
            const existingWaiter = waiters.find(waiter => waiter.login === newWaiter.login);
            if (existingWaiter) {
                setMessage({ type: 'error', text: 'Login is already taken.' });
                return;
            }
            const response = await addWaiter(newWaiter);
            const addedWaiter = {
                ...response.data,
                isActive: true,
            };

            setWaiters([...waiters, addedWaiter]);
            setNewWaiter({
                firstName: '',
                lastName: '',
                login: '',
                password: '',
            });
            setMessage({ type: 'success', text: 'Waiter added successfully!' });
        } catch (error) {
            console.error('Error adding waiter:', error);
            setMessage({ type: 'error', text: 'Failed to add waiter.' });
        }
    };

    const handleToggleActive = async waiter => {
        try {
            if (waiter.isActive) {
                await deleteWaiter(waiter.id);
                setWaiters(waiters.map(w => (w.id === waiter.id ? { ...w, isActive: false } : w)));
                setMessage({ type: 'success', text: 'Waiter deactivated successfully.' });
            } else {
                const updatedWaiter = { isActive: true };
                const response = await updateWaiter(waiter.id, updatedWaiter);
                setWaiters(waiters.map(w => (w.id === waiter.id ? { ...w, isActive: response.isActive } : w)));
                setMessage({ type: 'success', text: 'Waiter activated successfully.' });
            }
        } catch (error) {
            console.error('Error toggling waiter status:', error);
            setMessage({ type: 'error', text: 'Failed to update waiter status.' });
        }
    };

    const visibleWaiters = waiters.filter(waiter => waiter.isActive === (activeTab === 'active'));

    return (
        <div className={styles.waiter_management}>
            <h1>Waiter Management</h1>

            {message.text && (
                <div
                    className={`${styles.message} ${message.type === 'success' ? styles.success : styles.error}`}
                >
                    {message.text}
                </div>
            )}

            <div className={styles.waiter_management_addSection}>
                <h2>Add New Waiter</h2>
                <div className={styles.waiter_management_form}>
                    <input
                        type="text"
                        placeholder="First Name"
                        value={newWaiter.firstName}
                        onChange={e => setNewWaiter({ ...newWaiter, firstName: e.target.value })}
                    />
                    <input
                        type="text"
                        placeholder="Last Name"
                        value={newWaiter.lastName}
                        onChange={e => setNewWaiter({ ...newWaiter, lastName: e.target.value })}
                    />
                    <input
                        type="text"
                        placeholder="Login"
                        value={newWaiter.login}
                        onChange={e => setNewWaiter({ ...newWaiter, login: e.target.value })}
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        value={newWaiter.password}
                        onChange={e => setNewWaiter({ ...newWaiter, password: e.target.value })}
                    />
                    <button onClick={handleAddWaiter}>Add Waiter</button>
                </div>
            </div>

            <div className={styles.waiter_management_tabs}>
                <button
                    className={`${styles.waiter_management_tabButton} ${activeTab === 'active' ? styles.active : ''}`}
                    onClick={() => setActiveTab('active')}
                >
                    Active Waiters
                </button>
                <button
                    className={`${styles.waiter_management_tabButton} ${activeTab === 'inactive' ? styles.active : ''}`}
                    onClick={() => setActiveTab('inactive')}
                >
                    Inactive Waiters
                </button>
            </div>

            <div className={styles.waiter_management_listSection}>
                <h2>{activeTab === 'active' ? 'Active Waiters' : 'Inactive Waiters'}</h2>
                <div className={styles.waiter_management_cards}>
                    {visibleWaiters.map((waiter, index) => (
                        <div
                            key={waiter.id || index}
                            className={`${styles.waiter_management_card} ${
                                !waiter.isActive ? styles.inactiveCard : ''
                            }`}
                        >
                            <p>
                                <strong>{waiter.firstName} {waiter.lastName}</strong>
                            </p>
                            <p>Status: {waiter.isActive ? 'Active' : 'Inactive'}</p>
                            <button
                                className={
                                    waiter.isActive ? styles.deactivateButton : styles.activateButton
                                }
                                onClick={() => handleToggleActive(waiter)}
                            >
                                {waiter.isActive ? 'Deactivate' : 'Activate'}
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default WaiterManagement;
