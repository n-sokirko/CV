import {API_PATH} from "./commonApi.js";

export async function RestaurantLogin(login, password) {
    const path = API_PATH + 'auth/restaurant/login'

    const request = {
        login: login,
        password: password
    }

    return await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        },
        body: JSON.stringify(request)
    })
}

export async function getIngredients(name, page = 0, size = 10, sort) {

    const filters = [];

    if (name !== "") {
        const nameFilter = {"property": "name", "operator": "contains", "value": name};
        filters.push(nameFilter);
    }

    const encodedFilter = encodeURIComponent(JSON.stringify(filters));
    const encodedSorting = encodeURIComponent(sort);
    const path = `${API_PATH}ingredients?$filter=${encodedFilter}&page=${page}&size=${size}&$sort=${encodedSorting}`;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function updateIngredientAvailability(id, isAvailable) {
    const path = API_PATH + 'ingredients/' + id + '/availability?availability=' + isAvailable;

    return await fetch(path, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        },
    })
}

export async function getOrders(page = 0, size = 10, startDate, endDate) {
    const filters = [];

        const stateFilter = {"property": "state", "operator": "eq", "value": "IN_PROGRESS"};
        filters.push(stateFilter);

    if (startDate !== "") {
        const startDateFilter = {"property": "createdAt", "operator": "after", "value": startDate};
        filters.push(startDateFilter);
    }

    if (endDate !== "") {
        const endDateFilter = {"property": "createdAt", "operator": "before", "value": endDate};
        filters.push(endDateFilter);
    }

    const encodedFilter = encodeURIComponent(JSON.stringify(filters));

    const path = `${API_PATH}orders?$filter=${encodedFilter}&size=${size}&page=${page}`;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getMealById(id) {
    const path = API_PATH + 'meals/' + id;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getModifiableIngredientById(id) {
    const path = API_PATH + 'modifiable-ingredients/' + id;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function updateOrderState(id, event) {
    const path = API_PATH + 'orders/' + id + '/' + event;

    return await fetch(path, {
        method: 'PUT',
    });
}