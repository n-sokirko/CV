export const API_PATH = "http://localhost:8080/api/v1/"
export const GOOGLE_REDIRECT_URL =  `https://accounts.google.com/o/oauth2/v2/auth?redirect_uri=${API_PATH}auth/google/code/login&response_type=code&client_id=672640810665-7kqf6dqc4t658teb1vn4r8mu39pqb0t7.apps.googleusercontent.com&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile+openid&access_type=offline`
export const FACEBOOK_REDIRECT_URL = `https://www.facebook.com/v20.0/dialog/oauth?client_id=1001820311722627&redirect_uri=${API_PATH}auth/facebook/code/login&state=hello`
export const DEFAULT_IMAGE_LINK = "https://zpi-bucket.s3.us-east-1.amazonaws.com/default_meal_img.jpg";
console.log(API_PATH)

export async function getTables() {
    const path = API_PATH + 'tables';

    return await fetch(path, {
        method: 'GET'
    });
}

export async function getTableById(id) {
    const path = API_PATH + 'tables/' + id;

    return await fetch(path, {
        method: 'GET'
    });
}