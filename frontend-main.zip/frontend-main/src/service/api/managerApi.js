import { API_PATH } from "./commonApi.js";

export async function ManagerLogin(login, password) {
    const path = `${API_PATH}auth/manager/login`;

    const request = {
        login: login,
        password: password
    };

    return await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        },
        body: JSON.stringify(request)
    });
}

export async function addAllergen(allergen) {
    const path = `${API_PATH}allergens`;

    const response = await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(allergen),
    });

    if (!response.ok) {
        throw new Error('Error while adding allergen');
    }

    return response.json();
}

export async function fetchAllergens() {
    const path = `${API_PATH}allergens`;

    const response = await fetch(path, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
    });

    if (!response.ok) {
        throw new Error('Error fetching allergens');
    }

    return await response.json();
}

export async function updateAllergen(allergenId, allergen) {
     const path = `${API_PATH}allergens/${allergenId}`;

    const response = await fetch(path, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(allergen),
    });

    if (!response.ok) {
        throw new Error('Error while updating allergen');
    }

    return response.json();
} 

export async function deleteAllergen(allergenId) {
    const path = `${API_PATH}allergens/${allergenId}`;

    try {
        const response = await fetch(path, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
        });

        if (!response.ok) {
            const errorMessage = await response.text();
            throw new Error(`Error while deleting allergen: ${response.status} ${response.statusText}. ${errorMessage}`);
        }

        if (response.status === 204) {
            return;
        }

        return await response.json();
    } catch (error) {
    
        throw error;
    }
}

export const getAllergens = async () => {
  const path = `${API_PATH}allergens/all`;

  const response = await fetch(path, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error('Error fetching allergens');
  }

  return await response.json();
};

export const addDiet = async (dietData) => {
    const response = await fetch(`${API_PATH}diets`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(dietData),
    });

    if (!response.ok) {
        const responseText = await response.text();
        throw new Error('Failed to add diet: ' + responseText);
    }

    return response.json();
};

export const getAllDiets = async () => {
    const response = await fetch(`${API_PATH}diets`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
    });

    if (!response.ok) {
        const responseText = await response.text();
        throw new Error('Failed to fetch diets: ' + responseText);
    }

    return response.json();
};

export const addAllergenToDiet = async (dietId, allergenId) => {
    const response = await fetch(`${API_PATH}diets/${dietId}/allergen/${allergenId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ allergenId }),
    });
  
    if (!response.ok) {
      const responseText = await response.text();
      throw new Error('Failed to add allergen to diet: ' + responseText);
    }
  
    return response.json();
  };

  export const deleteAllergenFromDiet = async (dietId, allergenId) => {
    const response = await fetch(`${API_PATH}diets/${dietId}/allergen/${allergenId}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
        const responseText = await response.text();
        throw new Error(`Failed to delete allergen from diet: ${response.status} ${response.statusText}. ${responseText}`);
    }

    if (response.status === 204) {
        return; 
    }

    return response.json(); 
};

export const deleteDiet = async (dietId) => {
  const response = await fetch(`${API_PATH}diets/${dietId}`, {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const responseText = await response.text();
    throw new Error(`Failed to delete diet: ${response.status} ${response.statusText}. ${responseText}`);
  }

  if (response.status === 204) {
    return; 
  }

  return response.json(); 
};

export const addIngredient = async (ingredient) => {
  const response = await fetch(`${API_PATH}ingredients`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name: ingredient.name,
      available: ingredient.available,
      allergenIds: ingredient.allergens, 
    }),
  });

  if (!response.ok) {
    throw new Error('Network response was not ok');
  }

  return response.json();
};

export const addAllergenToIngredient = async (ingredientId, allergenId) => {
  try {
    const res = await fetch(`${API_PATH}ingredients/${ingredientId}/allergens/${allergenId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });

   
    if (res.status === 204) {
      return; 
    } 
  
    if (!res.ok) {
      const errorMessage = await res.text(); 
      throw new Error(`Failed to add allergen: ${errorMessage}`);
    }

    return await res.json();
  } catch (error) {

    throw error;
  }
};

export const removeAllergenFromIngredient = async (ingredientId, allergenId) => {
  try {
    const res = await fetch(`${API_PATH}ingredients/${ingredientId}/allergens/${allergenId}`, {
      method: 'DELETE',
    });

    if (!res.ok) {
      throw new Error('Failed to delete allergen from ingredient.');
    }
  } catch (error) {
 
    throw error;
  }
};

export const deleteIngredient = async (id) => {
  const response = await fetch(`${API_PATH}ingredients/${id}`, {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error('Failed to delete ingredient');
  }

  const text = await response.text();
  return text ? JSON.parse(text) : {};
};

export const updateIngredient = async (id, updatedIngredient) => {
  const response = await fetch(`${API_PATH}ingredients/${id}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(updatedIngredient),
  });
  if (!response.ok) {
    throw new Error('Failed to update ingredient');
  }
  return response.json();
};

export const updateIngredientAvailability = async (id, availability) => {
  const url = `${API_PATH}ingredients/${id}/availability?availability=${availability}`;
  
  try {
    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorText = await response.text(); 
     
      throw new Error('Failed to update ingredient availability: ' + errorText);
    }

    return response.json();
  } catch (error) {
 
    throw error; 
  }
};

export const getAllIngredients = async () => {
  try {
    const res = await fetch(`${API_PATH}ingredients/all`);
    if (!res.ok) {
      throw new Error('Failed to fetch all ingredients.');
    }
    return await res.json();
  } catch (error) {
   
    throw error;
  }
};

export const getAllSubcategories = async () => {
  try {
    const response = await fetch(`${API_PATH}subcategories/all`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    }); 
   const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      const errorText = await response.text();
     
      throw new Error('Server error or non-JSON response.');
    }

    if (!response.ok) {
      throw new Error('Failed to fetch subcategories.');
    }

    return await response.json();
  } catch (error) {
   
    throw error;
  }
};

export const addSubcategory = async (subcategory) => {
  try {
    const response = await fetch(`${API_PATH}subcategories`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(subcategory),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || 'Failed to add subcategory.');
    }
    return await response.json();
  } catch (error) {
    throw error;
  }
};

export const deleteSubcategory = async (id) => {
  const response = await fetch(`${API_PATH}subcategories/${id}`, {
      method: 'DELETE',
  });

  if (!response.ok) {
      let errorMessage = 'Failed to delete subcategory.';
      try {
          const errorData = await response.json();
          if (errorData && errorData.message) {
              errorMessage = errorData.message;
          }
      } catch (e) {
        }
      throw new Error(errorMessage);
  }

  return;
};

export const updateSubcategory = async (id, subcategory) => {
  try {
    const response = await fetch(`${API_PATH}subcategories/${id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(subcategory),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || `Failed to update subcategory with ID ${id}.`);
    }

    return await response.json();
  } catch (error) {
    throw error;
  }
};

export const getAllCategories = async () => {
  try {
    const response = await fetch(`${API_PATH}categories`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (!response.ok) {
      throw new Error('Failed to fetch categories.');
    }
    return await response.json();
  } catch (error) {
  
    throw error;
  }
};

export const addCategory = async (category) => {
  try {
 
    const response = await fetch(`${API_PATH}categories`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(category),
    });

    if (!response.ok) {
      const errorText = await response.text(); 
  
      throw new Error('Failed to add category.');
    }

    return await response.json();
  } catch (error) {

    throw error;
  }
};

export const deleteCategory = async (id) => {
  const response = await fetch(`${API_PATH}categories/${id}`, {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    let errorMessage = 'Failed to delete category.';
    try {
      const errorData = JSON.parse(errorText);
      errorMessage = errorData.message || errorMessage;
    } catch (e) {
     
    }
    throw new Error(errorMessage);
  }
};

export const updateCategory = async (id, category) => {
  try {
    const response = await fetch(`${API_PATH}categories/${id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(category),
    });

    if (!response.ok) {
      throw new Error('Failed to update category.');
    }

    return await response.json();
  } catch (error) {
 
    throw error;
  }
};

export const getAllMeals = async () => {
  try {
    const response = await fetch(`${API_PATH}meals`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (!response.ok) {
      throw new Error('Failed to fetch meals.');
    }
    return await response.json();
  } catch (error) {
  
    throw error;
  }
};

export const addMeal = async (mealData) => {
  try {
    const formData = new FormData();
    formData.append('name', mealData.name);
    formData.append('price', Number(mealData.price)); 
    formData.append('calories', Number(mealData.calories)); 
    formData.append('isAvailable', mealData.isAvailable);
    formData.append('subcategoryId', Number(mealData.subcategoryId)); 

    if (Array.isArray(mealData.ingredientsIds) && mealData.ingredientsIds.length) {
      mealData.ingredientsIds.forEach((id) => {
        formData.append('ingredientsIds', id);
      });
    } else {
   
    }
    if (mealData.file) {
      formData.append('file', mealData.file); 
    }

    const response = await fetch(`${API_PATH}meals`, {
      method: 'POST',
      body: formData, 
    });

    if (!response.ok) {
      const errorDetails = await response.text();
      throw new Error(`Failed to add meal. Server response: ${errorDetails}`);
    }

    return await response.json();
  } catch (error) {

    throw error;
  }
};

export const getMealManager = async (id) => {
  try {
    const response = await fetch(`${API_PATH}meals/${id}/manager`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (!response.ok) {
      throw new Error('Failed to fetch meal manager.');
    }
    return await response.json();
  } catch (error) {

    throw error;
  }
};

export const getAllMealsManager = async () => {
  try {
    const response = await fetch(`${API_PATH}meals/manager`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (!response.ok) {
      throw new Error('Failed to fetch all meals manager.');
    }
    return await response.json();
  } catch (error) {

    throw error;
  }
};

export const addIngredientToMeal = async (mealId, ingredientId) => {
  try {
    const response = await fetch(`${API_PATH}meals/${mealId}/ingredients/${ingredientId}`, {
      method: 'POST',
    });

    if (!response.ok) {
      const errorDetails = await response.text();
      throw new Error(`Failed to add ingredient. Server response: ${errorDetails}`);
    }

    return await response.json();
  } catch (error) {
  
    throw error;
  }
};

export const removeIngredientFromMeal = async (mealId, ingredientId) => {
  try {
    const response = await fetch(`${API_PATH}meals/${mealId}/ingredients/${ingredientId}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      const errorDetails = await response.text();
      throw new Error(`Failed to remove ingredient. Server response: ${errorDetails}`);
    }
  } catch (error) {
    
    throw error;
  }
};

export const updateMealMultipart = async (mealId, mealData, image) => {
  try {
    const formData = new FormData();
    if (mealData.name !== undefined) {
      formData.append('name', mealData.name);
    }
    if (mealData.price !== undefined) {
      formData.append('price', mealData.price);
    }
    if (mealData.calories !== undefined) {
      formData.append('calories', mealData.calories);
    }
    if (mealData.subcategoryId !== undefined) {
      formData.append('subcategoryId', mealData.subcategoryId);
    }
    if (image) {
      formData.append('file', image);
    } 
    
    for (let pair of formData.entries()) {

    }
     const response = await fetch(`${API_PATH}meals/${mealId}`, {
      method: 'PATCH',
      body: formData,
    });

    if (!response.ok) {
      const errorDetails = await response.text();
      throw new Error(`Failed to update meal. Server response: ${errorDetails}`);
    }

    return await response.json();
  } catch (err) {
 
    throw err;
  }
};


export const addMealWithImage = async (mealData, image) => {
  try {
    const formData = new FormData();
    formData.append('name', mealData.name);
    formData.append('price', Number(mealData.price));
    formData.append('calories', Number(mealData.calories));
    formData.append('isAvailable', mealData.isAvailable);
    formData.append('subcategoryId', Number(mealData.subcategoryId));

    if (Array.isArray(mealData.ingredientsIds) && mealData.ingredientsIds.length) {
      mealData.ingredientsIds.forEach((id) => {
        formData.append('ingredientsIds', id);
      });
    } else {

    }
    if (image) {
      formData.append('file', image);
    }

    const response = await fetch(`${API_PATH}meals`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorDetails = await response.text();
      throw new Error(`Failed to add meal. Server response: ${errorDetails}`);
    }

    return await response.json();
  } catch (error) {
 
    throw error;
  }
};

export const getMealModifiableIngredients = async (mealId) => {
  const response = await fetch(`${API_PATH}meals/${mealId}/modifiable-ingredients`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',

    },
  });

  if (!response.ok) {
    throw new Error('Failed to fetch modifiable ingredients');
  }

  return await response.json();
};

export const getModifiableIngredient = async (id) => {
  try {
    const response = await fetch(`${API_PATH}modifiable-ingredients/${id}`, {
      method: 'GET',
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch modifiable ingredient with ID: ${id}`);
    }
    return await response.json();
  } catch (error) {
    
    throw error;
  }
};

export const getAllModifiableIngredients = async () => {
  try {
    const response = await fetch(`${API_PATH}modifiable-ingredients/all`, {
      method: 'GET',
    });
    if (!response.ok) {
      throw new Error("Failed to fetch all modifiable ingredients");
    }
    return await response.json();
  } catch (error) {

    throw error;
  }
};

export const addModifiableIngredient = async (modifiableIngredientData) => {
  try {
    const response = await fetch(`${API_PATH}modifiable-ingredients`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(modifiableIngredientData),
    });

    if (!response.ok) {
      const errorDetails = await response.text();
      throw new Error(`Failed to add modifiable ingredient. Server response: ${errorDetails}`);
    }

    return await response.json();
  } catch (error) {

    throw error;
  }
};

export const updateModifiableIngredient = async (id, modifiableIngredient) => {
  try {
    const response = await fetch(`${API_PATH}modifiable-ingredients/${id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(modifiableIngredient),
    });

    if (!response.ok) {
      const errorDetails = await response.text();
      throw new Error(`Failed to update modifiable ingredient. Server response: ${errorDetails}`);
    }

    return await response.json();
  } catch (error) {
 
    throw error;
  }
};

export const removeModifiableIngredient = async (id) => {
  try {
    const response = await fetch(`${API_PATH}modifiable-ingredients/${id}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      throw new Error(`Failed to delete modifiable ingredient with ID: ${id}`);
    }

    return true;
  } catch (error) {
 
    throw error;
  }
};

export const getReservationsByDate = async (date) => {
  try {
    const url = `${API_PATH}reservations`;
    const formattedDate = date.toLocaleDateString('en-CA').replace(/-/g, '/');


    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`Failed to fetch reservations: ${errorBody}`);
    }

    const data = await response.json();


    const filteredReservations = data.content.filter(
      (reservation) => reservation.reservationDate === formattedDate
    );

    return filteredReservations;
  } catch (error) {
    console.error('Error fetching reservations by date:', error);
    throw error;
  }
};

export const getOrdersByDate = async (date) => {
  try {
    const url = `${API_PATH}orders/all`;

    const formattedTargetDate = date.toLocaleDateString('en-GB').replace(/\//g, '-');

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`Failed to fetch orders: ${errorBody}`);
    }

    const data = await response.json();


    const filteredOrders = data.filter((order) => {
      if (!order.createdAt) return false;
      const orderDate = order.createdAt.split(' ')[0];
      return orderDate === formattedTargetDate;
    });

    return filteredOrders;
  } catch (error) {
    console.error('Error fetching orders by date:', error);
    throw error;
  }
};

export const fetchRooms = async () => {
    const response = await fetch(`${API_PATH}rooms`);
    if (!response.ok) {
        throw new Error('Failed to fetch rooms');
    }
    return await response.json();
};

export const addRoom = async (roomData) => {
    const response = await fetch(`${API_PATH}rooms`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(roomData),
    });
    if (!response.ok) {
        throw new Error('Failed to add room');
    }
    return await response.json();
};

export const deleteRoom = async (id) => {
    const response = await fetch(`${API_PATH}rooms/${id}`, {
        method: 'DELETE',
    });
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || 'Failed to delete room');
    }
    try {
        return await response.json();
    } catch (e) {
        return;
    }
};

export const addTable = async (tableData) => {
    const response = await fetch(`${API_PATH}tables`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(tableData),
    });
    if (!response.ok) {
        throw new Error('Failed to add table');
    }
    return await response.json();
};

export const fetchTablesByRoomId = async (roomId) => {
    const response = await fetch(`${API_PATH}tables?roomId=${roomId}`);
    if (!response.ok) {
        throw new Error('Failed to fetch tables');
    }
    return await response.json();
};
export const deleteTable = async (id) => {
    const response = await fetch(`${API_PATH}tables/${id}`, {
        method: 'DELETE',
    });

    if (!response.ok) {
        throw new Error('Failed to delete table');
    }
    return true;
};

export const updateTable = async (id, tableData) => {
    const response = await fetch(`${API_PATH}tables/${id}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(tableData),
    });
    if (!response.ok) {
        throw new Error('Failed to update table');
    }
    return await response.json();
};

export const updateSchedule = async (weekday, openingTime, closingTime) => {
  const response = await fetch(`${API_PATH}configuration/${weekday}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      openingTime: openingTime.toTimeString().slice(0, 8),
      closingTime: closingTime.toTimeString().slice(0, 8),
    }),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || `Failed to update schedule for weekday ${weekday}`);
  }

  return response.json();
};

export const fetchSchedule = async () => {
    const response = await fetch(`${API_PATH}configuration`);
    if (!response.ok) {
        throw new Error('Failed to fetch schedule');
    }
    return response.json();
};

export const fetchWaiters = async () => {
  const response = await fetch(`${API_PATH}waiters`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });


  if (!response.ok) {
    throw new Error('Failed to fetch waiters');
  }

  const data = await response.json();
  return data;
};


export const addWaiter = async (waiterData) => {
  console.log('Sending data to server (POST):', waiterData);
  const response = await fetch(`${API_PATH}waiters`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(waiterData),
  });
  if (!response.ok) {
    throw new Error('Failed to add waiter');
  }
  return await response.json();
};

export const getWaiterById = async (id) => {
  const response = await fetch(`${API_PATH}waiters/${id}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });
  if (!response.ok) {
    throw new Error(`Failed to fetch waiter with ID: ${id}`);
  }
  return await response.json();
};

export const deleteWaiter = async (id) => {
  const response = await fetch(`${API_PATH}waiters/${id}`, {
    method: 'DELETE',
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText || 'Failed to delete waiter');
  }
  return;
};
export const updateWaiter = async (id, waiterData) => {
  console.log('Sending data to server (PATCH):', waiterData);

  const response = await fetch(`${API_PATH}waiters/${id}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(waiterData),
  });

  const responseData = await response.json();
  console.log('Server response (PATCH):', responseData);

  if (!response.ok) {
    throw new Error(`Failed to update waiter. Server response: ${JSON.stringify(responseData)}`);
  }

  return responseData;
};






export const getWaiterPersonalData = async () => {
  const response = await fetch(`${API_PATH}waiters/personaldata`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });
  if (!response.ok) {
    throw new Error('Failed to fetch waiter personal data');
  }
  return await response.json();
};