import {API_PATH} from "./commonApi.js";

export async function Register(name, lastname, email, phone, password, confirmPassword) {
    const path = API_PATH + 'auth/client/register'

    const request = {
        name: name + ' ' + lastname,
        email: email,
        phone: phone,
        password: password,
        passwordRepeat: confirmPassword
    }

    return await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        },
        body: JSON.stringify(request)
    })
}

export async function Login(login, password) {
    const path = API_PATH + 'auth/client/login'

    const request = {
        login: login,
        password: password
    }

    return await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        },
        body: JSON.stringify(request)
    })
}

export async function getCategoryById(id) {
    const path = API_PATH + 'categories/' + id;

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getSubcategoryById(id) {
    const path = API_PATH + 'subcategories/' + id;

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getCategories() {
    const path = API_PATH + 'categories/all';

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getIngredientById(id) {
    const path = API_PATH + 'ingredients/' + id;

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getAllergenById(id) {
    const path = API_PATH + 'allergens/' + id;

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getSubcategoriesByCategoryId(id) {
    const path = API_PATH + 'categories/' + id + '/subcategories';

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getDiets() {
    const path = API_PATH + 'diets/all';

    return await fetch(path, {
        method: 'GET'
    })
}


export async function getModifiableIngredientsByMealId(id) {
    const path = API_PATH + 'meals/' + id + '/modifiable-ingredients';

    return await fetch(path, {
        method: 'GET'
    });
}

export async function getMealById(id) {
    const path = API_PATH + 'meals/' + id;

    return await fetch(path, {
        method: 'GET'
    });
}

export async function getMealsSortedAndFiltered(name, page = 0, size = 10, sort,
                                                categoryName, minPrice, maxPrice,
                                                minCalories, maxCalories, subcategoryName) {
    const filters = [];

    if (name !== "") {
        const nameFilter = {"property": "name", "operator": "contains", "value": name};
        filters.push(nameFilter);
    }
    if (categoryName !== "" && categoryName !== "All") {
        const categoryFilter = {"property": "subcategory.category.name", "operator": "eq", "value": categoryName};
        filters.push(categoryFilter);
    }

    if (subcategoryName !== "" && subcategoryName !== "All") {
        const subcategoryFilter = {"property": "subcategory.name", "operator": "eq", "value": subcategoryName};
        filters.push(subcategoryFilter);
    }

    if (minPrice !== "") {
        const price = parseInt(minPrice);
        const minPriceFilter = {"property": "price", "operator": "gt", "value": price};
        filters.push(minPriceFilter);
    }

    if (maxPrice !== "") {
        const price = parseInt(maxPrice);
        const maxPriceFilter = {"property": "price", "operator": "lt", "value": price};
        filters.push(maxPriceFilter);
    }

    if (minCalories !== "") {
        const calories = parseInt(minCalories);
        const minCaloriesFilter = {"property": "calories", "operator": "gt", "value": calories};
        filters.push(minCaloriesFilter);
    }

    if (maxCalories !== "") {
        const calories = parseInt(maxCalories);
        const maxCaloriesFilter = {"property": "calories", "operator": "lt", "value": calories};
        filters.push(maxCaloriesFilter);
    }
    const encodedFilter = encodeURIComponent(JSON.stringify(filters));
    const encodedSorting = encodeURIComponent(sort);
    const path = `${API_PATH}meals?$filter=${encodedFilter}&page=${page}&size=${size}&$sort=${encodedSorting}`;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getOpeningHours() {
    const path = API_PATH + 'configuration';

    return await fetch(path, {
        method: 'GET'
    });
}

export async function completePersonalInfo(name, lastname, phone, email, token, isEmailChangeable) {
    const path = API_PATH + 'clients/personaldata'

    let request = {
        name: name + ' ' + lastname,
        phone: phone,
    }

    if (isEmailChangeable) {
        request.email = email;
    }

    return await fetch(path, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify(request)
    })
}


export async function getDietsByClientId(id) {
    const path = API_PATH + 'clients/' + id;

    return await fetch(path, {
        method: 'GET'
    });
}

export async function addClientDiet(token, dietId) {
    const path = API_PATH + 'clients/diet/' + dietId;

    return await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': 'Bearer ' + token
        }
    })
}

export async function deleteClientDiet(token, dietId) {
    const path = API_PATH + 'clients/diet/' + dietId;

    return await fetch(path, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': 'Bearer ' + token
        }
    })
}

export async function getPersonalData(token) {
    const path = API_PATH + 'clients/personaldata'

    return await fetch(path, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': 'Bearer ' + token
        }
    })
}

export async function sendEmailToResetPassword(email) {
    const path = API_PATH + 'auth/reset/password?email=' + email

    return await fetch(path, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        }
    })
}

export async function resetPassword(password, passwordRepeat, token) {
    const path = API_PATH + 'auth/reset/password/' + token;
    const request = {
        password: password,
        passwordRepeat: passwordRepeat
    }
    return await fetch(path, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        },
        body: JSON.stringify(request)
    })
}

export async function validateToken(token) {
    const path = API_PATH + 'auth/reset/validate/' + token;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function changePassword(oldPassword, newPassword, repeatPassword, token) {
    const path = API_PATH + 'auth/password'

    const request = {
        oldPassword: oldPassword,
        newPassword: newPassword,
        newPasswordConfirmation: repeatPassword
    }

    return await fetch(path, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': 'Bearer ' + token
        },
        body: JSON.stringify(request)
    })
}


export async function placeOrder(orderData, token) {
    const path = API_PATH + 'orders';

    return await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(orderData),
    });
}

export async function getClientMenu(dietsIds) {
    let path;

    if (dietsIds.length === 0) {
        path = `${API_PATH}meals/match_diets`;
    } else {
        const queryParams = dietsIds.map(dietId => `diets[]=${dietId}`).join('&');
        const encodedQuery = encodeURI(queryParams);
        path = `${API_PATH}meals/match_diets?${encodedQuery}`;
    }

    return await fetch(path, {
        method: 'GET',
    });
}
export async function getDietById(id) {
    const path = API_PATH + 'diets/' + id;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function makeReservation(token, data) {
    const path = API_PATH + 'reservations';

    return await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(data),
    });
}

export async function getOrders(page = 0, size = 10) {
    const path = `${API_PATH}orders?$page=${page}&size=${size}`;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getTableById(id) {
    const path = API_PATH + 'tables/' + id;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getRoomById(id) {
    const path = API_PATH + 'rooms/' + id;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getModifiableIngredientById(id) {
    const path = API_PATH + 'modifiable-ingredients/' + id;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getReservationsByClientId(page, size = 10, clientId, startDate, endDate) {
    const filters = [];

    const clientIdFilter = {"property": "client.id", "operator": "eq", "value": clientId};
    filters.push(clientIdFilter);

    if (startDate !== "") {
        const startDateFilter = {"property": "date", "operator": "after", "value": `${startDate}`};
        filters.push(startDateFilter);
    }

    if (endDate !== "") {
        const endDateFilter = {"property": "date", "operator": "before", "value": `${endDate}`};
        filters.push(endDateFilter);
    }

    const encodedFilter = encodeURIComponent(JSON.stringify(filters));

    const path = `${API_PATH}reservations?$filter=${encodedFilter}&page=${page}&size=${size}`;

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getOrdersByClientId(page = 0, size = 10, clientId, startDate, endDate) {
    const filters = [];

    const clientIdFilter = {"property": "client.id", "operator": "eq", "value": clientId};
    filters.push(clientIdFilter);

    if (startDate !== "") {
        const startDateFilter = {"property": "createdAt", "operator": "after", "value": `${startDate} 00:00:00`};
        filters.push(startDateFilter);
    }

    if (endDate !== "") {
        const endDateFilter = {"property": "createdAt", "operator": "before", "value": `${endDate} 00:00:00`};
        filters.push(endDateFilter);
    }

    const encodedFilter = encodeURIComponent(JSON.stringify(filters));
    const path = `${API_PATH}orders?$filter=${encodedFilter}&size=${size}&page=${page}`;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function updateReservationState(id, token) {
    const path = API_PATH + 'reservations/' + id;

    return await fetch(path, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Authorization': 'Bearer ' + token
        }
    });
}

export async function getTableRecommendation(reservationData){
    const path = API_PATH + 'table_recommendation';

    return await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        },
        body: JSON.stringify(reservationData)
    })
}

export async function getFreeTables(date, from, to, roomId) {
    const path = API_PATH + `tables/free?date=${date}&from=${from}&to=${to}&roomId=${roomId}`;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getMealsRecommendations(cartItems) {
    const path = API_PATH + 'recommendations';

    return await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(cartItems),
    });
}