import {API_PATH} from "./commonApi.js";

export async function WaiterLogin(login, password) {
    const path = API_PATH + 'auth/waiter/login'

    const request = {
        login: login,
        password: password
    }

    return await fetch(path, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=utf-8'
        },
        body: JSON.stringify(request)
    })
}

export async function getReservations(page, size = 10, currentDate, startDate, endDate) {
    const filters = [];

    if (currentDate !== "") {
        const currentDateFilter = {"property": "date", "operator": "at", "value": currentDate};
        filters.push(currentDateFilter);
    }

    if (startDate !== "") {
        const startDateFilter = {"property": "date", "operator": "after", "value": startDate};
        filters.push(startDateFilter);
    }

    if (endDate !== "") {
        const endDateFilter = {"property": "date", "operator": "before", "value": endDate};
        filters.push(endDateFilter);
    }

    const encodedFilter = encodeURIComponent(JSON.stringify(filters));

    const path = `${API_PATH}reservations?$filter=${encodedFilter}&page=${page}&size=${size}`;

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getReservationById(id) {
    const path = API_PATH + 'reservations/' + id;

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getClientById(id) {
    const path = API_PATH + 'clients/' + id;

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getTableById(id) {
    const path = API_PATH + 'tables/' + id;

    return await fetch(path, {
        method: 'GET'
    })
}

export async function getOrders(page = 0, size = 10) {
    const path = `${API_PATH}orders?$page=${page}&size=${size}`;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getRoomById(id) {
    const path = API_PATH + 'rooms/' + id;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getMealById(id) {
    const path = API_PATH + 'meals/' + id;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getModifiableIngredientById(id) {
    const path = API_PATH + 'modifiable-ingredients/' + id;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function updateOrderState(id, event) {
    const path = API_PATH + 'orders/' + id + '/' + event;

    return await fetch(path, {
        method: 'PUT',
    });
}

export async function assignToOrder(id, token) {
    const path = API_PATH + 'orders/' + id + '/add-waiter';

    return await fetch(path, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
        }
    });
}

export async function getOrdersWithoutWaiter(page = 0, size = 10, startDate, endDate) {
    const filters = [];

    if (startDate !== "") {
        const startDateFilter = {"property": "createdAt", "operator": "after", "value": startDate};
        filters.push(startDateFilter);
    }

    if (endDate !== "") {
        const endDateFilter = {"property": "createdAt", "operator": "before", "value": endDate};
        filters.push(endDateFilter);
    }

    const stateFilter = {"property": "state", "operator": "not in", "values": ["FINISHED"]};
    filters.push(stateFilter);

    const encodedFilter = encodeURIComponent(JSON.stringify(filters));

    const path = `${API_PATH}orders/nowaiter?$filter=${encodedFilter}&size=${size}&page=${page}`;

    return fetch(path, {
        method: 'GET'
    });
}

export async function getOrdersByWaiterId(page = 0, size = 10, waiterId, startDate, endDate) {
    const filters = [];

    const waiterIdFilter = {"property": "waiter.id", "operator": "eq", "value": waiterId};
    filters.push(waiterIdFilter);

    if (startDate !== "") {
        const startDateFilter = {"property": "createdAt", "operator": "after", "value": startDate};
        filters.push(startDateFilter);
    }

    if (endDate !== "") {
        const endDateFilter = {"property": "createdAt", "operator": "before", "value": endDate};
        filters.push(endDateFilter);
    }

    const stateFilter = {"property": "state", "operator": "not in", "values": ["FINISHED"]};
    filters.push(stateFilter);

    const encodedFilter = encodeURIComponent(JSON.stringify(filters));
    const path = `${API_PATH}orders?$filter=${encodedFilter}&size=${size}&page=${page}`;

    return await fetch(path, {
        method: 'GET',
    });
}

export async function getWaiterPersonalData(token) {
    const path = API_PATH + 'waiters/personaldata';

    return await fetch(path, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
        }
    });
}